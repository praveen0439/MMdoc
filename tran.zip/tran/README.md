# svio-transactions


This project:

1. Is a Spring batch application consisting of one batch job SvioSIATransactions. The jobs are launched via kafka message.
2. Uses Docker and docker-compose for a local development environment.
3. Is configured via environment variables (for local development these values are set in the `env.local.template` and `env.dev.template` file).

Scope:
This microservice is part of SVIO project: https://massmutual.atlassian.net/wiki/spaces/FAB/pages/5038376530/SVIO+Detailed+Design

This job listens to done (businesscustomers.event.agreements.institutionalcontrol.done) kafka topic and on the reception of done file invokes the job which validates the Control(.Ctrl) and Data(.FIL) files related to Transactions and generates the gasap.txt file at at “svio-prd”>/svio-sia-events" S3 location.
It also writes the data to “gasap_lines” mongo collection for the svio-reporting-batch to process GaSap event.
The status of the job success or failure (statusSia:”Processed” or statusSia:”Failed”) is added to the document in “donefile” collection.

The batch produces a single file which is then writen to a S3 bucket. Spec here: https://massmutual.atlassian.net/wiki/spaces/FAB/pages/5206376715/SIA+Microservice
Otherwise, we have the following cases of errors described here: https://massmutual.atlassian.net/wiki/spaces/FAB/pages/5314838765/SVIO+-+processing+flow+and+error+handling

## Key Contacts

* Team develop: SVI Squad


## Max Request
| Access                                                                                                                        | DEV | QA | PROD |
|-------------------------------------------------------------------------------------------------------------------------------| --- | --- | --- |
| For access to all resources https://massmutual.atlassian.net/wiki/spaces/FAB/pages/5090082929/SVIO+-+AD+Group+Access+Requests |
## Deployed Environments

This application is deployed into three environments:

| Details | DEV                                  | QA            | PROD         |
| --- |--------------------------------------|---------------|--------------|
| Cluster | aws-inst-dev                         | aws-inst-nprd | aws-inst-prd |


### Logs
Application logs can be obtained via Rafay, Sumologic or NewRelic.


## Local Installation Instructions

Before you can get this project running locally you'll need:
- docker,
- docker-compose,
- Java JDK,
- maven build tool installed on your local machine.
- mongodb

If you're using Mac, it is recommended to install these via homebrew:

```bash
$ brew install docker docker-compose adoptopenjdk8 mvn
```

OK, let's get started!!

First, clone down this repo with git and change into the project directory:

```bash
$ git clone https://github.com/massmutual-git/svio-transactions.git
$ cd svio-transactions
```

Next, create your local environment file from the environment template:
We have two options:
- using mongo local
- using mongo from dev environment (for this way you need to be in VPN and to have security access to MongoDB)

```bash
$ cp env.local.template.template env.local.template 
$ cp env.dev.template.template env.dev.template
```
###Start mongo local

Create folder for mongodb you can create under mm id
```bash
$ sudo docker run -it -v <your complete path folder>:/data/db -p 27017:27017  --name mongodb -d mongo
```

###Start postgres local

You can pull a docker postgres image like postgres:14.2-alpine and run it in your local on http://localhost:5432/

###Start kafka local

https://docs.confluent.io/platform/current/platform-quickstart.html#quickstart

For Mac with M1 chip: https://massmutual.atlassian.net/wiki/spaces/FAB/pages/4393731362/Workarounds+for+Apple+Silicon+M1

## Various ways of starting the application:

###Start aplication using docker command
If you want to run it locally or add environment variables you can test it using docker command

```bash
$ docker build -f Dockerfile -t massmutual/test_my_immage:local-test-build .
$ docker run -d --env-file=env.dev.template  massmutual/test_my_immage:local-test-build

```

###Start aplication using Intellij Idea

You can start application in two ways. Before starting, check if you have the valid configuration in `env.local.template` or `env.dev.template` file.

- using run docker file from idea [Click me for tutorial](https://massmutual.atlassian.net/wiki/spaces/FAB/pages/4153704732/Run+Docker+using+environment+file+inIntellij+Idea)
- using debug mode [Click me for tutorial](https://massmutual.atlassian.net/wiki/spaces/FAB/pages/4153247292/Install+and+use+environment+file+in+IntelliJ+IDEA)

## Project Layout

### Folders

* `src/`: Contains all Java Code.
* `deploy/`: Contains the configuration for the kubernetes cluster.

### Important Files in Project Root

* `src/main/resources/application.yml`: A property file for configuration (this file is Spring-boot configuration entry point for all environments).
* `Dockerfile`: The docker file used to build this application for deployment.
* `Jenkinsfile`: Jenkins pipeline instructions
* `src/*.java`: The Application source code.

## Deployment
#### Jenkins setup pipeline tutorial
[Jenkins pipeline configuration tutorial](https://massmutual.atlassian.net/wiki/spaces/FAB/pages/4148004775/How+To+Guide+Importing+Your+Project+Into+Jenkins)

Deployment will be made by Jenkins pipeline for each environment

| DEV | QA| PROD | 
| --- | --- | --- |
|https://jenkins.inst.nsawsdev.massmutual.com/job/svio/ | https://jenkins.inst.nsawsnprd.massmutual.com/job/svio/ | https://jenkins.inst.nsawsprd.massmutual.com/job/svio/ |


### Local Development

The first place you'll work with these environment variables is in your local development environment. Any value set in the `env.local.template` or `env.dev.template` files in the root of this repository will dictate how that value is set for your locally running instance of svio-transactions microservice with local MongoDB or MongoDB from dev environment.

`env.local.template`and `env.dev.template` files is not added to source control (since it could contain sensitive values you might now want to push to github) but a handy env template is available to create your initial local environment (follow the instructions in the **Local Installation Instructions** section to see how to create it).

**NOTE:** Any change you make to `env.local.template` or to `env.dev.template` won't be immediately available in your running application until you rebuild/rerun your local development instance.

### Adding/Updating Credentials in Secret Manager

The credentials used by this application in a deployed environment are encrypted and saved securely in AWS Secret Manager. This section of the README will explain how to read/write those credentials into secrets manager and how to tie specific secure values to particular environment variables in deployed environments.

#### Reading Credentials From Secrets Manager

Take a look at the `deploy/aws/dev/values.yaml` file of this repository. Within it you'll see the section `secrets:svio-downstream-secrets:`. svio-downstream-secrets is the path in Secrets Manager.


```
#### example in deploy/aws/dev/values.yaml file

```
secret:
svio-downstream-secrets:
key:
- JAVAX_NET_SSL_TRUSTSTORE_PASSWORD
```

### Kubernetes
Connect to a kubernetes cluster in terminal using `getAWSTempCredentials` command.
After you enter username and password, you can choose the desired cluster and access it using `kubectl`