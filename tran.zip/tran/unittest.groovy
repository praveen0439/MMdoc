//import libraries
import lib.JenkinsUtilities

// Perform unit test
def unitTest(){
    def utils = new JenkinsUtilities(this)
    docker_file = "Dockerfile"
    docker_path = "${WORKSPACE}/$BUILD_FOLDER"
    try {
        utils.printBold("Performing Unit test")
        sh "DOCKER_BUILDKIT=1 docker build -f $docker_path/$docker_file $docker_path --target export-test-results --output ."


    } catch (Exception e) {
        utils.printError "Error encountered during tests"
        echo 'Exception occured: ' + e.toString()
        throw e

    } finally {

        sh "touch *.xml"
        junit testResults: "*.xml", skipPublishingChecks: true

        utils.printSuccess("Successfully performed Unit tests")
        // Keep the below lines if you want build to fail when unit tests fail. Omitting these lines would mark the build Unstable and continue with next stages
        if (currentBuild.result == 'UNSTABLE' || currentBuild.result == 'FAILURE') {
            currentBuild.result = 'FAILURE'
            utils.errorOutBuild("Unit Tests failed")
        }
    }
}
return this