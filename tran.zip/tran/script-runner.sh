#!/bin/sh -l
echo "svio-transcations Started: $0"
# Update JAVA OPTIONS for specific to your own configuration

JAVA_OPTIONS="-XX:+HeapDumpOnOutOfMemoryError -Xms512m -Xmx512m -DTest=foo -Djavax.net.ssl.trustStorePassword=$trust_store_passwd -javaagent:/usr/local/tomcat/newrelic/newrelic.jar"


#whoami
java -version

echo "-------------------------------------------------------------------"
java $JAVA_OPTIONS -jar /usr/app/app.jar 
ret=$?
echo "-------------------------------------------------------------------"

echo "End executing "

if [ $ret -ne 0 ] ; then
   echo "Execution failed for the command"
   exit 1
fi
