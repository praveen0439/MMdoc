db.getCollection("transactions").aggregate([
    {
        $match: {
            "eventHeader.metadata.eventSourceFilename": "CARSTR20240325110240.FIL",
        }
    },
    {
        $addFields: {
            "productType": {
                $cond: {
                    if: {$eq: ["S", {$substr: ["$contract.investment.fund.reference.id", 0, 1]}]},
                    then: "SIA",
                    else: {
                        $cond: {
                            if: {$eq: ["00005", {$substr: ["$contract.primaryId", 0, 5]}]},
                            then: "EXTGIA",
                            else: "MMGIA"
                        }
                    }
                }
            }
        }
    },
    {
        $lookup: {
            from: "svi_sapgl_mapping",
            let: {
                "typeCode": "$transaction.typeCode",
                "distributorNumber": "$contract.distributor.number",
                "methodCode": "$payoutTransaction.payout.methodCode",
                "productType": "$productType"
            },
            pipeline: [
                {
                    $match: {
                        $expr: {
                            $and: [
                                {$eq: ['$transactionType', '$$typeCode']},
                                {$eq: ['$productType', '$$productType']},
                                {
                                    $or: [
                                        {
                                            $and: [
                                                {$ne: ['$$distributorNumber', null]},
                                                {$eq: ['$purchaseSource', '$$distributorNumber']}
                                            ]
                                        },
                                        {
                                            $and: [
                                                {$ne: ['$$methodCode', null]},
                                                {$eq: ['$paymentMethod', '$$methodCode']}
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            ],
            as: 'sapGLData'
        }
    }
])