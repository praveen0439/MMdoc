package com.mm.enterprise.sviotransactions.model.mapping;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Builder
@Document("bus_area_svi_data")
public class BusArea {
    @Id
    private String id;
    private String portfolioFund;
    private String sapBusinessAreaNumber;
}
