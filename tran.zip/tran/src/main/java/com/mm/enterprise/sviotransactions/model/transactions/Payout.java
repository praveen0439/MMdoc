package com.mm.enterprise.sviotransactions.model.transactions;

import lombok.Data;

@Data
public class Payout {
    private String postingDate;
    private String methodCode;
}
