package com.mm.enterprise.sviotransactions.model.mapping.sqlserver;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="vw_Current_PortfoioFundSAPBusinessArea")
public class BusAreaSqlServer {
    @Id
    private String portfolioFund;
    private String sapBusinessAreaNumber;
}
