package com.mm.enterprise.sviotransactions.listener;

import com.mm.enterprise.sviotransactions.exception.KafkaMessageServiceException;
import com.mm.enterprise.sviotransactions.model.donefiles.DoneFiles;
import com.mm.enterprise.sviotransactions.service.KafkaTopicAlertService;
import com.mm.enterprise.sviotransactions.service.MongoDBService;
import com.mm.enterprise.sviotransactions.util.Constants;
import com.mongodb.MongoException;
import com.mongodb.client.result.UpdateResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.dao.DataAccessException;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.kafka.KafkaException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import static com.mm.enterprise.sviotransactions.exception.KafkaMessageServiceException.KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE;
import static com.mm.enterprise.sviotransactions.exception.KafkaMessageServiceException.WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE;

@Component
@RequiredArgsConstructor
@Slf4j
public class SvioTransactionsJobExecutionListener implements JobExecutionListener {
    private final MongoTemplate mongoTemplate;
    private final KafkaTopicAlertService kafkaTopicAlertService;
    private final MongoDBService mongoDBService;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.info("Starting SvioTransactionsJobExecutionListener");
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        log.info("{} finished with status {}", jobExecution.getJobInstance().getJobName(), jobExecution.getExitStatus());
        JobParameters jobParameters = jobExecution.getJobParameters();
        String doneFileName = jobParameters.getParameters().get(Constants.DONE_FILE_NAME).getValue().toString();
        log.info("Done file retrieved: {}", doneFileName);

        List<StepExecution> stepExecutions = new ArrayList<>(jobExecution.getStepExecutions());

        if (ExitStatus.COMPLETED.equals(jobExecution.getExitStatus())) {
            List<String> controlFiles = (List<String>) jobParameters.getParameters().get(Constants.DONE_CTRL_FILES).getValue();
            List<String> filFiles = (List<String>) jobParameters.getParameters().get(Constants.DONE_FIL_FILES).getValue();
            String noRows = (String) jobExecution.getExecutionContext().get(Constants.NO_ROWS);

            String notificationMessage = String.format("Svio-transactions gasap.txt file generated with %s rows, for %s and %s files from %s.", noRows, controlFiles, filFiles, doneFileName);
            try {
                kafkaTopicAlertService.sendNotification(notificationMessage);
                updateStatusSIA(doneFileName, Constants.PROCESSED);
                log.info("Done file updated successfully: {}", doneFileName);
            } catch (InterruptedException | ExecutionException | TimeoutException e) {
                Thread.currentThread().interrupt();
                throw new KafkaMessageServiceException(WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE, e);
            } catch (KafkaException e) {
                throw new KafkaMessageServiceException(KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE, e);
            }
        } else {
            StepExecution failedStepExecution = stepExecutions.get(stepExecutions.size() - 1);
            List<Throwable> failureExceptions = failedStepExecution.getFailureExceptions();

            String localisedErrorMessage;
            if (failureExceptions.get(failureExceptions.size() - 1).getCause() != null) {
                localisedErrorMessage = failureExceptions.get(failureExceptions.size() - 1).getCause().toString();
            } else {
                localisedErrorMessage = failureExceptions.get(failureExceptions.size() - 1).getLocalizedMessage();
            }
            String errorMessage = jobExecution.getJobInstance().getJobName() + " job FAILED in step: " + failedStepExecution.getStepName() + " with error: " + localisedErrorMessage;
            kafkaTopicAlertService.sendError(errorMessage);
            updateStatusSIA(doneFileName, Constants.FAILED);
            log.info("Done file updated successfully: {}", doneFileName);
        }
    }
    @Retryable(retryFor = {MongoException.class, DataAccessException.class}, maxAttempts = 5, backoff = @Backoff(delay = 2000))
    private void updateStatusSIA(String doneFilename, String status) throws MongoException, DataAccessException {
        Query query = new Query().addCriteria(Criteria.where("eventHeader.metadata.eventSourceFilename").is(doneFilename));
        Update updatedef = new Update().set("eventHeader.statusSia", status);
        UpdateResult updateResult = mongoTemplate.updateFirst(query, updatedef, DoneFiles.class);
        log.info("Done status update: " + updateResult);
    }
}
