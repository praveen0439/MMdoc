package com.mm.enterprise.sviotransactions.model.controlfiles;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.MongoId;


@Data
@Document("controlfiles")
public class ControlFile {

    @MongoId
    private String id;
    private ControlEventHeader eventHeader;
}
