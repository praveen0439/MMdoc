package com.mm.enterprise.sviotransactions.model.mapping;

import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.data.annotation.Id;


@SuperBuilder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString(callSuper = true)
public class SapGL {
    @Id
    private String id;
    private String productType;
    private String transactionType;
    private String purchaseSource;
    private String paymentMethod;
    private String blueGreenBook;
    private String financialLine;
    private String accountDescription;
    private String companyCode;
    private String glAcct;
    private String debitCreditInd;
    private String busArea;
    private String profCnt;
    private String pmtStat;
    private String insStat;
    private String qualStat;
    private String assignment;
}

