package com.mm.enterprise.sviotransactions.model.transactions;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.logging.log4j.util.Chars;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class GasapOutput implements Serializable {
    private String postingDate;
    private String glReferenceNumber;
    private String shortTestHeader;
    private String companyCodeNumber;
    private String glAccountNumber;
    private String debitCreditInd;
    private String cashAmount;
    private String businessArea;
    private String costCenterNumber;
    private String profitCenterNumber;
    private String paymentStatusNumber;
    private String insuranceStatusNumber;
    private String qualifiedStatusNumber;
    private String stateCode;
    private String cityCode;
    private String idNumber;
    private String lineText;
    private String assignment;
    private String investmentVehicle;
    private String rowTerminator;

    @Override
    public String toString() {
        return postingDate +
               glReferenceNumber +
               shortTestHeader +
               companyCodeNumber +
               glAccountNumber +
               debitCreditInd +
               cashAmount +
               businessArea +
               costCenterNumber +
               profitCenterNumber +
               paymentStatusNumber +
               insuranceStatusNumber +
               qualifiedStatusNumber +
               stateCode +
               cityCode +
               idNumber +
               lineText +
               assignment +
               investmentVehicle +
               rowTerminator +
               Chars.LF;
    }
}
