package com.mm.enterprise.sviotransactions.model.transactions;

import lombok.Data;

@Data
public class Transaction {
    private String effectiveDate;
    private String typeCode;
}
