package com.mm.enterprise.sviotransactions.job;

import com.mm.enterprise.sviotransactions.listener.SvioTransactionsJobExecutionListener;
import com.mm.enterprise.sviotransactions.tasklet.GasapFileGeneratorTask;
import com.mm.enterprise.sviotransactions.tasklet.MongoDBWriterTask;
import com.mm.enterprise.sviotransactions.tasklet.TransactionsValidatorTask;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@Slf4j
@RequiredArgsConstructor
public class SvioTransactionsJob {

    private final TransactionsValidatorTask transactionsValidatorTask;
    private final GasapFileGeneratorTask gasapFileGeneratorTask;
    private final MongoDBWriterTask mongoDBWriterTask;
    private final SvioTransactionsJobExecutionListener svioTransactionsJobExecutionListener;

    @Bean
    public Job svioTransactionsBatchJob(JobRepository jobRepository, PlatformTransactionManager platformTransactionManager) {
        return new JobBuilder(BatchJobType.SvioSIATransactions.getValue(), jobRepository)
                .start(validateControlAndFilFiles(jobRepository, platformTransactionManager))
                .next(generateGasapFile(jobRepository, platformTransactionManager))
                .next(writeFileContentToDatabase(jobRepository, platformTransactionManager))
                .listener(svioTransactionsJobExecutionListener)
                .build();
    }

    @Bean
    protected Step validateControlAndFilFiles(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder("validateControlAndFilFiles", jobRepository)
                .tasklet(transactionsValidatorTask, transactionManager)
                .build();
    }

    @Bean
    protected Step generateGasapFile(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder("generateGasapFile", jobRepository)
                .tasklet(gasapFileGeneratorTask, transactionManager)
                .build();
    }

    @Bean
    protected Step writeFileContentToDatabase(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder("writeFileContentToDatabase", jobRepository)
                .tasklet(mongoDBWriterTask, transactionManager)
                .build();
    }
}
