package com.mm.enterprise.sviotransactions.util;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AwsUtils {

    public static final String AWS_WEB_IDENTITY_TOKEN_FILE = "AWS_WEB_IDENTITY_TOKEN_FILE";

    public static String getAwsWebIdentityToken() {
        Path awsWebIdentityTokenPath = Paths.get(System.getenv(AWS_WEB_IDENTITY_TOKEN_FILE));
        try {
            return Files.readAllLines(awsWebIdentityTokenPath).get(0);
        } catch (IOException e) {
            String message = "Error retrieving AWS Web Identity Token";
            log.error(message, e);
            throw new IllegalStateException(message, e);
        }
    }
}
