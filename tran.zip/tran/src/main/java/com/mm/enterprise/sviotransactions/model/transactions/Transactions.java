package com.mm.enterprise.sviotransactions.model.transactions;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.MongoId;

@Data
@Builder
@Document("transactions")
public class Transactions {
    @MongoId
    private String id;
    private TransactionsEventHeader eventHeader;
    private PayoutTransaction payoutTransaction;
    private Contract contract;
    private Transaction transaction;
    private Trade trade;
}
