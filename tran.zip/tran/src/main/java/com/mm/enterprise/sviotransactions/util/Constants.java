package com.mm.enterprise.sviotransactions.util;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class Constants {
    public static final String SVIO_TRANSACTIONS_SESSION = "svio-transactions-session";
    public static final String AWS_ROLE_ARN = "AWS_ROLE_ARN";
    public static final String DONE_FILE_NAME = "svioDoneFileName";
    public static final String DONE_CTRL_FILES = "svioDoneCtrlFiles";
    public static final String DONE_FIL_FILES = "svioDoneFilFiles";
    public static final String NO_ROWS = "noRows";
    public static final String GASAP_CONTENT = "gasapContent";
    public static final String PROCESSED = "PROCESSED";
    public static final String FAILED = "FAILED";


    //Validations
    public static final String RECORD_COUNT = "Failed validation: Records count computed for %s file does not match expected data in control file %s. Computed: %s; Expected: %s.";
    public static final String TOTAL_AMT = "Failed validation: Total net amount computed for %s file does not match expected data in control file %s. Computed: %s; Expected: %s.";
    public static final String FILES_MATCH = "The %s files from done file: %s not matching the %s files from database: %s.";
    public static final String NO_MAPPING_FOUND_SAP_GL = "No mapping found in %s table for: productType: %s, transactionTypeCode: %s, distributorNumber: %s and payoutMethodCode: %s";
    public static final String NO_MAPPING_FOUND_BUS_AREA = "No mapping found in %s table for: fundId: %s";

    // Queries
    public static final String EVENT_SOURCE_FILENAME = "eventHeader.metadata.eventSourceFilename";
    public static final String SAP_GL_SVI_DATA = "svi_sapgl_mapping";
    public static final String BUS_AREA_SVI_DATA = "bus_area_svi_data";
    public static final String TRANSACTIONS = "transactions";
    public static final String GASAP_LINES = "gasap_lines";
    public static final String SIA = "SIA";
    public static final String MMGIA = "MMGIA";
    public static final String EXTGIA = "EXTGIA";


    // Output
    public static final String GL_REF_NUM = "LPB5001000";
    public static final char ZERO = '0';
    public static final String RECORD_TYPE = "TR";
    public static final String TRANS_TYPE = "GL CASPER";
    public static final String TRANS_BATCH_ID = "001";
    public static final String CARRIER_ADMIN_SYSTEM = "RETIR SRVS";
    public static final String START_TAG = "<JOURNALAMT>";
    public static final String END_TAG = "</JOURNALAMT>";

}
