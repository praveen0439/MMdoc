package com.mm.enterprise.sviotransactions.repository;

import com.mm.enterprise.sviotransactions.model.mapping.BusArea;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BusAreaRepository extends MongoRepository<BusArea, String> {

    BusArea findBusAreaByPortfolioFund(String portfolioFund);
}
