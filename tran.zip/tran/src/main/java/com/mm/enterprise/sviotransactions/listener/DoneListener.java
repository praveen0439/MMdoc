package com.mm.enterprise.sviotransactions.listener;

import businesscustomers.event.agreements.institutionalcontrol.done.SvioDone;
import com.mm.enterprise.sviotransactions.exception.KafkaMessageServiceException;
import com.mm.enterprise.sviotransactions.exception.SvioTransactionsException;
import com.mm.enterprise.sviotransactions.job.BatchJobType;
import com.mm.enterprise.sviotransactions.model.mapping.BusArea;
import com.mm.enterprise.sviotransactions.model.mapping.sqlserver.BusAreaSqlServer;
import com.mm.enterprise.sviotransactions.repository.sqlserver.BusAreaSqlServerRepository;
import com.mm.enterprise.sviotransactions.service.JobService;
import com.mm.enterprise.sviotransactions.service.KafkaTopicAlertService;
import com.mm.enterprise.sviotransactions.util.Constants;
import com.mongodb.client.result.UpdateResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.kafka.KafkaException;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import static com.mm.enterprise.sviotransactions.exception.KafkaMessageServiceException.KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE;
import static com.mm.enterprise.sviotransactions.exception.KafkaMessageServiceException.WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE;

@Component
@EnableKafka
@RequiredArgsConstructor
@Slf4j
public class DoneListener {
    private final JobService jobService;
    private final BusAreaSqlServerRepository busAreaSqlServerRepository;
    private final MongoTemplate mongoTemplate;
    private final KafkaTopicAlertService kafkaTopicAlertService;

    @KafkaListener(containerFactory = "mmKafkaListenerContainerFactory", topics = "${mm.svio.transactions.kafka.topic.done}")
    public void consume(@Payload SvioDone svioDone) {
        log.info("Starting the Kafka listener.");
        updateBusAreaCollection();
        startJob(svioDone, BatchJobType.SvioSIATransactions.getValue());
    }

    public void startJob(SvioDone svioDone, String jobType) {
        final Map<String, JobParameter<?>> params = new HashMap<>();
        params.put(Constants.DONE_CTRL_FILES, new JobParameter<>(svioDone.getEventHeader().getMetadata().getEventSourceTransactionsControlFiles(), List.class));
        params.put(Constants.DONE_FIL_FILES, new JobParameter<>(svioDone.getEventHeader().getMetadata().getEventSourceTransactionsFilFiles(), List.class));
        params.put(Constants.DONE_FILE_NAME, new JobParameter<>(svioDone.getEventHeader().getMetadata().getEventSourceFilename(), String.class));
        jobService.startJob(jobType, new JobParameters(params));
    }

    public void updateBusAreaCollection() {
        log.info("Updating bus_area_svi_data collection with Unival data");
        try{
            List<BusAreaSqlServer> busAreaSqlServerList = busAreaSqlServerRepository.findAll();
            if(busAreaSqlServerList.isEmpty()){
                throw new SvioTransactionsException.NoDataInUnivalViewException("There is no data in Unival view vw_Current_PortfoioFundSAPBusinessArea");
            }
            for (BusAreaSqlServer item : busAreaSqlServerList) {
                Query query = new Query().addCriteria(Criteria.where("portfolioFund").is(item.getPortfolioFund()));
                Update updatedef = new Update().set("sapBusinessAreaNumber", item.getSapBusinessAreaNumber());
                UpdateResult updateResult = mongoTemplate.upsert(query, updatedef, BusArea.class);
                if (updateResult.getModifiedCount() != 0) {
                    log.info("portfoliofund " + item.getPortfolioFund() + " is updated with sapBusinessAreaNumber " + item.getSapBusinessAreaNumber());
                } else if (updateResult.getUpsertedId() != null) {
                    log.info("portfoliofund " + item.getPortfolioFund() + " inserted with sapBusinessAreaNumber " + item.getSapBusinessAreaNumber());
                }
            }
        }catch (SvioTransactionsException.NoDataInUnivalViewException e){
            try {
                String notificationMessage = "There is no data in Unival view vw_Current_PortfoioFundSAPBusinessArea";
                kafkaTopicAlertService.sendWarningNotification(notificationMessage);
            } catch (InterruptedException | ExecutionException | TimeoutException ex) {
                Thread.currentThread().interrupt();
                throw new KafkaMessageServiceException(WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE, ex);
            } catch (KafkaException ex) {
                throw new KafkaMessageServiceException(KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE, ex);
            }
        }
        catch (Exception e){
            log.info("An exception while updating bus_area_svi_data collection with Unival data" + e.getMessage());
            String notificationMessage = "An exception while updating bus_area_svi_data collection with Unival data" +"\n"+ e.getMessage();
            try {
                kafkaTopicAlertService.sendWarningNotification(notificationMessage);
            } catch (InterruptedException | ExecutionException | TimeoutException ex) {
                Thread.currentThread().interrupt();
                throw new KafkaMessageServiceException(WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE, ex);
            } catch (KafkaException ex) {
                throw new KafkaMessageServiceException(KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE, ex);
            }
        }
    }
}
