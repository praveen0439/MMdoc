package com.mm.enterprise.sviotransactions.model.transactions;

import com.mm.enterprise.sviotransactions.model.mapping.SapGL;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.data.mongodb.core.mapping.MongoId;

import java.util.List;

@SuperBuilder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString(callSuper = true)
public class TransactionsAggregated {
    @MongoId
    private String id;
    private TransactionsEventHeader eventHeader;
    private PayoutTransaction payoutTransaction;
    private Contract contract;
    private Transaction transaction;
    private Trade trade;
    private String productType;
    private List<SapGL> sapGLData;
}
