package com.mm.enterprise.sviotransactions.repository.sqlserver;

import com.mm.enterprise.sviotransactions.model.mapping.sqlserver.BusAreaSqlServer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BusAreaSqlServerRepository extends JpaRepository<BusAreaSqlServer,String> {

}
