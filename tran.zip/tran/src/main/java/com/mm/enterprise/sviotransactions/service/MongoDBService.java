package com.mm.enterprise.sviotransactions.service;

import com.mm.enterprise.sviotransactions.model.controlfiles.ControlFile;
import com.mm.enterprise.sviotransactions.model.donefiles.DoneFiles;
import com.mm.enterprise.sviotransactions.model.mapping.BusArea;
import com.mm.enterprise.sviotransactions.model.transactions.Transactions;
import com.mm.enterprise.sviotransactions.model.transactions.TransactionsAggregated;
import com.mm.enterprise.sviotransactions.repository.BusAreaRepository;
import com.mm.enterprise.sviotransactions.repository.ControlFilesRepository;
import com.mm.enterprise.sviotransactions.repository.DoneFilesRepository;
import com.mm.enterprise.sviotransactions.repository.TransactionsRepository;
import com.mongodb.bulk.BulkWriteResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.AggregationOptions;
import org.springframework.data.mongodb.core.aggregation.ConditionalOperators;
import org.springframework.data.mongodb.core.aggregation.EvaluationOperators.Expr;
import org.springframework.data.mongodb.core.aggregation.StringOperators;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.mm.enterprise.sviotransactions.util.Constants.*;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;
import static org.springframework.data.mongodb.core.aggregation.BooleanOperators.And.and;
import static org.springframework.data.mongodb.core.aggregation.BooleanOperators.Or.or;
import static org.springframework.data.mongodb.core.aggregation.ComparisonOperators.valueOf;
import static org.springframework.data.mongodb.core.aggregation.ConditionalOperators.when;
import static org.springframework.data.mongodb.core.aggregation.LookupOperation.newLookup;
import static org.springframework.data.mongodb.core.aggregation.VariableOperators.Let.ExpressionVariable.newVariable;
import static org.springframework.data.mongodb.core.query.Criteria.where;

@Service
@Slf4j
@RequiredArgsConstructor
public class MongoDBService {
    private final BusAreaRepository busAreaRepository;
    private final ControlFilesRepository controlFilesRepository;
    private final TransactionsRepository transactionsRepository;
    private final DoneFilesRepository doneFilesRepository;

    private final MongoOperations mongoOperations;
    private final MongoTemplate mongoTemplate;

    public List<TransactionsAggregated> queryTransactions(String eventSourceFileName) {

        final var aggregation = newAggregation(
                match(where(EVENT_SOURCE_FILENAME).is(eventSourceFileName)),
                addFields()
                        .addFieldWithValue("productType",
                                when(valueOf(StringOperators.Substr.valueOf("contract.investment.fund.reference.id").substring(0, 1)).equalToValue("S"))
                                        .then(SIA)
                                        .otherwiseValueOf(when(valueOf(StringOperators.Substr.valueOf("contract.primaryId").substring(0, 5)).equalToValue("00005"))
                                                .then(EXTGIA)
                                                .otherwise(MMGIA)))
                        .build(),
                newLookup()
                        .from(SAP_GL_SVI_DATA)
                        .let(newVariable("typeCode").forField("transaction.typeCode"),
                                newVariable("distributorNumber").forField("contract.distributor.number"),
                                newVariable("methodCode").forField("payoutTransaction.payout.methodCode"),
                                newVariable("productType").forField("productType"))
                        .pipeline(
                                match(
                                        Expr.valueOf(and(
                                                valueOf("transactionType").equalToValue("$$typeCode"),
                                                valueOf("productType").equalToValue("$$productType"),
                                                or(and(valueOf("purchaseSource").equalToValue("$$distributorNumber"),
                                                                ConditionalOperators.ifNull("$$distributorNumber").then(false)),
                                                        and(valueOf("paymentMethod").equalToValue("$$methodCode"),
                                                                ConditionalOperators.ifNull("$$methodCode").then(false))
                                                )

                                        ))
                                )
                        )
                        .as("sapGLData")
        )
                .withOptions(AggregationOptions.builder()
                        .cursorBatchSize(100)
                        .allowDiskUse(true)
                        .build());

        return mongoOperations.aggregate(aggregation, TRANSACTIONS, TransactionsAggregated.class).getMappedResults();
    }

    public BusArea findBusAreaByPortfolioFund(String fundId) {
        return busAreaRepository.findBusAreaByPortfolioFund(fundId);
    }

    public void createCollectionIfNotPresent(String collectionName) {
        if (mongoTemplate.collectionExists(collectionName)) {
            mongoTemplate.dropCollection(collectionName);
        }
        mongoTemplate.createCollection(collectionName);
    }

    public BulkWriteResult bulkInsert(String collectionName, List<?> documents) {
        return mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, collectionName)
                .insert(documents)
                .execute();
    }

    public List<ControlFile> findControlByEventSourceFilename(String fileName) {
        return controlFilesRepository.findByEventSourceFilename(fileName);
    }

    public List<Transactions> findByTransactionsEventSourceFilename(String fileName) {
        return transactionsRepository.findByFileName(fileName);
    }

    public List<DoneFiles> findDoneByEventSourceFilename(String fileName) {
        return doneFilesRepository.findByEventSourceFilename(fileName);
    }

    public DoneFiles saveDoneFile(DoneFiles doneFile) {
        return doneFilesRepository.save(doneFile);
    }

}
