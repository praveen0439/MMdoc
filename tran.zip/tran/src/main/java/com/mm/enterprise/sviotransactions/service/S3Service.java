package com.mm.enterprise.sviotransactions.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;

import java.io.InputStream;

@Slf4j
@Service
@RequiredArgsConstructor
public class S3Service {

    private final S3Client s3Client;

    public void writeS3Object(String bucketName, String bucketKey, String fileContent) {

        PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                .bucket(bucketName)
                .key(bucketKey)
                .build();
        RequestBody requestBody = RequestBody.fromString(fileContent);

        s3Client.putObject(putObjectRequest, requestBody);
        log.info("S3 object {} written successfully", bucketKey);
    }

    public void deleteS3Object(String bucketName, String bucketKey) {

        DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest.builder()
                .bucket(bucketName)
                .key(bucketKey)
                .build();

        s3Client.deleteObject(deleteObjectRequest);
        log.info("S3 object {} deleted successfully", bucketKey);
    }

    public void copyS3Object(String bucketName, String sourceKey, String destinationKey) {

        CopyObjectRequest copyReq = CopyObjectRequest.builder()
                .sourceBucket(bucketName)
                .sourceKey(sourceKey)
                .destinationBucket(bucketName)
                .destinationKey(destinationKey)
                .build();

        log.info("Copied S3 object {} to {} successfully", sourceKey, destinationKey);
        s3Client.copyObject(copyReq);
    }

    public boolean doesS3ObjectExist(String bucketName, String bucketKey) {
        try {
            HeadObjectRequest headObjectRequest = HeadObjectRequest.builder()
                    .bucket(bucketName)
                    .key(bucketKey)
                    .build();
            s3Client.headObject(headObjectRequest);
            log.info("S3 Object {} exists in location {}", bucketKey, bucketName);

            return true;
        } catch (NoSuchKeyException e) {
            log.info("S3 object {} does not exist in location {}", bucketKey, bucketName);
            return false;
        }
    }

    public InputStream getS3Object(String bucketName, String bucketKey) {
        final GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                .bucket(bucketName)
                .key(bucketKey)
                .build();
        return s3Client.getObjectAsBytes(getObjectRequest).asInputStream();
    }
}
