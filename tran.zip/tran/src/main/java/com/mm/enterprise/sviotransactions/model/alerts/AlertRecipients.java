package com.mm.enterprise.sviotransactions.model.alerts;

import lombok.Data;

@Data
public class AlertRecipients {
    private String errorEmail;
    private String errorSlackChannel;
    private String errorWebhook;
    private String errorIconEmoji;
    private String errorSubject;
    private String notificationEmail;
    private String notificationSlackChannel;
    private String notificationWebhook;
    private String notificationIconEmoji;
    private String notificationWarningIconEmoji;
    private String notificationSubject;
    private Boolean xmattersEnabled;
    private String xmattersGroupName;
    private String xmattersType;
}
