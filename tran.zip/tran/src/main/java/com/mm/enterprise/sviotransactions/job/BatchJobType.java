package com.mm.enterprise.sviotransactions.job;

import lombok.Getter;

@Getter
public enum BatchJobType {
    SvioSIATransactions("SvioSIATransactions");
    private final String value;
    BatchJobType(String value) {
        this.value = value;
    }

}
