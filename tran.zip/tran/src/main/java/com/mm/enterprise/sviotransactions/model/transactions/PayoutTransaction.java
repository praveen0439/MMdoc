package com.mm.enterprise.sviotransactions.model.transactions;

import lombok.Data;

@Data
public class PayoutTransaction {
    private Payout payout;
    private Payee payee;
}
