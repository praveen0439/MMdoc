package com.mm.enterprise.sviotransactions.configuration.kafka.producer;

import com.mm.enterprise.sviotransactions.configuration.kafka.KafkaConfiguration;
import com.mm.enterprise.sviotransactions.configuration.kafka.KafkaHelpers;
import io.confluent.kafka.serializers.AbstractKafkaSchemaSerDeConfig;
import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import io.confluent.kafka.serializers.KafkaAvroSerializerConfig;
import jakarta.validation.constraints.NotNull;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.internals.DefaultPartitioner;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class KafkaProducer {

    @NotNull
    @Value(value = "${mm.svio.transactions.kafka.producer.client.id}")
    private String clientId;

    @NotNull
    @Value(value = "${mm.svio.transactions.kafka.producer.block.timeout:60000}")
    private Integer kafkaProducerBlockTimeout;

    @Value(value = "${mm.svio.transactions.kafka.producer.request.timeout:30000}")
    private Integer kafkaProducerRequestTimeout;

    @Value(value = "${mm.svio.transactions.kafka.producer.acks:all}")
    private String kafkaAcks;

    @Value(value = "${mm.svio.transactions.kafka.producer.retries:5}")
    private Integer kafkaProducerRetries;

    @Value(value = "${mm.svio.transactions.alert.topic}")
    private String alertingTopic;


    private final KafkaConfiguration kafkaConfiguration;

    public KafkaProducer(KafkaConfiguration kafkaConfiguration) {
        this.kafkaConfiguration = kafkaConfiguration;
    }

    @Bean
    public Map<String, Object> mmProducerConfigs() {
        Map<String, Object> configs = new HashMap<>();
        configs.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaConfiguration.getKafkaUrl());
        configs.put(ProducerConfig.CLIENT_ID_CONFIG, clientId);
        configs.put(ProducerConfig.MAX_BLOCK_MS_CONFIG, kafkaProducerBlockTimeout);
        configs.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, kafkaProducerRequestTimeout);
        configs.put(ProducerConfig.ACKS_CONFIG, kafkaAcks);
        configs.put(ProducerConfig.RETRIES_CONFIG, kafkaProducerRetries);
        configs.put(ProducerConfig.PARTITIONER_CLASS_CONFIG, DefaultPartitioner.class);
        configs.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configs.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class.getName());
        configs.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, "true");
        configs.put(AbstractKafkaSchemaSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, kafkaConfiguration.getSchemaUrl());
        configs.put(AbstractKafkaSchemaSerDeConfig.AUTO_REGISTER_SCHEMAS, "false");
        configs.put(KafkaAvroSerializerConfig.AVRO_REMOVE_JAVA_PROPS_CONFIG, "true");

        KafkaHelpers.enableKafkaSecurity(configs, kafkaConfiguration);

        return configs;
    }

    @Bean
    public ProducerFactory<String, Object> mmProducerFactory() {
        return new DefaultKafkaProducerFactory<>(mmProducerConfigs());
    }

    @Bean
    public KafkaTemplate<String, Object> alertingKafkaTemplate() {
        KafkaTemplate<String, Object> kafkaTemplate = new KafkaTemplate<>(mmProducerFactory());
        kafkaTemplate.setDefaultTopic(alertingTopic);
        return kafkaTemplate;
    }
}
