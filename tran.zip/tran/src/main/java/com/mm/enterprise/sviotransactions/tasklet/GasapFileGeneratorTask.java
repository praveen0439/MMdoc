package com.mm.enterprise.sviotransactions.tasklet;

import com.mm.enterprise.sviotransactions.model.transactions.GasapOutput;
import com.mm.enterprise.sviotransactions.model.transactions.TransactionsAggregated;
import com.mm.enterprise.sviotransactions.service.GasapFileGeneratorService;
import com.mm.enterprise.sviotransactions.service.MongoDBService;
import com.mm.enterprise.sviotransactions.service.S3Service;
import com.mm.enterprise.sviotransactions.util.Constants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static com.mm.enterprise.sviotransactions.util.Constants.GASAP_CONTENT;
import static com.mm.enterprise.sviotransactions.util.Validator.validateSiaTransactionsContent;


@Service
@RequiredArgsConstructor
@Slf4j
public class GasapFileGeneratorTask implements Tasklet, StepExecutionListener {

    private final MongoDBService mongoDBService;
    private final GasapFileGeneratorService gasapFileGeneratorService;
    private final S3Service s3Service;

    @Value("${mm.svio.transactions.s3.bucket.name}")
    private String s3BucketName;

    @Value("${mm.svio.transactions.s3.bucket.key}")
    private String s3BucketKey;

    private List<GasapOutput> gasapRows;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        log.info("Staring GasapFileGeneratorTask.");
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
        JobParameters jobParameters = contribution.getStepExecution().getJobParameters();
        List<String> doneTransactionsFilFiles = (List<String>) jobParameters.getParameters().get(Constants.DONE_FIL_FILES).getValue();

        List<TransactionsAggregated> siaTransactions = new ArrayList<>();
        for (String doneTransactionsFilFile : doneTransactionsFilFiles) {
            List<TransactionsAggregated> siaTransactionsPartial = mongoDBService.queryTransactions(doneTransactionsFilFile);
            siaTransactions.addAll(siaTransactionsPartial);
        }

        validateSiaTransactionsContent(siaTransactions);

        gasapRows = siaTransactions.stream()
                .map(gasapFileGeneratorService::generateGasapLine)
                .flatMap(Collection::stream)
                .toList();

        String content = gasapRows.stream()
                .map(GasapOutput::toString)
                .collect(Collectors.joining());

        content += gasapFileGeneratorService.generateTrailerRow();

        s3Service.writeS3Object(s3BucketName, s3BucketKey, content);

        contribution.getStepExecution().getJobExecution().getExecutionContext().put(Constants.NO_ROWS, String.valueOf(gasapRows.size()));
        return RepeatStatus.FINISHED;
    }


    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        stepExecution.getJobExecution().getExecutionContext().put(GASAP_CONTENT, gasapRows);
        return ExitStatus.COMPLETED;
    }
}
