package com.mm.enterprise.sviotransactions.model.transactions;

import lombok.Data;

@Data
public class Contract {
    private String primaryId;
    private String suffix;
    private String effectiveDate;
    private Investment investment;
    private Distributor distributor;

}
