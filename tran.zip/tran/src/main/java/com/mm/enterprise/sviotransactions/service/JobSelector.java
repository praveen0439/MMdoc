package com.mm.enterprise.sviotransactions.service;

import org.springframework.batch.core.Job;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class JobSelector {
    private final Map<String, Job> jobs;

    public JobSelector(List<Job> jobs) {
        this.jobs = jobs.stream()
                .collect(Collectors.toMap(Job::getName, Function.identity()));
    }

    public Job get(String jobName) {
        return jobs.get(jobName);
    }
}
