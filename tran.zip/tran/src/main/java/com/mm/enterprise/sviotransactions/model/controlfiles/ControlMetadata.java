package com.mm.enterprise.sviotransactions.model.controlfiles;

import lombok.Data;

import java.time.LocalDate;

@Data
public class ControlMetadata {
    private String eventSourceFilename;
    private String eventSourceFileType;
    private String eventSourceReferencedFilename;
    private String eventSourceRunDate;
    private String eventSourceRunTime;
    private String eventSourceValuationDate;
    private LocalDate processedDate;

}
