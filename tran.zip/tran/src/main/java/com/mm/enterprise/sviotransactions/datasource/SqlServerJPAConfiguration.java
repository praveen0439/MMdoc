package com.mm.enterprise.sviotransactions.datasource;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;


@Configuration
@EnableJpaRepositories(
        basePackages = "com.mm.enterprise.sviotransactions.repository.sqlserver",
        entityManagerFactoryRef = "sqlServerEntityMangerFactoryBean",
        transactionManagerRef = "sqlServerTransactionManager"
)
public class SqlServerJPAConfiguration {

    @Bean
    LocalContainerEntityManagerFactoryBean sqlServerEntityMangerFactoryBean(EntityManagerFactoryBuilder entityManagerFactoryBuilder,@Qualifier("sqlServerDataSource") DataSource dataSource){
        return entityManagerFactoryBuilder
                .dataSource(dataSource)
                .packages("com.mm.enterprise.sviotransactions.model.mapping.sqlserver")
                .build();
    }
    @Bean
    PlatformTransactionManager sqlServerTransactionManager(@Qualifier("sqlServerEntityMangerFactoryBean") LocalContainerEntityManagerFactoryBean emfb){
        return new JpaTransactionManager(emfb.getObject());
    }
}

