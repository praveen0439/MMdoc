package com.mm.enterprise.sviotransactions.configuration.aws;

import com.mongodb.*;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnCloudPlatform;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.cloud.CloudPlatform;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.services.sts.StsClient;
import software.amazon.awssdk.services.sts.model.AssumeRoleWithWebIdentityRequest;
import software.amazon.awssdk.services.sts.model.AssumeRoleWithWebIdentityResponse;
import software.amazon.awssdk.services.sts.model.Credentials;

import java.util.function.Supplier;

import static com.mm.enterprise.sviotransactions.util.AwsUtils.getAwsWebIdentityToken;
import static com.mm.enterprise.sviotransactions.util.Constants.AWS_ROLE_ARN;
import static com.mm.enterprise.sviotransactions.util.Constants.SVIO_TRANSACTIONS_SESSION;

@Configuration
@RequiredArgsConstructor
@EnableConfigurationProperties(AwsMongoProperties.class)
@ConditionalOnCloudPlatform(CloudPlatform.KUBERNETES)
@ConditionalOnProperty(prefix = "mm.svio.transactions.mongo.rbac", value = "enabled", matchIfMissing = true)
@Slf4j
public class AwsMongoConfiguration {

    private final AwsMongoProperties awsMongoProperties;

    @Bean
    MongoClient mongoClient() {

        Supplier<AwsCredential> awsFreshCredentialSupplier = () -> {
            String awsWebIdentityToken = getAwsWebIdentityToken();
            StsClient client = StsClient.builder().build();

            AssumeRoleWithWebIdentityRequest assumeRoleWithWebIdentityRequest = AssumeRoleWithWebIdentityRequest.builder()
                    .webIdentityToken(awsWebIdentityToken)
                    .roleArn(System.getenv(AWS_ROLE_ARN))
                    .roleSessionName(SVIO_TRANSACTIONS_SESSION)
                    .build();

            AssumeRoleWithWebIdentityResponse assumeRoleWithWebIdentityResponse = client.assumeRoleWithWebIdentity(assumeRoleWithWebIdentityRequest);
            Credentials stsCredentials = assumeRoleWithWebIdentityResponse.credentials();

            return new AwsCredential(stsCredentials.accessKeyId(), stsCredentials.secretAccessKey(), stsCredentials.sessionToken());
        };

        MongoCredential credential = MongoCredential
                .createAwsCredential(null, null)
                .withMechanismProperty(MongoCredential.AWS_CREDENTIAL_PROVIDER_KEY, awsFreshCredentialSupplier);

        return MongoClients.create(
                MongoClientSettings.builder()
                        .applyConnectionString(new ConnectionString(awsMongoProperties.getUri()))
                        .retryWrites(true)
                        .writeConcern(WriteConcern.MAJORITY)
                        .credential(credential)
                        .build());
    }
}
