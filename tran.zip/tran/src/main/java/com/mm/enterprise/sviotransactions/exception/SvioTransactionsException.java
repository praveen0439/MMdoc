package com.mm.enterprise.sviotransactions.exception;

public class SvioTransactionsException extends RuntimeException {

    public SvioTransactionsException(String message, Throwable cause) {
        super(message, cause);
    }

    public static class BusinessValidationException extends RuntimeException {

        public BusinessValidationException(String msg) {
            super(msg);
            initCause(new RuntimeException(msg));
        }
    }

    public static class NoDataInUnivalViewException extends RuntimeException {

        public NoDataInUnivalViewException(String msg) {
            super(msg);
            initCause(new RuntimeException(msg));
        }
    }

}
