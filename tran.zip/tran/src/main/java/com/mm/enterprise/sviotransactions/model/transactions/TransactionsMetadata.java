package com.mm.enterprise.sviotransactions.model.transactions;

import lombok.Data;

import java.time.LocalDate;

@Data
public class TransactionsMetadata {
    private String eventSourceFilename;
    private String fileGeneratedDate;
    private LocalDate processedDate;

}
