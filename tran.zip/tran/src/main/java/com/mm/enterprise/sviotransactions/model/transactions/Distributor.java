package com.mm.enterprise.sviotransactions.model.transactions;

import lombok.Data;

@Data
public class Distributor {
    private String number;

}
