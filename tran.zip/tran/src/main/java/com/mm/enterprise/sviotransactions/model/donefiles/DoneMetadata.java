package com.mm.enterprise.sviotransactions.model.donefiles;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class DoneMetadata {

      private String eventSourceFilename;
      private List<String> eventSourceTransactionsControlFiles;
      private List<String> eventSourceTransactionsFilFiles;
      private List<String> eventSourceDisbursementsControlFiles;
      private List<String> eventSourceDisbursementsFilFiles;
      private List<String> eventSourceShareholdersExtractFiles;
      private List<String> eventSourceTransactionsExtractFiles;
      private String fileGeneratedDate;
      private String valuationDate;
      private LocalDate processedDate;

}
