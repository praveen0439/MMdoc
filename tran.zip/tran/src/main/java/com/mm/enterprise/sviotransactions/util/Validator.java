package com.mm.enterprise.sviotransactions.util;

import com.mm.enterprise.sviotransactions.exception.SvioTransactionsException.BusinessValidationException;
import com.mm.enterprise.sviotransactions.model.controlfiles.ControlFile;
import com.mm.enterprise.sviotransactions.model.mapping.BusArea;
import com.mm.enterprise.sviotransactions.model.mapping.SapGL;
import com.mm.enterprise.sviotransactions.model.transactions.Transactions;
import com.mm.enterprise.sviotransactions.model.transactions.TransactionsAggregated;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.function.Predicate;

import static com.mm.enterprise.sviotransactions.util.Constants.*;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Validator {

    public static void checkFileNames(List<String> doneFiles, List<String> databaseFiles, String fileType) {
        if (!databaseFiles.containsAll(doneFiles)) {
            throw new BusinessValidationException(String.format(FILES_MATCH, fileType, doneFiles, fileType, databaseFiles));
        }
    }

    public static void validateRecordCountAndTotalAmount(List<Transactions> transactions, ControlFile controlFile) {
        String controlFileName = controlFile.getEventHeader().getMetadata().getEventSourceFilename();
        String filFileName = controlFile.getEventHeader().getMetadata().getEventSourceReferencedFilename();
        BigDecimal controlTotalRecords = controlFile.getEventHeader().getEventBatchRecordCountTotal();
        BigDecimal controlTotalSum = controlFile.getEventHeader().getEventBatchTotalAmt();

        BigDecimal transactionsSum = computeTransactionsSum(transactions);

        if (controlTotalRecords.compareTo(BigDecimal.valueOf(transactions.size())) != 0) {
            throw new BusinessValidationException(String.format(RECORD_COUNT, filFileName, controlFileName, transactions.size(), controlTotalRecords));
        }

        if (controlTotalSum.compareTo(transactionsSum) != 0) {
            throw new BusinessValidationException(String.format(TOTAL_AMT, filFileName, controlFileName, transactionsSum, controlTotalSum));
        }
    }

    public static BigDecimal computeTransactionsSum(List<Transactions> transactions) {
        return transactions.stream()
                .map(trans -> new BigDecimal(trans.getContract().getInvestment().getValue()))
                .reduce(BigDecimal::add)
                .orElse(BigDecimal.ZERO);
    }

    public static void validateSiaTransactionsContent(List<TransactionsAggregated> siaTransactions) {
        for (TransactionsAggregated siaTransaction : siaTransactions) {
            if (siaTransaction.getSapGLData().isEmpty()) {
                throw new BusinessValidationException(String.format(NO_MAPPING_FOUND_SAP_GL, SAP_GL_SVI_DATA, siaTransaction.getProductType(), siaTransaction.getTransaction().getTypeCode(), siaTransaction.getContract().getDistributor().getNumber(), siaTransaction.getPayoutTransaction().getPayout().getMethodCode()));
            }
            List<SapGL> wrongMappingRows = siaTransaction.getSapGLData().stream()
                    .filter(filterNullFields())
                    .toList();
            if (!wrongMappingRows.isEmpty()) {
                throw new BusinessValidationException(String.format("Null values found in the following rows: %s from %s mapping table.", wrongMappingRows, SAP_GL_SVI_DATA));
            }
        }
    }

    private static Predicate<SapGL> filterNullFields() {
        return sapGL -> SIA.equalsIgnoreCase(sapGL.getProductType()) ? getMandatoryFieldsGIA(sapGL) || sapGL.getInsStat() == null : getMandatoryFieldsGIA(sapGL);
    }

    private static boolean getMandatoryFieldsGIA(SapGL sapGL) {
        return sapGL.getCompanyCode() == null || sapGL.getGlAcct() == null || sapGL.getDebitCreditInd() == null || sapGL.getProfCnt() == null ||
               sapGL.getPmtStat() == null || sapGL.getAssignment() == null;
    }

    public static String formatDate(String date, String pattern, String targetPattern) {
        DateFormat sourceFormat = new SimpleDateFormat(pattern);
        try {
            Date dateAsString = sourceFormat.parse(date);
            SimpleDateFormat dtf = new SimpleDateFormat(targetPattern);
            return dtf.format(dateAsString);
        } catch (ParseException e) {
            throw new BusinessValidationException("Error while trying to parse date! Wrong format given!");
        }
    }

    public static void validateBusArea(String fundId, BusArea busAreaByPortfolioFund) {
        if (busAreaByPortfolioFund == null) {
            throw new BusinessValidationException(String.format(NO_MAPPING_FOUND_BUS_AREA, BUS_AREA_SVI_DATA, fundId));
        }
    }
}
