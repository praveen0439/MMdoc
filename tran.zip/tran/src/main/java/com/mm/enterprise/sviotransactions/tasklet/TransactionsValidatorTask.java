package com.mm.enterprise.sviotransactions.tasklet;

import com.mm.enterprise.sviotransactions.model.controlfiles.ControlFile;
import com.mm.enterprise.sviotransactions.model.transactions.Transactions;
import com.mm.enterprise.sviotransactions.service.MongoDBService;
import com.mm.enterprise.sviotransactions.util.Constants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

import static com.mm.enterprise.sviotransactions.util.Validator.checkFileNames;
import static com.mm.enterprise.sviotransactions.util.Validator.validateRecordCountAndTotalAmount;


@Service
@RequiredArgsConstructor
@Slf4j
public class TransactionsValidatorTask implements Tasklet, StepExecutionListener {

    private final MongoDBService mongoDBService;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        log.info("Staring TransactionsValidatorTask.");
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
        JobParameters jobParameters = contribution.getStepExecution().getJobParameters();
        List<String> doneTransactionsControlFiles = (List<String>) jobParameters.getParameters().get(Constants.DONE_CTRL_FILES).getValue();
        List<String> doneTransactionsFilFiles = (List<String>) jobParameters.getParameters().get(Constants.DONE_FIL_FILES).getValue();

        List<ControlFile> transactionsControlFiles = doneTransactionsControlFiles.stream()
                .map(mongoDBService::findControlByEventSourceFilename)
                .flatMap(List::stream)
                .toList();

        List<String> transactionsControlFileNames = transactionsControlFiles.stream()
                .map(controlFile -> controlFile.getEventHeader().getMetadata().getEventSourceFilename())
                .collect(Collectors.toList());

        checkFileNames(doneTransactionsControlFiles, transactionsControlFileNames, ".ctrl");

        List<String> transactionsFilFileNames = transactionsControlFiles.stream()
                .map(tcf -> tcf.getEventHeader().getMetadata().getEventSourceReferencedFilename())
                .toList();

        checkFileNames(doneTransactionsFilFiles, transactionsFilFileNames, ".FIL");

        for (ControlFile transactionsControlFile : transactionsControlFiles) {
            String eventSourceReferencedFilename = transactionsControlFile.getEventHeader().getMetadata().getEventSourceReferencedFilename();
            List<Transactions> transactionList = mongoDBService.findByTransactionsEventSourceFilename(eventSourceReferencedFilename);
            validateRecordCountAndTotalAmount(transactionList, transactionsControlFile);
        }

        return RepeatStatus.FINISHED;
    }


    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        return StepExecutionListener.super.afterStep(stepExecution);
    }

}
