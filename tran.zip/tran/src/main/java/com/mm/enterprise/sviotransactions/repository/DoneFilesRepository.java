package com.mm.enterprise.sviotransactions.repository;

import com.mm.enterprise.sviotransactions.model.donefiles.DoneFiles;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DoneFilesRepository extends MongoRepository<DoneFiles, String> {
    @Query("{'eventHeader.metadata.eventSourceFilename' : ?0}")
    List<DoneFiles> findByEventSourceFilename(String fileName);

    @Override
    <S extends DoneFiles> S save(S doneFile);
}
