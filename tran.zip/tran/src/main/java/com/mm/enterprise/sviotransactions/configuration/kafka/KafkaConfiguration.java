package com.mm.enterprise.sviotransactions.configuration.kafka;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@NoArgsConstructor
@Configuration
public class KafkaConfiguration {

    @NotNull
    @Value(value = "${mm.svio.transactions.kafka.brokers.url}")
    private String kafkaUrl;

    @Value(value = "${mm.svio.transactions.kafka.schema.url:#{null}}")
    private String schemaUrl;

    @Value(value = "${mm.svio.transactions.kafka.security.protocol:#{null}}")
    private String securityProtocol;

    @Value(value = "${mm.svio.transactions.kafka.basic.auth.credentials.source:#{null}}")
    private String authCredentialSource;

    @Value(value = "${mm.svio.transactions.kafka.basic.auth.user.info:#{null}}")
    private String authUserInfo;

    @Value(value = "${mm.svio.transactions.kafka.sasl.mechanism:#{null}}")
    private String saslMechanism;

    @Value(value = "${mm.svio.transactions.kafka.sasl.login.callback.handler.class:#{null}}")
    private String saslLoginCallback;

    @Value(value = "${mm.svio.transactions.kafka.sasl.jaas.config:#{null}}")
    private String saslJaasConfig;

    @Value(value = "${javax.net.ssl.trustStore:#{null}}")
    private String trustStore;

    @Value(value = "${javax.net.ssl.trustStorePassword:#{null}}")
    private String trustStorePassword;
}
