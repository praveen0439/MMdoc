package com.mm.enterprise.sviotransactions.tasklet;

import com.mm.enterprise.sviotransactions.model.transactions.GasapOutput;
import com.mm.enterprise.sviotransactions.service.MongoDBService;
import com.mm.enterprise.sviotransactions.util.Constants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
@RequiredArgsConstructor
@Slf4j
public class MongoDBWriterTask implements Tasklet, StepExecutionListener {

    private final MongoDBService mongoDBService;
    private List<GasapOutput> gasapRows;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        log.info("Staring MongoDBWriterTask.");
        gasapRows = (List<GasapOutput>) stepExecution.getJobExecution().getExecutionContext().get(Constants.GASAP_CONTENT);
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {

        mongoDBService.createCollectionIfNotPresent(Constants.GASAP_LINES);
        if (!gasapRows.isEmpty()) {
            mongoDBService.bulkInsert(Constants.GASAP_LINES, gasapRows);
        }

        return RepeatStatus.FINISHED;
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        return StepExecutionListener.super.afterStep(stepExecution);
    }

}
