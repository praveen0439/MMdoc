package com.mm.enterprise.sviotransactions.model.transactions;

import lombok.Data;

@Data
public class Address {
    private String stateOrProvinceCode;
    private String typeCode;
}
