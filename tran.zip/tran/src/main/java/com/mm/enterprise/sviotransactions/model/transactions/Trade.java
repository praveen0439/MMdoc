package com.mm.enterprise.sviotransactions.model.transactions;

import lombok.Data;

@Data
public class Trade {
    private String settlementDate;
    private String tradeDate;
}
