package com.mm.enterprise.sviotransactions.service;

import com.mm.enterprise.sviotransactions.model.mapping.BusArea;
import com.mm.enterprise.sviotransactions.model.mapping.SapGL;
import com.mm.enterprise.sviotransactions.model.transactions.GasapOutput;
import com.mm.enterprise.sviotransactions.model.transactions.TransactionsAggregated;
import com.mm.enterprise.sviotransactions.util.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Chars;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import static com.google.common.base.Strings.padEnd;
import static com.google.common.base.Strings.padStart;
import static com.mm.enterprise.sviotransactions.util.Constants.*;
import static com.mm.enterprise.sviotransactions.util.Validator.validateBusArea;
import static org.apache.logging.log4j.util.Chars.SPACE;

@Service
@RequiredArgsConstructor
@Slf4j
public class GasapFileGeneratorService {
    private final MongoDBService mongoDBService;
    private BigDecimal totalAmount = BigDecimal.ZERO;
    private int lineCount;

    public List<GasapOutput> generateGasapLine(TransactionsAggregated transactionsAggregated) {
        List<GasapOutput> output = new ArrayList<>();
        final BigDecimal cashAmount = new BigDecimal(transactionsAggregated.getContract().getInvestment().getValue()).multiply(BigDecimal.valueOf(100)).abs().setScale(0, RoundingMode.UNNECESSARY);
        for (SapGL sapGLDatum : transactionsAggregated.getSapGLData()) {
            totalAmount = totalAmount.add(cashAmount);
            lineCount++;
            final String busArea = getBusArea(transactionsAggregated, sapGLDatum);
            final String pmtStatusNumber = getPmtStatusNumber(transactionsAggregated, sapGLDatum);

            GasapOutput gasapRow = GasapOutput.builder()
                    .postingDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")))
                    .glReferenceNumber(padEnd(GL_REF_NUM, 16, SPACE))
                    .shortTestHeader(padEnd("", 25, SPACE))
                    .companyCodeNumber(sapGLDatum.getCompanyCode())
                    .glAccountNumber(padStart(sapGLDatum.getGlAcct(), 10, ZERO))
                    .debitCreditInd(sapGLDatum.getDebitCreditInd().substring(0, 1))
                    .cashAmount(padStart(cashAmount.toPlainString(), 13, ZERO))
                    .businessArea(busArea)
                    .costCenterNumber(padEnd("", 10, SPACE))
                    .profitCenterNumber(padStart(sapGLDatum.getProfCnt(), 10, ZERO))
                    .paymentStatusNumber(pmtStatusNumber)
                    .insuranceStatusNumber(sapGLDatum.getInsStat() != null ? sapGLDatum.getInsStat() : " ")
                    .qualifiedStatusNumber(sapGLDatum.getQualStat() != null ? sapGLDatum.getQualStat() : " ")
                    .stateCode(transactionsAggregated.getPayoutTransaction().getPayee().getAddress().get(0).getStateOrProvinceCode().toUpperCase())
                    .cityCode(padEnd("", 22, SPACE))
                    .idNumber(transactionsAggregated.getContract().getPrimaryId() + "0010" + transactionsAggregated.getContract().getSuffix())
                    .lineText(padEnd("", 20, SPACE))
                    .assignment(padEnd(sapGLDatum.getAssignment(), 18, SPACE))
                    .investmentVehicle(padEnd("", 21, SPACE))
                    .rowTerminator(padEnd("", 309, SPACE))
                    .build();
            output.add(gasapRow);
        }
        return output;
    }

    private static String getPmtStatusNumber(TransactionsAggregated transactionsAggregated, SapGL sapGLDatum) {
        String pmtStatusNumber;
        if ("0".equals(sapGLDatum.getPmtStat())) {
            pmtStatusNumber = String.valueOf(SPACE);
        } else {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");
            LocalDate settlementDate = LocalDate.parse(transactionsAggregated.getTrade().getSettlementDate(), dtf);
            LocalDate effectiveDate = LocalDate.parse(transactionsAggregated.getContract().getEffectiveDate(), dtf);
            long daysBetween = ChronoUnit.DAYS.between(settlementDate, effectiveDate);
            if (Math.abs(daysBetween) < 365) {
                pmtStatusNumber = "1";
            } else {
                pmtStatusNumber = "2";
            }
        }
        return pmtStatusNumber;
    }

    private String getBusArea(TransactionsAggregated transactionsAggregated, SapGL sapGLDatum) {
        String busArea;
        if (sapGLDatum.getBusArea() == null || sapGLDatum.getBusArea().isEmpty()) {
            String fundId = transactionsAggregated.getContract().getInvestment().getFund().getReference().getId();
            BusArea busAreaByPortfolioFund = mongoDBService.findBusAreaByPortfolioFund(fundId);
            validateBusArea(fundId, busAreaByPortfolioFund);
            busArea = busAreaByPortfolioFund.getSapBusinessAreaNumber();
        } else {
            busArea = sapGLDatum.getBusArea();
        }
        return busArea;
    }

    public String generateTrailerRow() {
        LocalDateTime dateTime = LocalDateTime.now();
        String trailerRow = RECORD_TYPE + TRANS_TYPE + padEnd("", 31, SPACE) +
                            TRANS_BATCH_ID + CARRIER_ADMIN_SYSTEM + padEnd("", 20, SPACE) +
                            Validator.formatDate(dateTime.toString(), "yyyy-MM-dd'T'HH:mm:ss", "yyyyMMddHHmmss") +
                            Validator.formatDate(dateTime.toString(), "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd hh:mm:ss") +
                            padStart(String.valueOf(lineCount), 12, ZERO) +
                            padEnd(START_TAG + totalAmount.toPlainString() + END_TAG, 100, SPACE) +
                            padEnd("", 292, SPACE) +
                            Chars.CR;
        lineCount = 0;
        totalAmount = BigDecimal.ZERO;
        return trailerRow;
    }
}
