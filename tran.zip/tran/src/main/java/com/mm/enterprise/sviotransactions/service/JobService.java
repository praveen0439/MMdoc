package com.mm.enterprise.sviotransactions.service;

import com.mm.enterprise.sviotransactions.exception.SvioTransactionsException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class JobService {
    private final JobSelector jobSelector;
    private final JobLauncher jobLauncher;
    private final KafkaTopicAlertService kafkaTopicAlertService;

    @Async
    public void startJob(String jobName, JobParameters jobParameters) {
        final JobExecution jobExecution;
        Job job = jobSelector.get(jobName);
        try {
            jobExecution = jobLauncher.run(job, jobParameters);
            log.info("Job execution id: " + jobExecution.getId());
        } catch (Exception e) {
            String message = String.format("Exception while starting the job %s with parameters %s. %s", jobName, jobParameters, e);
            kafkaTopicAlertService.sendError(message);
            log.error("Exception while starting the job: {}", jobName, e);
            throw new SvioTransactionsException(message + e.getMessage(), e);
        }
    }
}
