package com.mm.enterprise.sviotransactions.model.transactions;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
public class Reference {
    @Field("id")
    private String id;
}
