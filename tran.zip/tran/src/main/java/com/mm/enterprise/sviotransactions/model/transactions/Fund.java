package com.mm.enterprise.sviotransactions.model.transactions;

import lombok.Data;

@Data
public class Fund {
    private String adminNumber;
    private Reference reference;
}
