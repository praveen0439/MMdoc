package com.mm.enterprise.sviotransactions.model.donefiles;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Builder
@Document("donefiles")
public class DoneFiles {

    @Id
    private String id;
    private DoneEventHeader eventHeader;
}
