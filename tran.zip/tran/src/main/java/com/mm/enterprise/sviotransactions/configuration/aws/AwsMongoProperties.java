package com.mm.enterprise.sviotransactions.configuration.aws;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@ToString
@Validated
@Getter
@Setter
@ConfigurationProperties(prefix = "mm.svio.transactions.mongo")
public class AwsMongoProperties {
    private String uri;
}
