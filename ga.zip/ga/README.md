generic-adapter-svio
===========================================================

About the project : 

1. This is a sample Java Spring-Boot application triggered by generic-adapter-svio-lambda 
2. Built on Docker image and use docker-compose for local development.
3. Uses env variables defined in `env.local.template` and `env.dev.template`
3. Deployed to EKS cluster `eks1-inst`

This microservice is part of SVIO project: https://massmutual.atlassian.net/wiki/spaces/FAB/pages/5038376530/SVIO+Detailed+Design

The service is triggerd by generic-adapter-svio-lambda via API when new files arrived in S3 bucket. GA (generic-adapter-svio) processes the files and loads the data from files into kafka specific topics.The validation of the file is done and in case of some failures, alerts will be sent by GA. 


## Key Contacts

* Team develop: SVI Squad

## Max Request
| Access                                                                                                                        | DEV | QA | PROD |
|-------------------------------------------------------------------------------------------------------------------------------| --- | --- | --- |
| For access to all resources https://massmutual.atlassian.net/wiki/spaces/FAB/pages/5090082929/SVIO+-+AD+Group+Access+Requests |
## Deployed Environments

This application is deployed into three environments:


| Details | DEV               | QA                 | PROD              |
| --- |-------------------|--------------------|-------------------|
| Cluster | eks1-inst-dev | eks1-inst-nprd | eks1-inst-prd |

### Logs
Application logs can be obtained via Rafay, Sumologic or NewRelic. 

## Local Installation Instructions

Before you can get this project running locally you'll need:
- docker
- docker-compose
- Java JDK
- maven build tool installed on your local machine
- mongodb

For more details about how to start Generic Adapter on your local machine, please follow the instructions from this page:
https://massmutual.atlassian.net/wiki/spaces/FAB/pages/5445256819/SVIO+-+Generic+Adapter+Run+Locally

## Project Layout

### Folders

* `src/`: Contains all Java Code.
* `deploy/`: Contains the configuration for the kubernetes cluster.

### Important Files in Project Root

* `src/main/resources/application.yml`: A property file for configuration (this file is Spring-boot configuration entry point for all environments).
* `Dockerfile`: The docker file used to build this application for deployment.
* `Jenkinsfile`: Jenkins pipeline instructions
* `src/*.java`: The Application source code.
