package com.mm.enterprise.genericadaptersvio.mapper;

import businesscustomers.event.agreements.institutionalcontrol.completed.EventHeader;
import businesscustomers.event.agreements.institutionalcontrol.completed.Metadata;
import businesscustomers.event.agreements.institutionalcontrol.completed.SvioControlCompleted;
import com.mm.enterprise.genericadaptersvio.model.control.ControlInput;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class ControlTransactionMapperTest {
    private static final String SOURCE_FILE_NAME = "CARSTR111.ctrl";

    private static final String DATE = "20240304";
    private static final String RUN_TIME = "233000";

    private static final String RECORD_COUNT = "123";

    private static final String TOTAL_AMOUNT = "20";

    private static final String TRANSACTIONS_TYPE = "TRANSACTIONS";

    @InjectMocks
    private ControlTransactionsMapper controlTransactionsMapper;

    @Test
    void mapFromFlatFile_successfullyMapped() {
        // given
        ControlInput controlInput = ControlInput.builder()
                .fileName(SOURCE_FILE_NAME)
                .fileRunDate(DATE)
                .fileRunTime(RUN_TIME)
                .effectiveDate(DATE)
                .recordCount(RECORD_COUNT)
                .facTotals(BigDecimal.valueOf(Long.parseLong(TOTAL_AMOUNT)))
                .build();

        //when
        SvioControlCompleted controlCompleted = controlTransactionsMapper.mapFromFlatFile(controlInput, SOURCE_FILE_NAME, UUID.randomUUID().toString());

        // then
        EventHeader eventHeader = controlCompleted.getEventHeader();
        assertEquals(RECORD_COUNT, eventHeader.getEventBatchRecordCountTotal());
        assertEquals(TOTAL_AMOUNT, eventHeader.getEventBatchTotalAmt());
        assertNotNull(eventHeader.getEventCorrelationId());
        assertEquals("SVIO transactions", eventHeader.getEventSourceDescription());


        Metadata metadata = controlCompleted.getEventHeader().getMetadata();
        assertEquals(SOURCE_FILE_NAME, metadata.getEventSourceFilename());
        assertNotNull(controlCompleted.getEventHeader().getEventBatchGroupId());
        assertEquals(TRANSACTIONS_TYPE, metadata.getEventSourceFileType().toString());
        assertEquals(RUN_TIME, metadata.getEventSourceRunTime());
        assertEquals(DATE, metadata.getEventSourceRunDate());
        assertEquals(LocalDate.now(), metadata.getProcessedDate());
    }
}
