package com.mm.enterprise.genericadaptersvio.mapper;

import businesscustomers.event.disbursements.institutionaldisbursement.requested.*;
import com.mm.enterprise.genericadaptersvio.model.disbursements.DisbursementsInput;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class DisbursementMapperTest {

    @InjectMocks
    private DisbursementsMapper disbursementsMapper;

    @Test
    public void mapDisbursements_success() {
        DisbursementsInput disbursementsInput = DisbursementsInput.builder()
                .pooledFundNumber("GAG")
                .fundID("GEN155001")
                .masterContractNumber("000001550")
                .subPlanNumber("01")
                .tradeDate("20230523")
                .processing_postingDate("20230524")
                .settlementDate("20230524")
                .marketAmount(new BigDecimal("782044.55"))
                .investmentContractType("GA")
                .paymentMethod("U1")
                .taxStateCode("MA")
                .effectiveDate("20230524")
                .reversalFlag("N")
                .reversalReason("00")
                .wireState("")
                .payeeName("")
                .instructionLine1("")
                .instructionLine2("")
                .instructionLine3("")
                .instructionLine4("")
                .instructionLine5("")
                .instructionLine6("")
                .bankName("")
                .bankCity("")
                .recordKeeper("000000")
                .build();

        InstitutionalDisbursementInitiated disbursements = disbursementsMapper.mapFromFlatFile(disbursementsInput, "", "CARSDIST20230524092355.FIL");
        Contract contract = disbursements.getContract();
        assertEquals(disbursementsInput.getPooledFundNumber(), contract.getInvestment().getFund().getReference().getId());
        assertEquals(disbursementsInput.getFundID(), contract.getInvestment().getFund().getAdminNumber());
        assertEquals(disbursementsInput.getMasterContractNumber(), contract.getPrimaryId());
        assertEquals(disbursementsInput.getSubPlanNumber(), contract.getSuffix());
        assertEquals(disbursementsInput.getInvestmentContractType(), contract.getInvestment().getTypeCode());
        assertEquals(disbursementsInput.getRecordKeeper(), contract.getDistributor().getNumber());


        PayoutTransaction payoutTransaction = disbursements.getPayoutTransaction();
        assertEquals(disbursementsInput.getProcessing_postingDate(), payoutTransaction.getPayout().getPostingDate());
        assertEquals(disbursementsInput.getMarketAmount().toString(), payoutTransaction.getPayout().getAmountItem());
        assertEquals(disbursementsInput.getPaymentMethod(), payoutTransaction.getPayout().getMethodCode());
        assertEquals(disbursementsInput.getTaxStateCode(), payoutTransaction.getContract().getOwner().getAddress().getStateOrProvinceCode().toString().toUpperCase());
        assertEquals(disbursementsInput.getEffectiveDate(), payoutTransaction.getPayout().getEffectiveDate());
        assertEquals(disbursementsInput.getWireState(), Objects.toString(payoutTransaction.getPayee().getAddress().getStateOrProvinceCode(), ""));
        assertEquals(disbursementsInput.getPayeeName(), Objects.toString(payoutTransaction.getPayee().getBankAccount().getBankName(), ""));
        assertEquals(disbursementsInput.getInstructionLine1(), Objects.toString(payoutTransaction.getPayee().getBankAccount().getId(), ""));
        assertEquals(disbursementsInput.getInstructionLine2(), Objects.toString(payoutTransaction.getPayee().getBankAccount().getAccountNumber(), ""));
        assertEquals(disbursementsInput.getInstructionLine3(), Objects.toString(payoutTransaction.getPayee().getName().getFullName(), ""));
        assertEquals(disbursementsInput.getBankCity(), Objects.toString(payoutTransaction.getPayee().getAddress().getCity(), ""));


        Trade trade = disbursements.getTrade();
        assertEquals(disbursementsInput.getTradeDate(), trade.getTradeDate());
        assertEquals(disbursementsInput.getSettlementDate(), trade.getSettlementDate());


        Transaction transaction = disbursements.getTransaction();
        assertEquals(reversalIndicator(disbursementsInput.getReversalFlag()), transaction.getReversalIndicator());
        assertEquals(disbursementsInput.getReversalReason(), transaction.getReversalCode());

        EventHeader eventHeader = disbursements.getEventHeader();
        assertEquals(disbursementsInput.getBankName(), Objects.toString(eventHeader.getMetadata().getBankName2(), ""));
        assertEquals(disbursementsInput.getInstructionLine4(), Objects.toString(eventHeader.getMetadata().getInstructionLine4(), ""));
        assertEquals(disbursementsInput.getInstructionLine5(), Objects.toString(eventHeader.getMetadata().getInstructionLine5(), ""));
        assertEquals(disbursementsInput.getInstructionLine6(), Objects.toString(eventHeader.getMetadata().getInstructionLine6(), ""));

    }


    private Boolean reversalIndicator(String ind) {
        if (ind.equals("N"))
            return Boolean.FALSE;
        else
            return Boolean.TRUE;
    }
}
