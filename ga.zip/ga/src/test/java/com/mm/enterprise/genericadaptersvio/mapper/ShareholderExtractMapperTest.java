package com.mm.enterprise.genericadaptersvio.mapper;

import businesscustomers.event.agreements.institutionalcontrol.completed.EventHeader;
import businesscustomers.event.agreements.institutionalcontrol.completed.EventSourceFileType;
import businesscustomers.event.agreements.institutionalcontrol.completed.SvioControlCompleted;
import businesscustomers.event.agreements.institutionalshareholder.requested.Metadata;
import businesscustomers.event.agreements.institutionalshareholder.requested.SVIOShareholderExtract;
import com.mm.enterprise.genericadaptersvio.model.shareholderextract.ShareHolderExtractInputTrailer;
import com.mm.enterprise.genericadaptersvio.model.shareholderextract.ShareholderExtractInputRow;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class ShareholderExtractMapperTest {
    public static final String FUND_NUMBER = "GEN10100";
    public static final String SHARE_HOLDER_ACCOUNT_NUMBER = "000050001";
    public static final String SHARE_HOLDER_SUB_ACCOUNT_NUMBER = "01";
    public static final String DEALER_NUMBER = "2563";
    public static final String ACCOUNT_TYPE = "00";
    public static final String DIVIDEND_OPTION = "00";
    public static final String CAPITAL_GAINS_OPTION = "00";
    public static final String ACCOUNT_STATUS = "0";
    public static final String OPEN_DATE = "20230101";
    public static final String CLOSE_DATE = "00000000";
    public static final BigDecimal BOOK_SHARES = new BigDecimal("320.5150");
    private static final String SOURCE_FILE_NAME = "ShareholderExtract_20230826095704_20230825.txt";

    @InjectMocks
    private ShareHolderExtractMapper shareHolderExtractMapper;

    @Test
    void mapShareholderExtractRow_Success() {
        // given
        ShareholderExtractInputRow shareholderExtractInputRow = ShareholderExtractInputRow.builder()
                .fundNumber(FUND_NUMBER)
                .shareHolderAccountNumber(SHARE_HOLDER_ACCOUNT_NUMBER)
                .sharHolderSubAccountNumber(SHARE_HOLDER_SUB_ACCOUNT_NUMBER)
                .dealerNumber(DEALER_NUMBER)
                .accountType(ACCOUNT_TYPE)
                .dividendOption(DIVIDEND_OPTION)
                .capitalGainsOption(CAPITAL_GAINS_OPTION)
                .accountStatus(ACCOUNT_STATUS)
                .accountOpenDate(OPEN_DATE)
                .accountCloseDate(CLOSE_DATE)
                .bookShares(BOOK_SHARES)
                .build();

        // when
        SVIOShareholderExtract svioShareholderExtract = shareHolderExtractMapper.mapShareholderExtractRow(shareholderExtractInputRow, UUID.randomUUID().toString(), SOURCE_FILE_NAME);

        // then
        Metadata metadata = svioShareholderExtract.getEventHeader().getMetadata();
        assertEquals(SOURCE_FILE_NAME, metadata.getEventSourceFilename());
        assertEquals("20230826", metadata.getFileGeneratedDate());
        businesscustomers.event.agreements.institutionalshareholder.requested.Contract contract = svioShareholderExtract.getContract();
        assertEquals(FUND_NUMBER, contract.getInvestment().getFund().getAdminNumber());
        assertEquals(SHARE_HOLDER_ACCOUNT_NUMBER, contract.getPrimaryId());
        assertEquals(SHARE_HOLDER_SUB_ACCOUNT_NUMBER, contract.getSuffix());
        assertEquals(DEALER_NUMBER, contract.getDistributor().getNumber());
        assertEquals(ACCOUNT_STATUS, contract.getStatusCode());
        assertEquals(DIVIDEND_OPTION, contract.getInvestment().getDividend().getDividendOptionTypeCode());
        assertEquals(CAPITAL_GAINS_OPTION, contract.getInvestment().getDividend().getCapitalGainTypeCode());
        assertEquals(ACCOUNT_TYPE, contract.getTypeCode());
        assertEquals(OPEN_DATE, contract.getEffectiveDate());
        assertEquals(CLOSE_DATE, contract.getExpirationDate());
        assertEquals(String.valueOf(BOOK_SHARES), contract.getInvestment().getUnitCount());
    }

    @Test
    void givenValidTrailer_ReturnValidCompletedAvroObject() throws Exception {
        // given
        ShareHolderExtractInputTrailer shareHolderExtractInputTrailer = ShareHolderExtractInputTrailer.builder()
                .transactionCount("00000000038")
                .bookSharesSum(BigDecimal.valueOf(3456.73))
                .build();
        // when
        SvioControlCompleted svioControlCompleted = shareHolderExtractMapper.mapShareholderExtractTrailer(shareHolderExtractInputTrailer, UUID.randomUUID().toString(), SOURCE_FILE_NAME);

        // then
        EventHeader eventHeader = svioControlCompleted.getEventHeader();
        assertEquals("36", eventHeader.getEventBatchRecordCountTotal());
        assertEquals("3456.73", eventHeader.getEventBatchTotalAmt());
        assertEquals(SOURCE_FILE_NAME, eventHeader.getMetadata().getEventSourceFilename());
        assertEquals("20230825", eventHeader.getMetadata().getEventSourceValuationDate());
        assertEquals("20230826", eventHeader.getMetadata().getEventSourceRunDate());
        assertEquals("095704", eventHeader.getMetadata().getEventSourceRunTime());
        assertEquals(EventSourceFileType.SHAREHOLDERSEXTRACT, eventHeader.getMetadata().getEventSourceFileType());
    }

}