package com.mm.enterprise.genericadaptersvio.config.job.disbursements;

import com.mm.enterprise.genericadaptersvio.mapper.DisbursementsMapper;
import com.mm.enterprise.genericadaptersvio.model.control.ControlInput;
import com.mm.enterprise.genericadaptersvio.model.disbursements.DisbursementsInput;
import com.mm.enterprise.genericadaptersvio.processor.DisbursementsProcessor;
import com.mm.enterprise.genericadaptersvio.util.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;

@ExtendWith(MockitoExtension.class)
public class DisbursementsProcessorTest {

    @Mock
    private DisbursementsMapper disbursementsMapper;

    @Mock
    private StepExecution stepExecution;

    @InjectMocks
    private DisbursementsProcessor disbursementsProcessor;

    @Test
    void givenValidDisbursementsInput_mapperSuccessfullyCalled() throws Exception {
        DisbursementsInput input = new DisbursementsInput();
        final Map<String, JobParameter<?>> params = new HashMap<>();
        params.put(Constants.S3_BUCKET_KEY_PARAM, new JobParameter<>("test/test/disbursements.fil", String.class));
        //  set mock
        disbursementsProcessor.beforeStep(stepExecution);
        Mockito.when(stepExecution.getJobParameters()).thenReturn(new JobParameters(params));
        JobExecution jobExecution = Mockito.mock(JobExecution.class);
        ExecutionContext executionContext = new ExecutionContext();
        Mockito.when(jobExecution.getExecutionContext()).thenReturn(executionContext);
        Mockito.when(stepExecution.getJobExecution()).thenReturn(jobExecution);

        disbursementsProcessor.process(input);

        Mockito.verify(disbursementsMapper, Mockito.times(1)).mapFromFlatFile(eq(input), anyString(),anyString());
    }
}
