package com.mm.enterprise.genericadaptersvio.mapper;

import businesscustomers.event.agreements.institutionaltransactions.requested.*;
import com.mm.enterprise.genericadaptersvio.model.transaction.TransactionInput;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;


@ExtendWith(MockitoExtension.class)
public class TransactionMapperTest {

    @InjectMocks
    private TransactionsMapper transactionsMapper;

    public static final String REFERENCE_ID = "referenceId";
    public static final String FUND_ID = "fundId";
    public static final String ACCOUNT_NUMBER = "111";
    public static final String SUBACCOUNT_NUMBER = "222";
    public static final String VALUATION_DATE = "20231120";
    public static final BigDecimal TRANSACTION_MARKET_AMOUNT = BigDecimal.TEN;
    public static final String TRANSACTION_TYPE = "ABC";

    @Test
    public void mapTransaction_success() {
        TransactionInput transactionInput = TransactionInput.builder()
                .referenceId(REFERENCE_ID)
                .effectiveDate("20231120")
                .contractEffectiveDate("20231120")
                .settlementDate("20231120")
                .fundId(FUND_ID)
                .accountNumber(ACCOUNT_NUMBER)
                .subAccountNumber(SUBACCOUNT_NUMBER)
                .valuationDate(VALUATION_DATE)
                .transactionMarketAmount(TRANSACTION_MARKET_AMOUNT)
                .transactionType(TRANSACTION_TYPE)
                .taxStateCode("MI")
                .build();

        SVIOTransactions transactions = transactionsMapper.mapFromFlatFile(transactionInput, "", "CARSTR20230524092355.FIL");

        Contract contract = transactions.getContract();
        Assertions.assertEquals(transactionInput.getReferenceId(), contract.getInvestment().getFund().getReference().getId());
        Assertions.assertEquals(transactionInput.getFundId(), contract.getInvestment().getFund().getAdminNumber());
        Assertions.assertEquals(transactionInput.getAccountNumber(), contract.getPrimaryId());
        Assertions.assertEquals(transactionInput.getSubAccountNumber(), contract.getSuffix());

        Trade trade = transactions.getTrade();
        Assertions.assertEquals(transactionInput.getValuationDate(), trade.getTradeDate());
    }

    @Test
    public void mapTransaction_marketAmountPositive_DistributorNumberNotNull_PayoutPaymentMethodNull() {
        TransactionInput transactionInput = TransactionInput.builder()
                .referenceId(REFERENCE_ID)
                .effectiveDate("20231120")
                .contractEffectiveDate("20231120")
                .settlementDate("20231120")
                .fundId(FUND_ID)
                .accountNumber(ACCOUNT_NUMBER)
                .subAccountNumber(SUBACCOUNT_NUMBER)
                .valuationDate(VALUATION_DATE)
                .transactionMarketAmount(TRANSACTION_MARKET_AMOUNT)
                .transactionType(TRANSACTION_TYPE)
                .taxStateCode("MI")
                .paymentMethod("U1")
                .build();

        SVIOTransactions transactions = transactionsMapper.mapFromFlatFile(transactionInput, "", "CARSTR20230524092355.FIL");

        Contract contract = transactions.getContract();
        Assertions.assertEquals(transactionInput.getReferenceId(), contract.getInvestment().getFund().getReference().getId());
        Assertions.assertEquals(transactionInput.getFundId(), contract.getInvestment().getFund().getAdminNumber());
        Assertions.assertEquals(transactionInput.getAccountNumber(), contract.getPrimaryId());
        Assertions.assertEquals(transactionInput.getSubAccountNumber(), contract.getSuffix());

        Trade trade = transactions.getTrade();
        Assertions.assertEquals(transactionInput.getValuationDate(), trade.getTradeDate());

        Distributor distributor = transactions.getContract().getDistributor();
        Assertions.assertNotNull(distributor.getNumber());
        Assertions.assertEquals("U1", distributor.getNumber());

        Payout payout = transactions.getPayoutTransaction().getPayout();
        Assertions.assertNull(payout.getMethodCode());
    }

    @Test
    public void mapTransaction_marketAmountNegative_PayoutPaymentMethodNotNull_DistributorNumberNull() {
        TransactionInput transactionInput = TransactionInput.builder()
                .referenceId(REFERENCE_ID)
                .effectiveDate("20231120")
                .contractEffectiveDate("20231120")
                .settlementDate("20231120")
                .fundId(FUND_ID)
                .accountNumber(ACCOUNT_NUMBER)
                .subAccountNumber(SUBACCOUNT_NUMBER)
                .valuationDate(VALUATION_DATE)
                .transactionType(TRANSACTION_TYPE)
                .taxStateCode("MI")
                .paymentMethod("U1")
                .transactionMarketAmount(BigDecimal.valueOf(-10.5))
                .build();

        SVIOTransactions transactions = transactionsMapper.mapFromFlatFile(transactionInput, "", "CARSTR20230524092355.FIL");

        Contract contract = transactions.getContract();
        Assertions.assertEquals(transactionInput.getReferenceId(), contract.getInvestment().getFund().getReference().getId());
        Assertions.assertEquals(transactionInput.getFundId(), contract.getInvestment().getFund().getAdminNumber());
        Assertions.assertEquals(transactionInput.getAccountNumber(), contract.getPrimaryId());
        Assertions.assertEquals(transactionInput.getSubAccountNumber(), contract.getSuffix());

        Trade trade = transactions.getTrade();
        Assertions.assertEquals(transactionInput.getValuationDate(), trade.getTradeDate());

        Distributor distributor = transactions.getContract().getDistributor();
        Assertions.assertNull(distributor.getNumber());

        Payout payout = transactions.getPayoutTransaction().getPayout();
        Assertions.assertNotNull(payout.getMethodCode());
        Assertions.assertEquals("U1", payout.getMethodCode());
    }

    @Test
    public void mapTransaction_optionalFieldBlank_mapNull() {
        TransactionInput transactionInput = TransactionInput.builder()
                .referenceId(REFERENCE_ID)
                .effectiveDate("")
                .contractEffectiveDate("20231120")
                .settlementDate("20231120")
                .fundId(FUND_ID)
                .accountNumber(ACCOUNT_NUMBER)
                .subAccountNumber(SUBACCOUNT_NUMBER)
                .valuationDate(VALUATION_DATE)
                .transactionType(TRANSACTION_TYPE)
                .taxStateCode("MI")
                .paymentMethod("")
                .transactionMarketAmount(BigDecimal.valueOf(-10.5))
                .build();

        SVIOTransactions transactions = transactionsMapper.mapFromFlatFile(transactionInput, "", "CARSTR20230524092355.FIL");

        Transaction transaction = transactions.getTransaction();

        Assertions.assertNull(transaction.getEffectiveDate());
    }

    @Test
    public void mapTransaction_optionalMarketShares_mapNullForUnitCount() {
        TransactionInput transactionInput = TransactionInput.builder()
                .referenceId(REFERENCE_ID)
                .effectiveDate("")
                .contractEffectiveDate("20231120")
                .settlementDate("20231120")
                .fundId(FUND_ID)
                .accountNumber(ACCOUNT_NUMBER)
                .subAccountNumber(SUBACCOUNT_NUMBER)
                .valuationDate(VALUATION_DATE)
                .transactionType(TRANSACTION_TYPE)
                .taxStateCode("MI")
                .paymentMethod("")
                .transactionMarketAmount(TRANSACTION_MARKET_AMOUNT)
                .build();

        SVIOTransactions transactions = transactionsMapper.mapFromFlatFile(transactionInput, "", "CARSTR20230524092355.FIL");

        Investment investment = transactions.getContract().getInvestment();
        Assertions.assertNull(investment.getUnitCount());
    }
}
