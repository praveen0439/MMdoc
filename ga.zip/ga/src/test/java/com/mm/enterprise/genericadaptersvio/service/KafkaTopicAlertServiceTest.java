package com.mm.enterprise.genericadaptersvio.service;

import com.mm.enterprise.alert.info.Email;
import com.mm.enterprise.alert.info.InfoMessage;
import com.mm.enterprise.alert.info.Slack;
import com.mm.enterprise.alert.info.XMatters;
import com.mm.enterprise.genericadaptersvio.config.alert.AlertProperties;
import com.mm.enterprise.genericadaptersvio.config.alert.AlertRecipients;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.TopicPartition;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
public class KafkaTopicAlertServiceTest {

    AlertProperties alertProperties = new AlertProperties();

    @Mock
    private KafkaTemplate<String, Object> kafkaTemplate;

    @InjectMocks
    private KafkaTopicAlertService kafkaTopicAlertService;

    @BeforeEach
    void setup(){
        MockitoAnnotations.openMocks(this);

        AlertRecipients alertRecipients = new AlertRecipients();
        alertRecipients.setNotificationEmail("NotificationEmail");
        alertRecipients.setNotificationSubject("NotificationSubject");
        alertRecipients.setNotificationWebhook("NotificationWebhook");
        alertRecipients.setNotificationSlackChannel("NotificationSlackChannel");
        alertProperties.setRecipients(List.of(alertRecipients));
        alertProperties.setTopic("transactionsChunkJob");

        kafkaTopicAlertService = new KafkaTopicAlertService("appName",alertProperties,kafkaTemplate);
    }
    @Test
    public void testSendNotification() throws ExecutionException, InterruptedException, TimeoutException {
        InfoMessage alert = getInfoMessage();
        alert.setAppName("appName");

        SendResult<String, Object> sendResult = mock(SendResult.class);
        RecordMetadata recordMetadata = mock(RecordMetadata.class);
        when(recordMetadata.topic()).thenReturn("test");
        when(recordMetadata.partition()).thenReturn(0);
        when(recordMetadata.offset()).thenReturn(1L);
        when(sendResult.getRecordMetadata()).thenReturn(recordMetadata);

        CompletableFuture<SendResult<String, Object>> future = CompletableFuture.completedFuture(sendResult);
        when(kafkaTemplate.send(any(), any())).thenReturn(future);


        kafkaTopicAlertService.sendNotification("Message");

        verify(kafkaTemplate, times(1)).send(any(), any());
        verify(kafkaTemplate, times(1)).flush();
    }

    @Test
    public void testBuildAlertMessage() throws Exception {
        ReflectionTestUtils.invokeMethod(kafkaTopicAlertService, "buildAlertMessage", "testMsg", "testSubject", "test@email.com", "testChannel", "testwebhook", "testIconEmoji");
    }


    @NotNull
    private InfoMessage getInfoMessage() {
        String msg = "testMsg";
        String subject = "testSubject";
        String email = "test@email.com";
        String slackChannel = "testChannel";
        String webhook = "testwebhook";
        String iconEmoji = "testIconEmoji";
        InfoMessage alert = new InfoMessage();
        alert.setEmailList(List.of(Email.newBuilder()
                .setEmailAddresses(List.of(email))
                .setSubject(subject)
                .setMessage(msg)
                .build()));
        alert.setSlackList(List.of(Slack.newBuilder()
                .setChannel(slackChannel)
                .setWebhook(webhook)
                .setSubject(subject)
                .setMessage(msg)
                .setIconEmoji(iconEmoji)
                .build()));
        return alert;
    }
}
