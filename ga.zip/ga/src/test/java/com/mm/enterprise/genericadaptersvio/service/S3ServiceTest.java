package com.mm.enterprise.genericadaptersvio.service;

import com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions.UnknownS3Exception;
import com.mm.enterprise.genericadaptersvio.model.S3ObjectDetails;
import com.mm.enterprise.genericadaptersvio.util.LocalFileProcessor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import software.amazon.awssdk.awscore.exception.AwsErrorDetails;
import software.amazon.awssdk.awscore.exception.AwsServiceException;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.S3Exception;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

public class S3ServiceTest {

    @Mock
    S3Client s3Client;

    S3Service s3Service;

    S3ObjectDetails s3ObjectDetails;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
        s3Service = new S3Service(s3Client);
        s3ObjectDetails = new S3ObjectDetails("svio-dev", "source/main/transactions/svio.dat", "f35a57c2ffc90c5b1c2fd172842c7613", 33, new ArrayList<>());
    }

    @Test
    public void test_saveS3ObjectLocally_successfullySaved() {
        MockedStatic mockStatic = mockStatic(LocalFileProcessor.class);
        GetObjectResponse getObjectResponse = GetObjectResponse.builder()
                .acceptRanges("bytes")
                .lastModified(Instant.now())
                .contentLength(38L)
                .eTag("fab88ab08ad0dsadsadsad30c7320bb8")
                .contentType("text/plain")
                .serverSideEncryption("AES256")
                .metadata(new HashMap<>())
                .build();
        byte[] responseBytes = "0x546869732069732066726fasdbnjasnfjfnsafa4b726973686e61".getBytes(UTF_8);
        ResponseBytes<GetObjectResponse> getObjectResponseBytes = ResponseBytes.fromByteArray(getObjectResponse, responseBytes);

        when(s3Client.getObjectAsBytes(any(GetObjectRequest.class))).thenReturn(getObjectResponseBytes);

        s3Service.saveS3ObjectLocally(s3ObjectDetails);

        mockStatic.verify(() -> LocalFileProcessor.save(s3ObjectDetails, responseBytes));
    }

    @Test
    public void test_saveS3ObjectLocally_throwsS3Exception() {
        AwsErrorDetails awsDetails = AwsErrorDetails.builder().errorMessage("Exception for S3 bucket").build();
        AwsServiceException exception = S3Exception.builder().awsErrorDetails(awsDetails).build();
        when(s3Client.getObjectAsBytes(any(GetObjectRequest.class))).thenThrow(exception);

        assertThrows(RuntimeException.class, () -> s3Service.saveS3ObjectLocally(s3ObjectDetails));
    }
}
