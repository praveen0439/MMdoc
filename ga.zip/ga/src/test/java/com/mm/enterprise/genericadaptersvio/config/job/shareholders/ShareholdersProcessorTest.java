package com.mm.enterprise.genericadaptersvio.config.job.shareholders;

import com.mm.enterprise.genericadaptersvio.mapper.ShareHolderExtractMapper;
import com.mm.enterprise.genericadaptersvio.model.shareholderextract.ShareHolderExtractInputTrailer;
import com.mm.enterprise.genericadaptersvio.model.shareholderextract.ShareholderExtractInputRow;
import com.mm.enterprise.genericadaptersvio.processor.ShareHolderExtractProcessor;
import com.mm.enterprise.genericadaptersvio.util.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.kafka.core.KafkaTemplate;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;

@ExtendWith(MockitoExtension.class)
public class ShareholdersProcessorTest {
    @Mock
    private ShareHolderExtractMapper shareHolderExtractMapper;
    @Mock
    private StepExecution stepExecution;

    @Mock
    private KafkaTemplate<String, Object>  controlKafkaTemplate;

    @InjectMocks
    private ShareHolderExtractProcessor processor;

    @Test
    void givenShareholderInputRow_mapperForRowSuccessfullyCalled() {
        ShareHolderExtractInputTrailer inputTrailer = new ShareHolderExtractInputTrailer();
        final Map<String, JobParameter<?>> params = new HashMap<>();
        params.put(Constants.S3_BUCKET_KEY_PARAM, new JobParameter<>("test/test/shareholders.fil", String.class));
        //  set mock
        processor.beforeStep(stepExecution);
        Mockito.when(stepExecution.getJobParameters()).thenReturn(new JobParameters(params));
        JobExecution jobExecution = Mockito.mock(JobExecution.class);
        ExecutionContext executionContext = new ExecutionContext();
        Mockito.when(jobExecution.getExecutionContext()).thenReturn(executionContext);
        Mockito.when(stepExecution.getJobExecution()).thenReturn(jobExecution);

        ShareholderExtractInputRow inputRow = new ShareholderExtractInputRow();
        processor.process(inputRow);

        Mockito.verify(shareHolderExtractMapper, Mockito.times(1)).mapShareholderExtractRow(eq(inputRow), anyString(),anyString());
        Mockito.verify(shareHolderExtractMapper, Mockito.times(0)).mapShareholderExtractTrailer(eq(inputTrailer), anyString(),anyString());

    }

    @Test
    void givenShareholderTrailerInput_mapperForTrailerSuccessfullyCalled() {
        final Map<String, JobParameter<?>> params = new HashMap<>();
        params.put(Constants.S3_BUCKET_KEY_PARAM, new JobParameter<>("test/test/shareholders.fil", String.class));
        //  set mock
        processor.beforeStep(stepExecution);
        Mockito.when(stepExecution.getJobParameters()).thenReturn(new JobParameters(params));
        JobExecution jobExecution = Mockito.mock(JobExecution.class);
        ExecutionContext executionContext = new ExecutionContext();
        Mockito.when(jobExecution.getExecutionContext()).thenReturn(executionContext);
        Mockito.when(stepExecution.getJobExecution()).thenReturn(jobExecution);

        ShareholderExtractInputRow inputRow = new ShareholderExtractInputRow();
        ShareHolderExtractInputTrailer inputTrailer = new ShareHolderExtractInputTrailer();
        inputTrailer.setTransactionCount("10");

        processor.process(inputTrailer);

        Mockito.verify(shareHolderExtractMapper, Mockito.times(0)).mapShareholderExtractRow(eq(inputRow), anyString(),anyString());
        Mockito.verify(shareHolderExtractMapper, Mockito.times(1)).mapShareholderExtractTrailer(eq(inputTrailer), anyString(),anyString());
    }
}
