package com.mm.enterprise.genericadaptersvio.service;

import com.mm.enterprise.genericadaptersvio.model.JobParamsRequest;
import com.mm.enterprise.genericadaptersvio.model.S3ObjectDetails;
import com.mm.enterprise.genericadaptersvio.service.job.JobService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;

import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.batch.core.JobParameters;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;


@ExtendWith(MockitoExtension.class)
public class JobServiceTest {

    @InjectMocks
    private JobService jobService;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getJobParameters_returnJobParameters() {
        JobParamsRequest requestParams = JobParamsRequest.builder()
                .paramKey("key")
                .paramValue("value")
                .build();
        S3ObjectDetails s3ObjectDetails = s3ObjectDetails =
                new S3ObjectDetails("svio-dev", "source/main/transactions/svio.dat", "f35a57c2ffc90c5b1c2fd172842c7613", 33, List.of(requestParams));

        JobParameters result = jobService.getJobParameters(s3ObjectDetails, "file");

        assertNotNull(result);
        assertNotNull(result.getParameters());
        assertEquals("value", result.getParameters().get("key").getValue());
    }
}
