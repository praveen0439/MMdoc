package com.mm.enterprise.genericadaptersvio.config.job.transactionextract;

import businesscustomers.event.agreements.institutionalcontrol.completed.EventHeader;
import businesscustomers.event.agreements.institutionalcontrol.completed.EventSourceFileType;
import businesscustomers.event.agreements.institutionalcontrol.completed.SvioControlCompleted;
import businesscustomers.event.agreements.institutionaltransactiondetail.requested.*;
import com.mm.enterprise.genericadaptersvio.model.transactionextract.TransactionExtractInputRow;
import com.mm.enterprise.genericadaptersvio.model.transactionextract.TransactionExtractInputTrailer;
import com.mm.enterprise.genericadaptersvio.processor.TransactionExtractProcessor;
import com.mm.enterprise.genericadaptersvio.service.KafkaMessageService;
import com.mm.enterprise.genericadaptersvio.util.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.kafka.core.KafkaTemplate;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class TransactionExtractProcessorTest {

    public static final String TRANSACTION_TYPE_SUB = "000";
    public static final String REVERSE_DATE = "00000000";
    public static final String CLEAR_DATE = "00000000";

    public static final String SHARE_HOLDER_ACCOUNT_NUMBER = "000001550";
    public static final String SHARE_HOLDER_SUB_ACCOUNT_NUMBER = "01";
    public static final String DATE_OF_TRADE = "20230303";
    public static final String SEQUENCE_NUMBER = "00001";
    public static final String TRANSACTION_TYPE = "632";
    public static final String PURCHASE_SOURCE = "00";
    public static final String PAYMENT_METHOD = "U1";
    public static final String REVERSAL_FLAG = "1";
    public static final String PROCESSING_DATE = "20230911";
    public static final String FUND_NUMBER = "GEN155001";
    public static final double DOLLAR_AMOUNT = -476183.28;
    @Mock
    private KafkaTemplate<String, Object> controlKafkaTemplate;
    @Mock
    private KafkaMessageService kafkaMessageService;
    @Mock
    private StepExecution stepExecution;
    @InjectMocks
    private TransactionExtractProcessor transactionExtractProcessor;

    @Test
    void givenValidInputRow_ReturnValidAvroObject() throws Exception {
//    given
        final Map<String, JobParameter<?>> params = new HashMap<>();
        params.put(Constants.S3_BUCKET_KEY_PARAM, new JobParameter<>("test/test/test/test_20230909100257_20230909.txt", String.class));
        //  set mock
        transactionExtractProcessor.beforeStep(stepExecution);
        Mockito.when(stepExecution.getJobParameters()).thenReturn(new JobParameters(params));
        JobExecution jobExecution = Mockito.mock(JobExecution.class);
        ExecutionContext executionContext = new ExecutionContext();
        Mockito.when(jobExecution.getExecutionContext()).thenReturn(executionContext);
        Mockito.when(stepExecution.getJobExecution()).thenReturn(jobExecution);
        TransactionExtractInputRow transactionExtractInputRow = TransactionExtractInputRow.builder()
                .fundNumber(FUND_NUMBER)
                .shareHolderAccountNumber(SHARE_HOLDER_ACCOUNT_NUMBER)
                .shareHolderSubAccountNumber(SHARE_HOLDER_SUB_ACCOUNT_NUMBER)
                .dateOfTrade(DATE_OF_TRADE)
                .sequenceNumber(SEQUENCE_NUMBER)
                .transactionType(TRANSACTION_TYPE)
                .transactionTypeSub(TRANSACTION_TYPE_SUB)
                .dollarAmount(BigDecimal.valueOf(DOLLAR_AMOUNT))
                .clearDate(CLEAR_DATE)
                .purchaseSource(PURCHASE_SOURCE)
                .paymentMethod(PAYMENT_METHOD)
                .reverseDate(REVERSE_DATE)
                .reversalFlag(REVERSAL_FLAG)
                .processingDate(PROCESSING_DATE)
                .build();

//    when
        TransactionsExtractInitiated transactionsExtractInitiated = transactionExtractProcessor.process(transactionExtractInputRow);
        Metadata metadata = transactionsExtractInitiated.getEventHeader().getMetadata();
        assertEquals(TRANSACTION_TYPE_SUB, metadata.getTransactionSubType());
        assertEquals(REVERSE_DATE, metadata.getReverseDate());
        assertEquals("test_20230909100257_20230909.txt", metadata.getEventSourceFilename());
        assertEquals("20230909", metadata.getFileGeneratedDate());
        Contract contract = transactionsExtractInitiated.getContract();
        assertEquals(SHARE_HOLDER_ACCOUNT_NUMBER, contract.getPrimaryId());
        assertEquals(SHARE_HOLDER_SUB_ACCOUNT_NUMBER, contract.getSuffix());
        Investment investment = contract.getInvestment();
        assertEquals(String.valueOf(DOLLAR_AMOUNT), investment.getValue());
        Fund fund = investment.getFund();
        assertEquals(FUND_NUMBER, fund.getAdminNumber());
        Distributor distributor = contract.getDistributor();
        assertEquals(PURCHASE_SOURCE, distributor.getNumber());
        Trade trade = transactionsExtractInitiated.getTrade();
        assertEquals(DATE_OF_TRADE, trade.getTradeDate());
        assertEquals(CLEAR_DATE, trade.getSettlementDate());
        Transaction transaction = transactionsExtractInitiated.getTransaction();
        assertEquals(SEQUENCE_NUMBER, transaction.getSequenceNumber());
        assertEquals(TRANSACTION_TYPE, transaction.getTypeCode());
        assertTrue(transaction.getReversalIndicator());
        PayoutTransaction payoutTransaction = transactionsExtractInitiated.getPayoutTransaction();
        Payout payout = payoutTransaction.getPayout();
        assertEquals(PROCESSING_DATE, payout.getPostingDate());
        assertEquals(PAYMENT_METHOD, payout.getMethodCode());

//    test false reversal flag
        transactionExtractInputRow.setReversalFlag("0");
        assertFalse(transactionExtractProcessor.process(transactionExtractInputRow).getTransaction().getReversalIndicator());
    }

    @Captor
    ArgumentCaptor<SvioControlCompleted> svioControlCompletedCaptor;

    @Test
    void givenValidTrailer_ReturnValidCompletedAvroObject() throws Exception {
//    given
        final Map<String, JobParameter<?>> params = new HashMap<>();
        params.put(Constants.S3_BUCKET_KEY_PARAM, new JobParameter<>("test/test/test/test_20230909100257_20230909.txt", String.class));
        //  set mock
        transactionExtractProcessor.beforeStep(stepExecution);
        Mockito.when(stepExecution.getJobParameters()).thenReturn(new JobParameters(params));
        JobExecution jobExecution = Mockito.mock(JobExecution.class);
        ExecutionContext executionContext = new ExecutionContext();
        Mockito.when(jobExecution.getExecutionContext()).thenReturn(executionContext);
        Mockito.when(stepExecution.getJobExecution()).thenReturn(jobExecution);
        TransactionExtractInputTrailer transactionExtractInputTrailer = TransactionExtractInputTrailer.builder()
                .recordCount("00000000038")
                .totalDollarAmount(BigDecimal.valueOf(3456.73))
                .build();
        TransactionsExtractInitiated transactionsExtractInitiated = transactionExtractProcessor.process(transactionExtractInputTrailer);
        assertNull(transactionsExtractInitiated);
        Mockito.verify(kafkaMessageService).sendMessage(Mockito.any(), svioControlCompletedCaptor.capture(), Mockito.any());
        SvioControlCompleted svioControlCompleted = svioControlCompletedCaptor.getValue();
        EventHeader eventHeader = svioControlCompleted.getEventHeader();
        assertEquals("3456.73", eventHeader.getEventBatchTotalAmt());
        assertEquals("38", eventHeader.getEventBatchRecordCountTotal());
        assertNotNull(eventHeader.getEventGeneratedDateTime());
        businesscustomers.event.agreements.institutionalcontrol.completed.Metadata metadata = eventHeader.getMetadata();
        assertEquals("20230909", metadata.getEventSourceValuationDate());
        assertEquals("test_20230909100257_20230909.txt", metadata.getEventSourceFilename());
        assertEquals(EventSourceFileType.TRANSACTIONSEXTRACT, metadata.getEventSourceFileType());
    }

}