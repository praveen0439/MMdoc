package com.mm.enterprise.genericadaptersvio.controller;

import com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions.NoJobFoundException;
import com.mm.enterprise.genericadaptersvio.model.S3ObjectDetails;
import com.mm.enterprise.genericadaptersvio.service.S3Service;
import com.mm.enterprise.genericadaptersvio.service.job.JobService;
import com.mm.enterprise.genericadaptersvio.util.Constants;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.NoSuchJobExecutionException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ActiveProfiles("test")
@TestPropertySource("/application-test.")
@ExtendWith(MockitoExtension.class)
public class JobControllerTest {

    @Mock
    S3Service s3Service;
    @Mock
    JobService jobService;
    JobController jobController;
    S3ObjectDetails s3ObjectDetails;

    @BeforeEach
    void setup(){
        jobController = new JobController(jobService, s3Service);

        s3ObjectDetails= new S3ObjectDetails("svio-dev","source/main/transactions/svio.dat","f35a57c2ffc90c5b1c2fd172842c7613",33,new ArrayList<>());
    }

    @Test
    void testStartJob(){
        JobParameters jobParameters = getJobParameters(s3ObjectDetails);
        String localFlatFilePath = "/tmp/data/source-main-transactions-svio.dat";
        Mockito.when(jobService.getJobParameters(s3ObjectDetails, localFlatFilePath)).thenReturn(jobParameters);
        Mockito.when(s3Service.saveS3ObjectLocally(s3ObjectDetails)).thenReturn(localFlatFilePath);

        jobController.startJob(s3ObjectDetails, "transactionsChunkJob");
        verify(jobService, times(1)).startJob("transactionsChunkJob", jobParameters);
    }

    @NotNull
    public static JobParameters getJobParameters(S3ObjectDetails s3ObjectDetails) {
        Map<String, JobParameter<?>> params = new HashMap<>();
        params.put(Constants.INPUT_FILE, new JobParameter("", String.class));
        params.put(Constants.S3_BUCKET_NAME_PARAM, new JobParameter(s3ObjectDetails.bucketName(), String.class));
        params.put(Constants.S3_BUCKET_KEY_PARAM, new JobParameter(s3ObjectDetails.bucketKey(), String.class));
        params.put(Constants.S3_BUCKET_E_TAG_PARAM, new JobParameter(s3ObjectDetails.bucketETag(), String.class));
        params.put(Constants.S3_BUCKET_SIZE, new JobParameter(s3ObjectDetails.bucketSize(), String.class));
        JobParameters jobParameters = new JobParameters(params);

        return jobParameters;
    }
}
