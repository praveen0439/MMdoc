package com.mm.enterprise.genericadaptersvio.config.job.control;

import com.mm.enterprise.genericadaptersvio.mapper.ControlDisbursementsMapper;
import com.mm.enterprise.genericadaptersvio.model.control.ControlInput;
import com.mm.enterprise.genericadaptersvio.processor.ControlDisbursementsProcessor;
import com.mm.enterprise.genericadaptersvio.util.Constants;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.*;

@ExtendWith(MockitoExtension.class)
public class ControlDisbursementProcessorTest {

    @Mock
    private ControlDisbursementsMapper controlDisbursementsMapper;

    @Mock
    private StepExecution stepExecution;

    @InjectMocks
    private ControlDisbursementsProcessor controlDisbursementsProcessor;

    @Test
    void givenValidControlInput_mapperSuccessfullyCalled(){
        ControlInput input = new ControlInput();
        final Map<String, JobParameter<?>> params = new HashMap<>();
        params.put(Constants.S3_BUCKET_KEY_PARAM, new JobParameter<>("test/test/control.fil", String.class));
        //  set mock
        controlDisbursementsProcessor.beforeStep(stepExecution);
        Mockito.when(stepExecution.getJobParameters()).thenReturn(new JobParameters(params));
        JobExecution jobExecution = Mockito.mock(JobExecution.class);
        ExecutionContext executionContext = new ExecutionContext();
        Mockito.when(jobExecution.getExecutionContext()).thenReturn(executionContext);
        Mockito.when(stepExecution.getJobExecution()).thenReturn(jobExecution);

        controlDisbursementsProcessor.process(input);

        Mockito.verify(controlDisbursementsMapper, Mockito.times(1)).mapFromFlatFile(eq(input), anyString(),anyString());
    }
}
