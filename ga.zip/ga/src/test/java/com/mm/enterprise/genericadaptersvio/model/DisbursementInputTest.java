package com.mm.enterprise.genericadaptersvio.model;

import com.mm.enterprise.genericadaptersvio.model.disbursements.DisbursementsInput;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class DisbursementInputTest {
    DisbursementsInput disbursementsInput = new DisbursementsInput();

    @Test
    public void testDis(){
        disbursementsInput.setPooledFundNumber("GAG");
        disbursementsInput.setFundID("GEN155001");
        disbursementsInput.setMasterContractNumber("000001550");
        disbursementsInput.setSubPlanNumber("01");
        disbursementsInput.setTradeDate("20230523");
        disbursementsInput.setProcessing_postingDate("20230524");
        disbursementsInput.setSettlementDate("20230524");
        disbursementsInput.setMarketAmount(new BigDecimal("782044.55"));
        disbursementsInput.setInvestmentContractType("GA");
        disbursementsInput.setPaymentMethod("U1");
        disbursementsInput.setTaxStateCode("MA");
        disbursementsInput.setEffectiveDate("20230524");
        disbursementsInput.setReversalFlag("N");
        disbursementsInput.setReversalReason("00");
        disbursementsInput.setWireState("A");
        disbursementsInput.setPayeeName("A");
        disbursementsInput.setInstructionLine1("A");
        disbursementsInput.setInstructionLine2("A");
        disbursementsInput.setInstructionLine3("A");
        disbursementsInput.setInstructionLine4("A");
        disbursementsInput.setInstructionLine5("A");
        disbursementsInput.setInstructionLine6("A");
        disbursementsInput.setBankName("A");
        disbursementsInput.setBankCity("A");
        disbursementsInput.setRecordKeeper("000000");

        assertEquals("GAG",disbursementsInput.getPooledFundNumber());
        assertEquals("GEN155001",disbursementsInput.getFundID());
        assertEquals("000001550",disbursementsInput.getMasterContractNumber());
        assertEquals("01",disbursementsInput.getSubPlanNumber());
        assertEquals("20230523",disbursementsInput.getTradeDate());
        assertEquals("20230524",disbursementsInput.getProcessing_postingDate());
        assertEquals("20230524",disbursementsInput.getSettlementDate());
        assertEquals(new BigDecimal("782044.55"),disbursementsInput.getMarketAmount());
        assertEquals("GA",disbursementsInput.getInvestmentContractType());
        assertEquals("U1",disbursementsInput.getPaymentMethod());
        assertEquals("MA",disbursementsInput.getTaxStateCode());
        assertEquals("20230524",disbursementsInput.getEffectiveDate());
        assertEquals("N",disbursementsInput.getReversalFlag());
        assertEquals("00",disbursementsInput.getReversalReason());
        assertEquals("A",disbursementsInput.getWireState());
        assertEquals("A",disbursementsInput.getPayeeName());
        assertEquals("A",disbursementsInput.getInstructionLine1());
        assertEquals("A",disbursementsInput.getInstructionLine2());
        assertEquals("A",disbursementsInput.getInstructionLine3());
        assertEquals("A",disbursementsInput.getInstructionLine4());
        assertEquals("A",disbursementsInput.getInstructionLine5());
        assertEquals("A",disbursementsInput.getInstructionLine6());
        assertEquals("A",disbursementsInput.getBankName());
        assertEquals("A",disbursementsInput.getBankCity());
        assertEquals("000000",disbursementsInput.getRecordKeeper());
    }
}
