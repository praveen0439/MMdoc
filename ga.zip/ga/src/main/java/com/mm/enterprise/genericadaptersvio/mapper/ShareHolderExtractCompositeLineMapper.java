package com.mm.enterprise.genericadaptersvio.mapper;

import com.mm.enterprise.genericadaptersvio.model.shareholderextract.ShareHolderExtractInputTrailer;
import com.mm.enterprise.genericadaptersvio.model.shareholderextract.ShareholderExtractInput;
import com.mm.enterprise.genericadaptersvio.model.shareholderextract.ShareholderExtractInputRow;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.stereotype.Component;

import static com.mm.enterprise.genericadaptersvio.util.Constants.IS_TRAILER_PRESENT;

@Slf4j
@Component
public class ShareHolderExtractCompositeLineMapper implements LineMapper<ShareholderExtractInput>, StepExecutionListener {
    private static final String[] SHAREHOLDERS_FLAT_FILE_COLUMN_NAMES = {
            "fundNumber", "shareHolderAccountNumber", "shareHolderSubAccountNumber", "dealerNumber",
            "accountType", "dividendOption", "capitalGainsOption", "accountStatus", "accountOpenDate",
            "accountCloseDate", "bookShares"};

    private static final String[] SHAREHOLDERS_FLAT_FILE_TRAILER_COLUMN_NAMES = {
            "transactionCount", "bookSharesSum"};
    public static final String TRAILER_PREFIX = "XF0000SH";

    private final FieldSetMapper<ShareholderExtractInput> rowFieldSetMapper;
    private final FixedLengthTokenizer rowTokenizer;
    private final FieldSetMapper<ShareholderExtractInput> trailerFieldSetMapper;
    private final FixedLengthTokenizer trailerTokenizer;
    private StepExecution stepExecution;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }

    public ShareHolderExtractCompositeLineMapper() {
//      row mapper
        BeanWrapperFieldSetMapper<ShareholderExtractInput> rowMapper = new BeanWrapperFieldSetMapper<>();
        rowMapper.setTargetType(ShareholderExtractInputRow.class);
        this.rowFieldSetMapper = rowMapper;
        this.rowTokenizer = new FixedLengthTokenizer();
        this.rowTokenizer.setColumns(
                new Range(1, 10),
                new Range(11, 19),
                new Range(20, 21),
                new Range(65, 70),
                new Range(93, 94),
                new Range(95, 96),
                new Range(97, 98),
                new Range(103, 103),
                new Range(120, 127),
                new Range(128, 135),
                new Range(171, 189)
        );
        this.rowTokenizer.setNames(SHAREHOLDERS_FLAT_FILE_COLUMN_NAMES);
        this.rowTokenizer.setStrict(false);

//      trailer mapper
        BeanWrapperFieldSetMapper<ShareholderExtractInput> trailerMapper = new BeanWrapperFieldSetMapper<>();
        trailerMapper.setTargetType(ShareHolderExtractInputTrailer.class);
        this.trailerFieldSetMapper = trailerMapper;
        this.trailerTokenizer = new FixedLengthTokenizer();
        this.trailerTokenizer.setColumns(
                new Range(27, 35),
                new Range(36, 55)
        );
        this.trailerTokenizer.setNames(SHAREHOLDERS_FLAT_FILE_TRAILER_COLUMN_NAMES);
        this.trailerTokenizer.setStrict(false);
    }

    @Override
    public ShareholderExtractInput mapLine(String line, int lineNumber) throws Exception {
        if (line.startsWith(TRAILER_PREFIX)) {
            this.stepExecution.getJobExecution().getExecutionContext().putString(IS_TRAILER_PRESENT, String.valueOf(true));
            return trailerFieldSetMapper.mapFieldSet(trailerTokenizer.tokenize(line));
        }

        return rowFieldSetMapper.mapFieldSet(rowTokenizer.tokenize(line));
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        return stepExecution.getExitStatus();
    }
}

