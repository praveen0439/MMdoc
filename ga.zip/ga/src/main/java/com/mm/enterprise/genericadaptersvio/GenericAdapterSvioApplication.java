package com.mm.enterprise.genericadaptersvio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenericAdapterSvioApplication {
    public static void main(String[] args) {
        SpringApplication.run(GenericAdapterSvioApplication.class, args);
    }
}