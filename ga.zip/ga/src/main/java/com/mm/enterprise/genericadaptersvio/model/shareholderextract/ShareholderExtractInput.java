package com.mm.enterprise.genericadaptersvio.model.shareholderextract;

public interface ShareholderExtractInput {}
