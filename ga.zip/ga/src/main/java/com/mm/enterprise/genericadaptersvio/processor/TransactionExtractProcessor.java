package com.mm.enterprise.genericadaptersvio.processor;

import static businesscustomers.event.agreements.institutionalcontrol.completed.EventHeader.*;
import static com.mm.enterprise.genericadaptersvio.util.Constants.*;
import static com.mm.enterprise.genericadaptersvio.util.ItemProcessorHelper.getEventBatchGroupId;

import businesscustomers.event.agreements.institutionalcontrol.completed.EventSourceFileType;
import businesscustomers.event.agreements.institutionalcontrol.completed.SvioControlCompleted;
import businesscustomers.event.agreements.institutionaltransactiondetail.requested.Contract;
import businesscustomers.event.agreements.institutionaltransactiondetail.requested.Distributor;
import businesscustomers.event.agreements.institutionaltransactiondetail.requested.EventHeader;
import businesscustomers.event.agreements.institutionaltransactiondetail.requested.Fund;
import businesscustomers.event.agreements.institutionaltransactiondetail.requested.Investment;
import businesscustomers.event.agreements.institutionaltransactiondetail.requested.Metadata;
import businesscustomers.event.agreements.institutionaltransactiondetail.requested.Payout;
import businesscustomers.event.agreements.institutionaltransactiondetail.requested.PayoutTransaction;
import businesscustomers.event.agreements.institutionaltransactiondetail.requested.Trade;
import businesscustomers.event.agreements.institutionaltransactiondetail.requested.Transaction;
import businesscustomers.event.agreements.institutionaltransactiondetail.requested.TransactionsExtractInitiated;
import com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions.AppException;
import com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions.InvalidJobException;
import com.mm.enterprise.genericadaptersvio.model.transactionextract.TransactionExtractInput;
import com.mm.enterprise.genericadaptersvio.model.transactionextract.TransactionExtractInputRow;
import com.mm.enterprise.genericadaptersvio.model.transactionextract.TransactionExtractInputTrailer;
import com.mm.enterprise.genericadaptersvio.service.KafkaMessageService;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class TransactionExtractProcessor implements ItemProcessor<TransactionExtractInput, TransactionsExtractInitiated>, StepExecutionListener {

    private final KafkaTemplate<String, Object> controlKafkaTemplate;
    private final KafkaMessageService kafkaMessageService;
    private StepExecution stepExecution;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }

    @Override
    public TransactionsExtractInitiated process(TransactionExtractInput item) throws Exception {
        final String eventBatchGroupId = getEventBatchGroupId(stepExecution);

        String bucketKey = stepExecution.getJobParameters().getString(S3_BUCKET_KEY_PARAM);
        if (bucketKey == null) {
            throw new InvalidJobException("The parameter " + S3_BUCKET_KEY_PARAM + " cannot be null!");
        }
        String[] strings = bucketKey.split("/");
        String sourceFileName = strings[strings.length - 1];
        if (item instanceof TransactionExtractInputRow o) {
            return createTransactionsExtractInitiated(sourceFileName, o, eventBatchGroupId);
        }
        if (item instanceof TransactionExtractInputTrailer o) {
            SvioControlCompleted svioControlCompleted = createSvioControlCompleted(sourceFileName, o, eventBatchGroupId);
            kafkaMessageService.sendMessage(null, svioControlCompleted, controlKafkaTemplate);
        }
        return null;
    }

    private TransactionsExtractInitiated createTransactionsExtractInitiated(
            String sourceFileName, TransactionExtractInputRow o, String eventBatchGroupId) {
        LocalDateTime currentDateTime = LocalDateTime.now(ZoneId.of(ZONE_ID_EST));
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATETIME_FORMAT);
        DateTimeFormatter dateformatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
        final String eventCorrelationId = UUID.randomUUID().toString();
        return TransactionsExtractInitiated.newBuilder()
                .setEventHeader(EventHeader.newBuilder()
                        .setMetadata(Metadata.newBuilder()
                                .setTransactionSubType(o.getTransactionTypeSub().trim())
                                .setReverseDate(checkOptionalValues(o.getReverseDate().trim()))
                                .setEventSourceFilename(sourceFileName)
                                .setFileGeneratedDate(sourceFileName.split("_")[1].substring(0, 8))
                                .setProcessedDate(LocalDate.now())
                                .build())
                        .setEventType(REQUEST_EVENT_TYPE)
                        .setEventSubtype(EVENT_SUBTYPE_TRANSACTIONEXTRACT)
                        .setEventDateTime(currentDateTime.format(dateformatter))
                        .setEventGeneratedDateTime(currentDateTime.format(dateTimeFormatter))
                        .setEventCorrelationId(eventCorrelationId)
                        .setEventRequestId(eventCorrelationId)
                        .setEventSourceDescription(EVENT_SOURCE_DESCRIPTION_TRANSACTIONEXTRACT)
                        .setEventSource(EVENT_SOURCE)
                        .setEventInitiatorDescription(EVENT_INITIATOR_DESC_TRANSACTIONEXTRACT)
                        .setEventInitiator(GENERIC_ADAPTER_SVIO)
                        .setEventBatchGroupId(eventBatchGroupId)
                        .build())
                .setContract(Contract.newBuilder()
                        .setPrimaryId(o.getShareHolderAccountNumber().trim())
                        .setSuffix(o.getShareHolderSubAccountNumber().trim())
                        .setInvestment(Investment.newBuilder()
                                .setFund(Fund.newBuilder()
                                        .setAdminNumber(o.getFundNumber().trim())
                                        .build())
                                .setValue(o.getDollarAmount().toString())
                                .build())
                        .setDistributor(Distributor.newBuilder()
                                .setNumber(checkOptionalValues(o.getPurchaseSource().trim()))
                                .build())
                        .build())
                .setTrade(Trade.newBuilder()
                        .setTradeDate(o.getDateOfTrade().trim())
                        .setSettlementDate(o.getClearDate().trim())
                        .build())
                .setTransaction(Transaction.newBuilder()
                        .setSequenceNumber(o.getSequenceNumber().trim())
                        .setTypeCode(o.getTransactionType().trim())
                        .setReversalIndicator(
                                o.getReversalFlag().trim().equals("") ? null : mapReversalIndicator(o.getReversalFlag().trim()))
                        .build())
                .setPayoutTransaction(PayoutTransaction.newBuilder()
                        .setPayout(Payout.newBuilder()
                                .setPostingDate(checkOptionalValues(o.getProcessingDate().trim()))
                                .setMethodCode(checkOptionalValues(o.getPaymentMethod().trim()))
                                .build())
                        .build())
                .build();
    }

    private static SvioControlCompleted createSvioControlCompleted(String sourceFileName, TransactionExtractInputTrailer o, String eventBatchGroupId) {
        String valuationdate = sourceFileName.split("_")[2].substring(0, 8);
        String filedate = sourceFileName.split("_")[1].substring(0, 8);
        String filetime = sourceFileName.split("_")[1].substring(8, 14);

        final String eventCorrelationId = UUID.randomUUID().toString();
        LocalDateTime currentDateTime = LocalDateTime.now(ZoneId.of(ZONE_ID_EST));
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATETIME_FORMAT);

        return SvioControlCompleted.newBuilder()
                .setEventHeader(newBuilder()
                        .setEventBatchGroupId(eventBatchGroupId)
                        .setEventBatchTotalAmt(o.getTotalDollarAmount().toString())
                        .setEventBatchRecordCountTotal(removeLeadingZeroes(o))
                        .setEventCorrelationId(eventCorrelationId)
                        .setEventSource(EVENT_SOURCE)
                        .setEventSourceDescription(EVENT_SUBTYPE_TRANSACTIONEXTRACT)
                        .setEventGeneratedDateTime(currentDateTime.format(dateTimeFormatter))
                        .setEventType(REQUEST_EVENT_TYPE)
                        .setEventInitiatorDescription(EVENT_INITIATOR_DESC_TRANSACTIONEXTRACT)
                        .setEventInitiator(GENERIC_ADAPTER_SVIO)
                        .setMetadata(businesscustomers.event.agreements.institutionalcontrol.completed.Metadata.newBuilder()
                                .setEventSourceReferencedFilename("")
                                .setEventSourceRunDate(filedate)
                                .setEventSourceRunTime(filetime)
                                .setEventSourceValuationDate(valuationdate)
                                .setEventSourceFilename(sourceFileName)
                                .setEventSourceFileType(EventSourceFileType.TRANSACTIONSEXTRACT)
                                .setProcessedDate(LocalDate.now())
                                .build())
                        .build())
                .build();
    }

    private static String removeLeadingZeroes(TransactionExtractInputTrailer o) {
        String recordCount = o.getRecordCount();
        int i = 0;
        while (i < recordCount.length() && recordCount.charAt(i) == '0') {
            i++;
        }
        return new StringBuffer(recordCount).replace(0, i, "").toString();
    }

    private Boolean mapReversalIndicator(String reversalFlag) {
        if ("1".equals(reversalFlag)) {
            return Boolean.TRUE;
        }
        if ("0".equals(reversalFlag)) {
            return Boolean.FALSE;
        }
        throw new AppException("Invalid reversal indicator value: " + reversalFlag);
    }

    private String checkOptionalValues(String value) {
        if ("".equals(value)) {
            return null;
        }
        return value;
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        stepExecution.getJobExecution().getExecutionContext().putLong(WRITE_COUNT, stepExecution.getWriteCount());
        return stepExecution.getExitStatus();
    }
}
