package com.mm.enterprise.genericadaptersvio.util;

import org.springframework.batch.item.file.transform.DefaultFieldSet;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.batch.item.file.transform.LineTokenizer;

public class SingleColumnTokenizer implements LineTokenizer {
    @Override
    public FieldSet tokenize(String line) {
        String[] tokens = new String[]{line};
        String[] names = new String[]{"fileName"};

        return new DefaultFieldSet(tokens, names);
    }
}
