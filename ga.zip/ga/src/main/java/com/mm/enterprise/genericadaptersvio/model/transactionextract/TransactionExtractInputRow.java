package com.mm.enterprise.genericadaptersvio.model.transactionextract;

import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TransactionExtractInputRow implements TransactionExtractInput {
  @NotEmpty(message = "fundNumber is required!")
  @Size(max = 10, message = "fundNumber length should not be greater than 10 characters!")
  private String fundNumber;
  @NotEmpty(message = "ShareHolder account number is required!")
  @Size(max = 9, message = "ShareHolder length should not be greater than 9 characters!")
  private String shareHolderAccountNumber;
  @NotEmpty(message = "ShareHolderSubAccountNumber sub account number is required!")
  @Size(max = 2, message = "ShareHolderSubAccountNumber length should not be greater than 2 characters!")
  private String shareHolderSubAccountNumber;
  @NotEmpty(message = "DateOfTrade is required!")
  @Size(max = 8, message = "DateOfTrade length should not be greater than 8 characters!")
  @Pattern(regexp = "((19|2[0-9][0-9]{2})(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01]))",
      message = "dateOfTrade should respect the following pattern: yyyymmdd")
  private String dateOfTrade;
  @NotEmpty(message = "SequenceNumber is required!")
  @Size(max = 5, message = "SequenceNumber length should not be greater than 5 characters!")
  private String sequenceNumber;
  @NotEmpty(message = "TransactionType is required!")
  @Size(max = 3, message = "TransactionType length should not be greater than 3 characters!")
  private String transactionType;
  @NotEmpty(message = "TransactionTypeSub is required!")
  @Size(max = 3, message = "TransactionTypeSub length should not be greater than 3 characters!")
  private String transactionTypeSub;
  private String reversalFlag;
  @NotNull(message = "dollarAmount is required!")
  @Digits(integer = 16, fraction = 2, message = "dollarAmount decimal format should be 9999999999999999.99 or -999999999999999.99")
  private BigDecimal dollarAmount;
  private String processingDate;
  private String reverseDate;
  @NotEmpty(message = "clearDate is required!")
  @Size(max = 8, message = "clearDate length should not be greater than 8 characters!")
  private String clearDate;
  private String purchaseSource;
  private String paymentMethod;
}
