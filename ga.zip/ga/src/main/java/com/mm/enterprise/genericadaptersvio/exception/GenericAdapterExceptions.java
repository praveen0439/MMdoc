package com.mm.enterprise.genericadaptersvio.exception;

public final class GenericAdapterExceptions {
    private GenericAdapterExceptions() {
    }

    public static class AppException extends RuntimeException {

        public AppException(String message) {
            super(message);
            initCause(new RuntimeException(message));
        }
    }

    public static class NoJobFoundException extends RuntimeException {

        public NoJobFoundException(String message) {
            super(message);
            initCause(new RuntimeException(message));
        }
    }

    public static class LocalFolderException extends AppException {

        public LocalFolderException(String message) {
            super(message);
            initCause(new RuntimeException(message));
        }
    }

    public static class LocalFileWriteException extends AppException {

        public LocalFileWriteException(String message) {
            super(message);
            initCause(new RuntimeException(message));
        }
    }

    public static class UnknownS3Exception extends AppException {

        public UnknownS3Exception(String message) {
            super(message);
            initCause(new RuntimeException(message));
        }
    }

    public static class InvalidJobException extends AppException {

        public InvalidJobException(String message) {
            super(message);
            initCause(new RuntimeException(message));
        }
    }

    public static class EmptyTransactionsInput extends RuntimeException {

        public EmptyTransactionsInput(String message) {
            super(message);
            initCause(new RuntimeException(message));
        }
    }

    public static class ThreadSleepException extends RuntimeException {
        public ThreadSleepException(String jobName, Exception cause) {
            super("Multiple instances of the same job were running - error %s for job %s"
                            .formatted(cause.getMessage(), jobName),
                    cause);
        }
    }

}
