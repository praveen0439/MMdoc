package com.mm.enterprise.genericadaptersvio.processor;

import businesscustomers.event.agreements.institutionaltransactions.requested.SVIOTransactions;
import com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions.InvalidJobException;
import com.mm.enterprise.genericadaptersvio.mapper.TransactionsMapper;
import com.mm.enterprise.genericadaptersvio.model.transaction.TransactionInput;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.mm.enterprise.genericadaptersvio.util.Constants.S3_BUCKET_KEY_PARAM;
import static com.mm.enterprise.genericadaptersvio.util.ItemProcessorHelper.getEventBatchGroupId;
import static com.mm.enterprise.genericadaptersvio.util.ItemProcessorHelper.updateWriteCount;

@Component
@RequiredArgsConstructor
@Slf4j(topic = "logger")
public class TransactionProcessor implements ItemProcessor<TransactionInput, SVIOTransactions>, StepExecutionListener {
    private StepExecution stepExecution;

    @Autowired
    private TransactionsMapper transactionsMapper;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }


    @Override
    public SVIOTransactions process(TransactionInput item) throws Exception {
        log.debug("Starting processing for Transactions");
        final String eventBatchGroupId = getEventBatchGroupId(stepExecution);

        String bucketKey = stepExecution.getJobParameters().getString(S3_BUCKET_KEY_PARAM);
        if (bucketKey == null) {
            throw new InvalidJobException("The parameter " + S3_BUCKET_KEY_PARAM + " cannot be null!");
        }
        String[] strings = bucketKey.split("/");
        String inputFile = strings[strings.length - 1];

        return transactionsMapper.mapFromFlatFile(item, eventBatchGroupId, inputFile);
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        updateWriteCount(stepExecution);
        return stepExecution.getExitStatus();
    }
}
