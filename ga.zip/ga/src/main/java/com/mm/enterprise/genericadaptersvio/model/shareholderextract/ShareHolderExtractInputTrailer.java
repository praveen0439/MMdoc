package com.mm.enterprise.genericadaptersvio.model.shareholderextract;

import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ShareHolderExtractInputTrailer implements ShareholderExtractInput {
  @NotEmpty(message = "transactionCount is required!")
  @Size(max = 9, message = "transactionCount length should not be greater than 9 characters!")
  private String transactionCount;

  @NotNull(message = "bookShares is required!")
  @Digits(integer = 15, fraction = 4, message = "bookShares decimal format should be 999999999999999.99 or -999999999999999.99")
  private BigDecimal bookSharesSum;
}
