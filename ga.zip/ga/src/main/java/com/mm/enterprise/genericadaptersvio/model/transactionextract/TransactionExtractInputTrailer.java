package com.mm.enterprise.genericadaptersvio.model.transactionextract;

import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TransactionExtractInputTrailer implements TransactionExtractInput {
  @NotNull(message = "dollarAmount is required!")
  @Digits(integer = 16, fraction = 2, message = "dollarAmount decimal format should be 9999999999999999.99 or -999999999999999.99")
  private BigDecimal totalDollarAmount;
  @NotEmpty
  @Size(max = 11, message = "recordCount length should not be greater than 11 characters!")
  private String recordCount;
}
