package com.mm.enterprise.genericadaptersvio.config.job.tasklet;

import businesscustomers.event.agreements.institutionalcontrol.done.EventHeader;
import businesscustomers.event.agreements.institutionalcontrol.done.Metadata;
import businesscustomers.event.agreements.institutionalcontrol.done.SvioDone;
import com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions.AppException;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.encoder.org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;
import java.io.BufferedReader;
import java.io.FileReader;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static com.mm.enterprise.genericadaptersvio.util.Constants.*;

@Slf4j
@Component
@RequiredArgsConstructor
public class DoneTasklet implements Tasklet, StepExecutionListener {

    private final KafkaTemplate<String, Object> doneKafkaTemplate;
    private StepExecution stepExecution;

    @NotNull
    @Value(value = "${generic.adapter.svio.done.topic}")
    private String doneTopic;

    @Override
    public void beforeStep(@NonNull StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }

    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {
        final List<String> transactionsControlFiles = new ArrayList<>();
        final List<String> transactionsFilFiles = new ArrayList<>();
        final List<String> disbursementsControlFiles = new ArrayList<>();
        final List<String> disbursementsFilFiles = new ArrayList<>();
        final List<String> shareHoldersExtractFiles = new ArrayList<>();
        final List<String> transactionsExtractFiles = new ArrayList<>();
        Long lineCount = 0L;
        final String bucketKey = stepContribution.getStepExecution().getJobParameters().getString(S3_BUCKET_KEY_PARAM);
        String[] strings = Objects.requireNonNull(bucketKey).split("/");
        String sourceFileName = strings[strings.length - 1];
        String inputFile = chunkContext.getStepContext().getStepExecution().getJobExecution().getJobParameters().getString(INPUT_FILE);

        try (BufferedReader br = new BufferedReader(new FileReader(Objects.requireNonNull(inputFile)))) {
            String line;
            while ((line = br.readLine()) != null) {
                lineCount++;
                if (StringUtils.containsIgnoreCase(line, SHAREHOLDER)) {
                    shareHoldersExtractFiles.add(line);
                    continue;
                }

                if (StringUtils.containsIgnoreCase(line, TRANSACTION)) {
                    transactionsExtractFiles.add(line);
                    continue;
                }

                if (StringUtils.startsWithIgnoreCase(line, CARSTR)) {
                    if (StringUtils.endsWithIgnoreCase(line, FIL)) {
                        transactionsFilFiles.add(line);
                        continue;
                    } else {
                        transactionsControlFiles.add(line);
                        continue;
                    }
                }

                if (StringUtils.startsWithIgnoreCase(line, CARSDIST)) {
                    if (StringUtils.endsWithIgnoreCase(line, FIL)) {
                        disbursementsFilFiles.add(line);
                    } else {
                        disbursementsControlFiles.add(line);
                    }
                } else {
                    throw new AppException(String.format("Invalid file name %s found in %s file.", line, sourceFileName));
                }
            }
        }

        if (shareHoldersExtractFiles.isEmpty() || transactionsExtractFiles.isEmpty() || disbursementsFilFiles.isEmpty() ||
            disbursementsControlFiles.isEmpty() || transactionsFilFiles.isEmpty() || transactionsControlFiles.isEmpty()) {
            throw new AppException(String.format("One of the required files not found in %s file. Please check!", sourceFileName));
        }

        if (shareHoldersExtractFiles.size()>1 || transactionsExtractFiles.size()>1){
            throw new AppException(String.format("Only one ShareholderExtract/TransactionExtract file is expected in %s file. Please check!", sourceFileName));
        }

        SvioDone svioDone = buildSvioDoneMessage(transactionsExtractFiles, shareHoldersExtractFiles, transactionsFilFiles, transactionsControlFiles, disbursementsFilFiles, disbursementsControlFiles, sourceFileName);
        sendMessageToKafka(svioDone);

        stepExecution.getJobExecution().getExecutionContext().putLong(WRITE_COUNT, lineCount);

        return RepeatStatus.FINISHED;
    }

    private void sendMessageToKafka(SvioDone svioDone) throws InterruptedException, ExecutionException, TimeoutException {
        CompletableFuture<SendResult<String, Object>> future = doneKafkaTemplate.send(doneTopic, svioDone);
        doneKafkaTemplate.flush();
        SendResult<String, Object> result = future.get(1, TimeUnit.SECONDS);
        log.info("Sent the message to topic: {} on partition: {} and offset: {}", result.getRecordMetadata().topic(),
                result.getRecordMetadata().partition(), result.getRecordMetadata().offset());
    }

    private static SvioDone buildSvioDoneMessage(List<String> transactionsExtractFiles, List<String> shareHoldersExtractFiles, List<String> transactionsFilFiles, List<String> transactionsControlFiles, List<String> disbursementsFilFiles, List<String> disbursementsControlFiles, String sourceFileName) {
        String generatedDate = sourceFileName.split("_")[1].substring(0, 8);
        String valuationDate = sourceFileName.split("_")[2].substring(0, 8);

        Metadata metadata = Metadata.newBuilder()
                .setEventSourceTransactionsExtractFiles(transactionsExtractFiles)
                .setEventSourceShareholdersExtractFiles(shareHoldersExtractFiles)
                .setEventSourceTransactionsFilFiles(transactionsFilFiles)
                .setEventSourceTransactionsControlFiles(transactionsControlFiles)
                .setEventSourceDisbursementsFilFiles(disbursementsFilFiles)
                .setEventSourceDisbursementsControlFiles(disbursementsControlFiles)
                .setEventSourceFilename(sourceFileName)
                .setFileGeneratedDate(generatedDate)
                .setValuationDate(valuationDate)
                .setProcessedDate(LocalDate.now())
                .build();

        String eventBatchGroupId = UUID.randomUUID().toString();
        LocalDateTime currentDateTime = LocalDateTime.now(ZoneId.of(ZONE_ID_EST));
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATETIME_FORMAT);

        return SvioDone.newBuilder()
                .setEventHeader(EventHeader.newBuilder()
                        .setMetadata(metadata)
                        .setEventBatchGroupId(eventBatchGroupId)
                        .setEventSource(EVENT_SOURCE)
                        .setEventSourceDescription(EVENT_SOURCE_DESCRIPTION_DONE)
                        .setEventInitiator(GENERIC_ADAPTER_SVIO)
                        .setEventInitiatorDescription(EVENT_INITIATOR_DESC_DONE)
                        .setEventGeneratedDateTime(currentDateTime.format(dateTimeFormatter))
                        .setEventType(REQUEST_EVENT_TYPE)
                        .setEventCorrelationId(eventBatchGroupId)
                        .build())
                .build();
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        return stepExecution.getExitStatus();
    }
}
