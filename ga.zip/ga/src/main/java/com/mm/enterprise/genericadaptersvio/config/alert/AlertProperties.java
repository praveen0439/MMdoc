package com.mm.enterprise.genericadaptersvio.config.alert;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

@Data
@ConfigurationProperties(prefix = "ga.svio.alert")
public class AlertProperties {
    private String topic;
    private List<AlertRecipients> recipients;
}
