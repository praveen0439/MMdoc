package com.mm.enterprise.genericadaptersvio.processor;

import businesscustomers.event.agreements.institutionalcontrol.completed.SvioControlCompleted;
import businesscustomers.event.agreements.institutionalshareholder.requested.SVIOShareholderExtract;
import com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions;
import com.mm.enterprise.genericadaptersvio.mapper.ShareHolderExtractMapper;
import com.mm.enterprise.genericadaptersvio.model.shareholderextract.ShareHolderExtractInputTrailer;
import com.mm.enterprise.genericadaptersvio.model.shareholderextract.ShareholderExtractInput;
import com.mm.enterprise.genericadaptersvio.model.shareholderextract.ShareholderExtractInputRow;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;

import static com.mm.enterprise.genericadaptersvio.util.Constants.S3_BUCKET_KEY_PARAM;
import static com.mm.enterprise.genericadaptersvio.util.Constants.WRITE_COUNT;
import static com.mm.enterprise.genericadaptersvio.util.ItemProcessorHelper.getEventBatchGroupId;
import static com.mm.enterprise.genericadaptersvio.util.ItemProcessorHelper.removeLeadingZeroes;

@Slf4j
@Component
@RequiredArgsConstructor
public class ShareHolderExtractProcessor implements ItemProcessor<ShareholderExtractInput, SVIOShareholderExtract>, StepExecutionListener {
    @NotNull
    @Value(value = "${generic.adapter.svio.control.topic}")
    private String controlTopic;
    private StepExecution stepExecution;
    private final ShareHolderExtractMapper shareHolderExtractMapper;
    private final KafkaTemplate<String, Object> controlKafkaTemplate;

    @Override
    public void beforeStep(@NonNull StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }

    @Override
    public SVIOShareholderExtract process(@NonNull ShareholderExtractInput shareholderExtractInput) {
        log.debug("Starting processing for ShareholderExtract!");
        final String eventBatchGroupId = getEventBatchGroupId(stepExecution);
        final String inputFile = stepExecution.getJobParameters().getString(S3_BUCKET_KEY_PARAM);
        if (inputFile == null) {
            throw new GenericAdapterExceptions.InvalidJobException("The parameter " + S3_BUCKET_KEY_PARAM + " cannot be null!");
        }
        String[] strings = inputFile.split("/");
        String sourceFileName = strings[strings.length - 1];

        if (shareholderExtractInput instanceof ShareholderExtractInputRow shareholderExtractInputRow) {
            return shareHolderExtractMapper.mapShareholderExtractRow(shareholderExtractInputRow, eventBatchGroupId, sourceFileName);
        }
        if (shareholderExtractInput instanceof ShareHolderExtractInputTrailer shareHolderExtractInputTrailer) {
            SvioControlCompleted svioControlCompleted = shareHolderExtractMapper.mapShareholderExtractTrailer(shareHolderExtractInputTrailer, eventBatchGroupId, sourceFileName);
            controlKafkaTemplate.send(controlTopic, eventBatchGroupId, svioControlCompleted);
            stepExecution.getJobExecution().getExecutionContext().putLong(WRITE_COUNT, Long.parseLong(removeLeadingZeroes(shareHolderExtractInputTrailer.getTransactionCount())) - 2);
            log.info(String.format("Shareholder extract control with BatchGroupId %s completed.", eventBatchGroupId));
        }
        return null;
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        return stepExecution.getExitStatus();
    }
}
