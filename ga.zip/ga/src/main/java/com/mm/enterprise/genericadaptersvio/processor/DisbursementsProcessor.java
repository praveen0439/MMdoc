
package com.mm.enterprise.genericadaptersvio.processor;

import businesscustomers.event.disbursements.institutionaldisbursement.requested.InstitutionalDisbursementInitiated;
import com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions;
import com.mm.enterprise.genericadaptersvio.mapper.DisbursementsMapper;
import com.mm.enterprise.genericadaptersvio.model.disbursements.DisbursementsInput;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import static com.mm.enterprise.genericadaptersvio.util.Constants.S3_BUCKET_KEY_PARAM;
import static com.mm.enterprise.genericadaptersvio.util.ItemProcessorHelper.getEventBatchGroupId;
import static com.mm.enterprise.genericadaptersvio.util.ItemProcessorHelper.updateWriteCount;

@Component
@Slf4j(topic = "logger")
@RequiredArgsConstructor
public class DisbursementsProcessor implements ItemProcessor<DisbursementsInput, InstitutionalDisbursementInitiated>, StepExecutionListener {

    private final DisbursementsMapper disbursementsMapper;
    private StepExecution stepExecution;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        this.stepExecution=stepExecution;
    }

    @Override
    public InstitutionalDisbursementInitiated process(DisbursementsInput disbursementsInput) throws Exception {
        log.debug("Starting processing for Disbursements!");
        final String eventBatchGroupId = getEventBatchGroupId(stepExecution);

        String bucketKey = stepExecution.getJobParameters().getString(S3_BUCKET_KEY_PARAM);
        if (bucketKey == null) {
            throw new GenericAdapterExceptions.InvalidJobException("The parameter " + S3_BUCKET_KEY_PARAM + " cannot be null!");
        }
        String[] strings = bucketKey.split("/");
        String inputFile = strings[strings.length - 1];
        return disbursementsMapper.mapFromFlatFile(disbursementsInput,eventBatchGroupId,inputFile);
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        updateWriteCount(stepExecution);
        return stepExecution.getExitStatus();
    }
}

