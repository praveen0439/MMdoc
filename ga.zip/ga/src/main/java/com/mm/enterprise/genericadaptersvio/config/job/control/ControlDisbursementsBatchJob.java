package com.mm.enterprise.genericadaptersvio.config.job.control;

import businesscustomers.event.agreements.institutionalcontrol.completed.SvioControlCompleted;
import com.mm.enterprise.genericadaptersvio.config.job.tasklet.EmptyFileTask;
import com.mm.enterprise.genericadaptersvio.listener.SvioJobExecutionListener;
import com.mm.enterprise.genericadaptersvio.model.control.ControlInput;
import com.mm.enterprise.genericadaptersvio.processor.ControlDisbursementsProcessor;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.kafka.KafkaItemWriter;
import org.springframework.batch.item.kafka.builder.KafkaItemWriterBuilder;
import org.springframework.batch.item.support.CompositeItemProcessor;
import org.springframework.batch.item.validator.BeanValidatingItemProcessor;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.List;

import static com.mm.enterprise.genericadaptersvio.config.job.BatchJobType.CONTROL_DISBURSEMENTS_CHUNK_JOB;
import static com.mm.enterprise.genericadaptersvio.util.Constants.*;

@Configuration
@RequiredArgsConstructor
public class ControlDisbursementsBatchJob {
    @Value(value = "${generic.adapter.svio.retry.limit:3}")
    private Integer batchRetryLimit;

    private final ControlDisbursementsProcessor controlDisbursementsProcessor;

    private final EmptyFileTask emptyFileTask;

    private final SvioJobExecutionListener svioJobExecutionListener;

    private final KafkaTemplate<String, Object> controlKafkaTemplate;

    private static final String[] CONTROL_FLAT_FILE_COLUMN_NAME = {
            "fileName", "fileRunDate", "fileRunTime", "effectiveData",
            "recordCount", "facTotals"
    };

    @Bean
    public Job controlDisbursementsChunkJob(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new JobBuilder(CONTROL_DISBURSEMENTS_CHUNK_JOB.getValue(), jobRepository)
                .start(createDisbursementsControlChunkStep(jobRepository, transactionManager))
                .next(controlDisbursementsCheckEmptyFile(jobRepository, transactionManager))
                .listener(svioJobExecutionListener)
                .build();
    }

    @Bean
    protected Step controlDisbursementsCheckEmptyFile(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder(EMPTY_DISB_FILE_CHUNK_STEP, jobRepository)
                .tasklet(emptyFileTask, transactionManager)
                .build();

    }

    @Bean
    protected Step createDisbursementsControlChunkStep(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder(CONTROL_DISB_CHUNK_STEP, jobRepository)
                .<ControlInput, SvioControlCompleted>chunk(100, transactionManager)
                .reader(controlDisbFlatFileItemReader(null))
                .processor(compositeItemProcessor())
                .writer(kafkaItemWriter())
                .faultTolerant()
                .retryLimit(batchRetryLimit)
                .noRetry(ValidationException.class)
                .retry(Throwable.class)
                .listener(controlDisbursementsProcessor)
                .build();
    }

    @Bean
    @StepScope
    public FlatFileItemReader<ControlInput> controlDisbFlatFileItemReader(@Value("#{jobParameters['inputFile']}") FileSystemResource fileSystemResource) {
        return new FlatFileItemReaderBuilder<ControlInput>()
                .name(CONTROL_DISB_FLAT_FILE_ITEM_READER)
                .linesToSkip(1)
                .delimited()
                .delimiter(CONTROL_DELIMITED_LINE_TOKEN)
                .names(CONTROL_FLAT_FILE_COLUMN_NAME)
                .targetType(ControlInput.class)
                .resource(fileSystemResource)
                .build();
    }

    @Bean("controlKafkaItemWriter")
    @StepScope
    public KafkaItemWriter<String, Object> kafkaItemWriter() {
        return new KafkaItemWriterBuilder<String, Object>()
                .kafkaTemplate(controlKafkaTemplate)
                .itemKeyMapper(control -> String.valueOf(((SvioControlCompleted) control).getEventHeader().getEventCorrelationId()))
                .build();
    }

    @Bean("controlDisbInputValidatingItemProcessor")
    @StepScope
    public BeanValidatingItemProcessor<ControlInput> inputValidatingItemProcessor() {
        return new BeanValidatingItemProcessor<>();
    }

    @Bean("controlDisbCompositeItemProcessor")
    @StepScope
    public CompositeItemProcessor<ControlInput, SvioControlCompleted> compositeItemProcessor() {
        CompositeItemProcessor<ControlInput, SvioControlCompleted> compositeItemProcessor = new CompositeItemProcessor<>();
        compositeItemProcessor.setDelegates(List.of(inputValidatingItemProcessor(), controlDisbursementsProcessor));
        return compositeItemProcessor;
    }
}
