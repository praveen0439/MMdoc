package com.mm.enterprise.genericadaptersvio.processor;

import businesscustomers.event.agreements.institutionalcontrol.completed.SvioControlCompleted;
import com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions.InvalidJobException;
import com.mm.enterprise.genericadaptersvio.mapper.ControlDisbursementsMapper;
import com.mm.enterprise.genericadaptersvio.model.control.ControlInput;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import static com.mm.enterprise.genericadaptersvio.util.Constants.S3_BUCKET_KEY_PARAM;
import static com.mm.enterprise.genericadaptersvio.util.ItemProcessorHelper.getEventBatchGroupId;
import static com.mm.enterprise.genericadaptersvio.util.ItemProcessorHelper.updateWriteCount;

@Component
@Slf4j(topic = "logger")
@RequiredArgsConstructor
public class ControlDisbursementsProcessor implements ItemProcessor<ControlInput, SvioControlCompleted>, StepExecutionListener {
    private StepExecution stepExecution;

    private final ControlDisbursementsMapper controlDisbursementsMapper;

    @Override
    public void beforeStep(@NonNull StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }

    @Override
    public SvioControlCompleted process(@NonNull ControlInput item) {
        log.debug("Generating Control files");
        final String eventBatchGroupId = getEventBatchGroupId(stepExecution);
        String bucketKey = stepExecution.getJobParameters().getString(S3_BUCKET_KEY_PARAM);
        if (bucketKey == null) {
            throw new InvalidJobException("The parameter " + S3_BUCKET_KEY_PARAM + " cannot be null!");
        }
        String[] strings = bucketKey.split("/");
        String inputFile = strings[strings.length - 1];
        return controlDisbursementsMapper.mapFromFlatFile(item, inputFile, eventBatchGroupId);
    }

    @Override
    public ExitStatus afterStep(@NonNull StepExecution stepExecution) {
        updateWriteCount(stepExecution);
        return stepExecution.getExitStatus();
    }

}
