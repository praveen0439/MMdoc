package com.mm.enterprise.genericadaptersvio.mapper;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;

import java.util.Optional;
import java.util.function.BiFunction;

@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class BuilderWrapper<T> {
    private final T value;

    public static <T> BuilderWrapper<T> modify(T initialValue) {
        return new BuilderWrapper<>(initialValue);
    }

    public <U> BuilderWrapper<T> ifPresent(Optional<U> optional, BiFunction<T, U, T> modifier) {
        return modify(optional.map(input -> modifier.apply(value, input)).orElse(value));
    }

    public T get() {
        return value;
    }
}
