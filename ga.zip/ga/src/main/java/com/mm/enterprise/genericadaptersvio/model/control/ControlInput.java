package com.mm.enterprise.genericadaptersvio.model.control;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ControlInput {

    @NotBlank
    @Pattern(regexp = "^[a-zA-Z0-9]{1,22}\\.[a-zA-Z]{3,4}+$")
    private String fileName;

    @NotBlank
    @Size(max = 8, message = "File run date should not be greater than 8 characters.")
    @Pattern(regexp = "((19|2[0-9][0-9]{2})(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01]))", message = "File Run Date should respect the following pattern: yyyymmdd")
    private String fileRunDate;

    @NotBlank
    @Size(max = 6, message = "File Run Time should not be greater than 6 digits.")
    private String fileRunTime;

    @NotBlank
    @Size(max = 8, message = "Effective date should not be greater than 8 characters.")
    private String effectiveDate;

    @NotBlank
    @Size(max = 8, message = "Record count should not be greater than 8 digits.")
    private String recordCount;

    @NotNull
    @Digits(integer = 15, fraction = 2, message = "Market Amount totals format should be 999999999999999.99 or -999999999999999.99")
    private BigDecimal facTotals;
}
