package com.mm.enterprise.genericadaptersvio.model.transaction;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TransactionInput {

    @NotBlank(message = "Reference id is required.")
    @Size(max = 10, message = "Reference Id should not be greater than 10 digits.")
    private String referenceId;

    @NotBlank(message = "Fund id is required.")
    @Size(max = 10, message = "Fund Id should not be greater than 10 digits.")
    private String fundId;

    @NotBlank(message = "Account number is required.")
    @Size(max = 9, message = "Account number should not be greater than 9 digits.")
    private String accountNumber;

    @NotBlank(message = "SubAccount number is required.")
    @Size(max = 2, message = "SubAccount number should not be greater than 2 digits.")
    private String subAccountNumber;

    @Size(max = 8, message = "Effective date should not be greater than 8 characters.")
    private String effectiveDate;

    @NotBlank
    @Size(max = 8, message = "Valuation date should not be greater than 8 characters.")
    @Pattern(regexp = "((19|2[0-9][0-9]{2})(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01]))", message = "Valuation Date should respect the following pattern: yyyymmdd")
    private String valuationDate;

    @Size(max = 8, message = "Processing date should not be greater than 8 characters.")
    private String processingDate;

    @NotBlank
    @Size(max = 8, message = "Settlement date should not be greater than 8 characters.")
    @Pattern(regexp = "((19|2[0-9][0-9]{2})(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01]))", message = "Settlement Date should respect the following pattern: yyyymmdd")
    private String settlementDate;

    @Digits(integer = 13, fraction = 4, message = "Market Shares format should be 9999999999999.9999")
    private BigDecimal transactionMarketShares;

    @NotNull
    @Digits(integer = 15, fraction = 2, message = "Market Amount format should be 999999999999999.99 or -999999999999999.99")
    private BigDecimal transactionMarketAmount;

    @Size(max = 2, message = "Investment type should not be greater than 2 characters.")
    private String investmentType;

    @NotBlank
    @Size(max = 3, message = "Investment type should not be greater than 3 characters.")
    private String transactionType;

    @NotBlank
    @Size(max = 2, message = "Payment method should not be greater than 2 characters.")
    private String paymentMethod;

    @NotBlank
    @Size(max = 2, message = "Tax state code should not be greater than 2 characters.")
    private String taxStateCode;

    @NotBlank
    @Size(max = 8, message = "Contract effective date should not be greater than 8 characters.")
    @Pattern(regexp = "((19|2[0-9][0-9]{2})(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01]))", message = "Contract effective Date should respect the following pattern: yyyymmdd")
    private String contractEffectiveDate;
}
