package com.mm.enterprise.genericadaptersvio.config.job.done;

import com.mm.enterprise.genericadaptersvio.config.job.tasklet.DoneTasklet;
import com.mm.enterprise.genericadaptersvio.config.job.tasklet.EmptyFileTask;
import com.mm.enterprise.genericadaptersvio.listener.SvioJobExecutionListener;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import static com.mm.enterprise.genericadaptersvio.config.job.BatchJobType.DONE_CHUNK_JOB;
import static com.mm.enterprise.genericadaptersvio.util.Constants.DONE_CHUNK_STEP;
import static com.mm.enterprise.genericadaptersvio.util.Constants.EMPTY_DONE_FILE_CHUNK_STEP;

@Configuration
@RequiredArgsConstructor
public class DoneBatchJob {
    private final EmptyFileTask emptyFileTask;
    private final DoneTasklet doneTasklet;
    private final SvioJobExecutionListener svioJobExecutionListener;

    @Bean
    public Job doneChunkJob(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new JobBuilder(DONE_CHUNK_JOB.getValue(), jobRepository)
                .start(doneCheckEmptyFile(jobRepository, transactionManager))
                .next(createDoneChunkStep(jobRepository, transactionManager))
                .listener(svioJobExecutionListener)
                .build();
    }

    @Bean
    protected Step createDoneChunkStep(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder(DONE_CHUNK_STEP, jobRepository)
                .tasklet(doneTasklet, transactionManager)
                .build();
    }

    @Bean
    protected Step doneCheckEmptyFile(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder(EMPTY_DONE_FILE_CHUNK_STEP, jobRepository)
                .tasklet(emptyFileTask, transactionManager)
                .build();

    }
}
