package com.mm.enterprise.genericadaptersvio.model.shareholderextract;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ShareholderExtractInputRow implements ShareholderExtractInput {
    @NotEmpty(message = "fundNumber is required!")
    @Size(max = 10, message = "fundNumber length should not be greater than 10 characters!")
    private String fundNumber;

    @NotEmpty(message = "shareHolderAccountNumber is required!")
    @Size(max = 9, message = "shareHolderAccountNumber length should not be greater than 9 characters!")
    private String shareHolderAccountNumber;

    @NotEmpty(message = "sharHolderSubAccountNumber is required!")
    @Size(max = 2, message = "sharHolderSubAccountNumber length should not be greater than 2 characters!")
    private String sharHolderSubAccountNumber;

    @NotEmpty(message = "dealerNumber is required!")
    @Size(max = 6, message = "dealerNumber length should not be greater than 6 characters!")
    private String dealerNumber;

    @NotEmpty(message = "accountType is required!")
    @Size(max = 2, message = "accountType length should not be greater than 2 characters!")
    private String accountType;

    @NotEmpty(message = "dividendOption is required!")
    @Size(max = 2, message = "dividendOption length should not be greater than 2 characters!")
    private String dividendOption;

    @NotEmpty(message = "capitalGainsOption is required!")
    @Size(max = 2, message = "capitalGainsOption length should not be greater than 2 characters!")
    private String capitalGainsOption;

    @NotEmpty(message = "accountStatus is required!")
    @Size(max = 1, message = "accountStatus length should not be greater than 1 characters!")
    private String accountStatus;

    @NotEmpty(message = "accountOpenDate is required!")
    @Size(max = 8, message = "accountOpenDate length should not be greater than 8 characters!")
    @Pattern(regexp = "((19|2[0-9][0-9]{2})(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01]))",
            message = "accountOpenDate should respect the following pattern: yyyymmdd")
    private String accountOpenDate;

    @NotEmpty(message = "accountCloseDate is required!")
    @Size(max = 8, message = "accountCloseDate length should not be greater than 8 characters!")
    private String accountCloseDate;

    @NotNull(message = "bookShares is required!")
    @Digits(integer = 14, fraction = 4, message = "bookShares decimal format should be 99999999999999.9999 or -99999999999999.9999")
    private BigDecimal bookShares;
}
