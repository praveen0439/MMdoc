package com.mm.enterprise.genericadaptersvio.service;

import com.mm.enterprise.genericadaptersvio.exception.KafkaMessageServiceException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.KafkaException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
@Slf4j
public class KafkaMessageService {

  @Value(value = "${mm.common.kafka.producer.request.timeout:30000}")
  private Integer kafkaProducerRequestTimeout;

  public SendResult<String, Object> sendMessage(String key, Object value, KafkaTemplate<String, Object> kafkaTemplate) {
    log.info("Sending message to {} topic...", kafkaTemplate.getDefaultTopic());
    try {
      CompletableFuture<SendResult<String, Object>> future = kafkaTemplate.sendDefault(key, value);
      kafkaTemplate.flush();

      SendResult<String, Object> result = future.get(kafkaProducerRequestTimeout, TimeUnit.MILLISECONDS);

      log.info("Sent the message to topic: {} on partition: {} and offset: {}", result.getRecordMetadata().topic(),
          result.getRecordMetadata().partition(), result.getRecordMetadata().offset());

      return result;
    } catch (InterruptedException | ExecutionException | TimeoutException e) {
      Thread.currentThread().interrupt();
      log.error(KafkaMessageServiceException.WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE, e);
      throw new KafkaMessageServiceException(KafkaMessageServiceException.WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE, e);
    } catch (KafkaException e) {
      log.error(KafkaMessageServiceException.KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE, e);
      throw new KafkaMessageServiceException(KafkaMessageServiceException.KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE, e);
    }
  }

}
