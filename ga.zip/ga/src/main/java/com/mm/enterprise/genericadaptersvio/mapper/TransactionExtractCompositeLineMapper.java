package com.mm.enterprise.genericadaptersvio.mapper;

import com.mm.enterprise.genericadaptersvio.model.transactionextract.TransactionExtractInput;
import com.mm.enterprise.genericadaptersvio.model.transactionextract.TransactionExtractInputRow;
import com.mm.enterprise.genericadaptersvio.model.transactionextract.TransactionExtractInputTrailer;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.stereotype.Component;

import static com.mm.enterprise.genericadaptersvio.util.Constants.IS_TRAILER_PRESENT;

@Component
@Slf4j
@RequiredArgsConstructor
public class TransactionExtractCompositeLineMapper implements LineMapper<TransactionExtractInput>, StepExecutionListener {
    private static final String[] TRANSACTION_EXTRACT_FLAT_FILE_COLUMN_NAMES = {
            "fundNumber", "shareHolderAccountNumber", "shareHolderSubAccountNumber", "dateOfTrade",
            "sequenceNumber", "transactionType", "transactionTypeSub", "reversalFlag", "dollarAmount",
            "processingDate", "reverseDate", "clearDate", "purchaseSource", "paymentMethod"};

    private static final String[] TRANSACTION_EXTRACT_FLAT_FILE_TRAILER_COLUMN_NAMES = {
            "totalDollarAmount", "recordCount"};
    public static final String TRAILER_PREFIX = "PHOENIX-SVIO_ACTIVITY";

    private final FieldSetMapper<TransactionExtractInput> rowFieldSetMapper;
    private final FixedLengthTokenizer rowTokenizer;
    private final FieldSetMapper<TransactionExtractInput> trailerFieldSetMapper;
    private final FixedLengthTokenizer trailerTokenizer;
    private StepExecution stepExecution;

    @Override
    public void beforeStep(@NonNull StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }

    public TransactionExtractCompositeLineMapper() {
//      row mapper
        BeanWrapperFieldSetMapper<TransactionExtractInput> rowMapper = new BeanWrapperFieldSetMapper<>();
        rowMapper.setTargetType(TransactionExtractInputRow.class);
        this.rowFieldSetMapper = rowMapper;
        this.rowTokenizer = new FixedLengthTokenizer();
        this.rowTokenizer.setColumns(
                new Range(1, 10),
                new Range(11, 19),
                new Range(20, 21),
                new Range(33, 40),
                new Range(41, 45),
                new Range(46, 48),
                new Range(49, 51),
                new Range(82, 82),
                new Range(101, 119),
                new Range(219, 226),
                new Range(227, 234),
                new Range(235, 242),
                new Range(409, 410),
                new Range(411, 412)
        );
        this.rowTokenizer.setNames(TRANSACTION_EXTRACT_FLAT_FILE_COLUMN_NAMES);
        this.rowTokenizer.setStrict(false);

//      trailer mapper
        BeanWrapperFieldSetMapper<TransactionExtractInput> trailerMapper = new BeanWrapperFieldSetMapper<>();
        trailerMapper.setTargetType(TransactionExtractInputTrailer.class);
        this.trailerFieldSetMapper = trailerMapper;
        this.trailerTokenizer = new FixedLengthTokenizer();
        this.trailerTokenizer.setColumns(
                new Range(131, 149),
                new Range(151, 161)
        );
        this.trailerTokenizer.setNames(TRANSACTION_EXTRACT_FLAT_FILE_TRAILER_COLUMN_NAMES);
        this.trailerTokenizer.setStrict(false);
    }

    @Override
    public TransactionExtractInput mapLine(String line, int lineNumber) throws Exception {
        if (line.startsWith(TRAILER_PREFIX)) {
            stepExecution.getJobExecution().getExecutionContext().putString(IS_TRAILER_PRESENT, String.valueOf(true));
            return trailerFieldSetMapper.mapFieldSet(trailerTokenizer.tokenize(line));
        }
        return rowFieldSetMapper.mapFieldSet(rowTokenizer.tokenize(line));
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        return stepExecution.getExitStatus();
    }
}
