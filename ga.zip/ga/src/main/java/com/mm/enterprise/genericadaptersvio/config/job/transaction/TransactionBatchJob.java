package com.mm.enterprise.genericadaptersvio.config.job.transaction;

import businesscustomers.event.agreements.institutionaltransactions.requested.SVIOTransactions;
import com.mm.enterprise.genericadaptersvio.listener.SvioJobExecutionListener;
import com.mm.enterprise.genericadaptersvio.model.transaction.TransactionInput;
import com.mm.enterprise.genericadaptersvio.processor.TransactionProcessor;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.kafka.KafkaItemWriter;
import org.springframework.batch.item.kafka.builder.KafkaItemWriterBuilder;
import org.springframework.batch.item.support.CompositeItemProcessor;
import org.springframework.batch.item.validator.BeanValidatingItemProcessor;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.List;

import static com.mm.enterprise.genericadaptersvio.config.job.BatchJobType.TRANSACTIONS_CHUNK_JOB;
import static com.mm.enterprise.genericadaptersvio.util.Constants.TRANSACTION_CHUNK_STEP;
import static com.mm.enterprise.genericadaptersvio.util.Constants.TRANSACTION_FLAT_FILE_ITEM_READER;

@Configuration
@RequiredArgsConstructor
public class TransactionBatchJob {

    @Value(value = "${generic.adapter.svio.chunk.size:100}")
    private Integer batchChunkSize;

    @Value(value = "${generic.adapter.svio.retry.limit:3}")
    private Integer batchRetryLimit;

    private final TransactionProcessor transactionProcessor;
    private final SvioJobExecutionListener svioJobExecutionListener;
    private final KafkaTemplate<String, Object> transactionsKafkaTemplate;

    private static final String TRANSACTION_DELIMITED_LINE_TOKEN = "|";

    private static final String[] TRANSACTION_FLAT_FILE_COLUMN_NAME = {
            "referenceId", "fundId", "accountNumber", "subAccountNumber",
            "effectiveDate", "valuationDate", "processingDate", "settlementDate",
            "transactionMarketShares", "transactionMarketAmount", "investmentType",
            "transactionType", "paymentMethod", "taxStateCode", "contractEffectiveDate"
    };


    @Bean
    public Job transactionChunkJob(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new JobBuilder(TRANSACTIONS_CHUNK_JOB.getValue(), jobRepository)
                .start(createTransactionChunkStep(jobRepository, transactionManager))
                .listener(svioJobExecutionListener)
                .build();
    }

    @Bean
    protected Step createTransactionChunkStep(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder(TRANSACTION_CHUNK_STEP, jobRepository)
                .<TransactionInput, SVIOTransactions>chunk(batchChunkSize, transactionManager)
                .reader(transactionFlatFileItemReader(null))
                .processor(compositeItemProcessor())
                .writer(kafkaWriter())
                .faultTolerant()
                .retryLimit(batchRetryLimit)
                .noRetry(ValidationException.class)
                .retry(Throwable.class)
                .listener(transactionProcessor)
                .build();
    }

    @Bean
    @StepScope
    public FlatFileItemReader<TransactionInput> transactionFlatFileItemReader(@Value("#{jobParameters['inputFile']}") FileSystemResource fileSystemResource) {
        return new FlatFileItemReaderBuilder<TransactionInput>()
                .name(TRANSACTION_FLAT_FILE_ITEM_READER)
                .linesToSkip(1)
                .delimited()
                .delimiter(TRANSACTION_DELIMITED_LINE_TOKEN)
                .names(TRANSACTION_FLAT_FILE_COLUMN_NAME)
                .targetType(TransactionInput.class)
                .resource(fileSystemResource)
                .build();
    }

    @Bean
    @StepScope
    public KafkaItemWriter<String, Object> kafkaWriter() {
        return new KafkaItemWriterBuilder<String, Object>()
                .kafkaTemplate(transactionsKafkaTemplate)
                .itemKeyMapper(transaction -> String.valueOf(((SVIOTransactions) transaction).getEventHeader().getEventBatchGroupId()))
                .build();
    }

    @Bean("transactionInputValidatingItemProcessor")
    @StepScope
    public BeanValidatingItemProcessor<TransactionInput> inputValidatingItemProcessor() {
        return new BeanValidatingItemProcessor<>();
    }

    @Bean("transactionCompositeItemProcessor")
    @StepScope
    public CompositeItemProcessor<TransactionInput, SVIOTransactions> compositeItemProcessor() {
        CompositeItemProcessor<TransactionInput, SVIOTransactions> compositeItemProcessor = new CompositeItemProcessor<>();
        compositeItemProcessor.setDelegates(List.of(inputValidatingItemProcessor(), transactionProcessor));
        return compositeItemProcessor;
    }
}
