package com.mm.enterprise.genericadaptersvio.model.transactionextract;

public interface TransactionExtractInput {}
