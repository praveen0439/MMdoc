package com.mm.enterprise.genericadaptersvio.service.job;

import com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions.InvalidJobException;
import com.mm.enterprise.genericadaptersvio.model.S3ObjectDetails;
import com.mm.enterprise.genericadaptersvio.service.KafkaTopicAlertService;
import com.mm.enterprise.genericadaptersvio.util.Constants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class JobService {

    private final JobLauncher jobLauncher;
    private final JobSelector jobSelector;
    private final JobStatus jobStatus;
    private final KafkaTopicAlertService kafkaTopicAlertService;

    public JobParameters getJobParameters(S3ObjectDetails s3ObjectDetails, String localFlatFilePath) {
        final Map<String, JobParameter<?>> params = new HashMap<>();
        params.put(Constants.INPUT_FILE, new JobParameter<>(localFlatFilePath, String.class));
        params.put(Constants.S3_BUCKET_NAME_PARAM, new JobParameter<>(s3ObjectDetails.bucketName(), String.class));
        params.put(Constants.S3_BUCKET_KEY_PARAM, new JobParameter<>(s3ObjectDetails.bucketKey(), String.class));
        params.put(Constants.S3_BUCKET_E_TAG_PARAM, new JobParameter<>(s3ObjectDetails.bucketETag(), String.class));
        params.put(Constants.S3_BUCKET_SIZE, new JobParameter<>(s3ObjectDetails.bucketSize(), Long.class));

        if (s3ObjectDetails.jobParamsRequestList() != null) {
            s3ObjectDetails.jobParamsRequestList().forEach(jobParamsRequest ->
                    params.put(
                            jobParamsRequest.paramKey(),
                            new JobParameter<>(jobParamsRequest.paramValue(), String.class)
                    ));
        }
        return new JobParameters(params);
    }

    @Async
    public void startJob(String jobName, JobParameters jobParameters) {
        final JobExecution jobExecution;
        jobStatus.checkStatus(jobName);
        Job job = jobSelector.get(jobName);
        try {
            jobExecution = jobLauncher.run(job, jobParameters);
            log.info("Job execution id: " + jobExecution.getId());
        } catch (Exception e) {
            String message = String.format("Exception while starting the job %s with parameters %s. %s", jobName, jobParameters, e);
            kafkaTopicAlertService.sendError(message);
            log.error("Exception while starting the job: {}", jobName, e);
            throw new InvalidJobException(message + e.getMessage());
        }
    }
}
