package com.mm.enterprise.genericadaptersvio.controller;

import com.mm.enterprise.genericadaptersvio.model.S3ObjectDetails;
import com.mm.enterprise.genericadaptersvio.service.S3Service;
import com.mm.enterprise.genericadaptersvio.service.job.JobService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobParameters;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@Slf4j
public class JobController {
    private final static String GENERIC_ADAPTER_SVIO_SCOPE = "gasvio_rw";

    private final JobService jobService;
    private final S3Service s3Service;

    @PreAuthorize("hasAuthority('GENERIC_ADAPTER_SVIO_SCOPE')")
    @PostMapping(value = "/start/{jobName}", produces = MediaType.APPLICATION_JSON_VALUE)
    public String startJob(@RequestBody S3ObjectDetails s3ObjectDetails,
                           @Valid @NotBlank @PathVariable String jobName) {
        final String localFlatFilePath = s3Service.saveS3ObjectLocally(s3ObjectDetails);
        JobParameters jobParameters = jobService.getJobParameters(s3ObjectDetails, localFlatFilePath);
        jobService.startJob(jobName, jobParameters);
        return "Job started..." + jobName;
    }
}
