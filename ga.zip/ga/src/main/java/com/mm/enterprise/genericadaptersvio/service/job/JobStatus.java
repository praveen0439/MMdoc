package com.mm.enterprise.genericadaptersvio.service.job;

import com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

@Slf4j
@Service
@RequiredArgsConstructor
public class JobStatus {
    private static final long HALF_DAY_SECONDS = Duration.of(12, ChronoUnit.HOURS).getSeconds();

    private final JobExplorer jobExplorer;

    public void checkStatus(String jobName) {
        while (isJobRunning(jobName)) {
            try {
                log.info("A {} is already running", jobName);
                Thread.sleep(20000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new GenericAdapterExceptions.ThreadSleepException(jobName, e);
            }
        }
    }

    private boolean isJobRunning(String currentJobName) {
        final JobInstance jobInstance = jobExplorer.getLastJobInstance(currentJobName);
        if (jobInstance == null) {
            return false;
        }
        final JobExecution lastExecution = jobExplorer.getLastJobExecution(jobInstance);
        if (lastExecution == null) {
            return false;
        }
        if (!lastExecution.isRunning()) {
            return false;
        }

        final var lastUpdated = lastExecution.getLastUpdated();
        return ChronoUnit.SECONDS.between(lastUpdated, LocalDateTime.now()) < HALF_DAY_SECONDS;
    }
}
