package com.mm.enterprise.genericadaptersvio.service;


import com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions.UnknownS3Exception;
import com.mm.enterprise.genericadaptersvio.model.S3ObjectDetails;
import com.mm.enterprise.genericadaptersvio.util.Constants;
import com.mm.enterprise.genericadaptersvio.util.LocalFileProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobParameters;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;

import java.nio.file.Path;
import java.util.List;

import static com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions.LocalFolderException;
import static com.mm.enterprise.genericadaptersvio.util.Constants.SOURCE_MAIN_BUCKET_FOLDER;
import static com.mm.enterprise.genericadaptersvio.util.LocalFileProcessor.removeLocalFile;

@Slf4j
@Service
@RequiredArgsConstructor
public class S3Service {
    private final S3Client s3Client;

    public String saveS3ObjectLocally(S3ObjectDetails s3Object) {

        String filePath = "";

        try {
            final GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                    .bucket(s3Object.bucketName())
                    .key(s3Object.bucketKey())
                    .build();
            ResponseBytes<GetObjectResponse> objectBytes = s3Client.getObjectAsBytes(getObjectRequest);
            byte[] data = objectBytes.asByteArray();

            return LocalFileProcessor.save(s3Object, data);
        } catch (S3Exception e) {
            String message = String.format("S3 exception %s while trying to save object %s.",
                    e.awsErrorDetails().errorMessage(), s3Object.bucketName() + "/" + s3Object.bucketKey());
            log.error(message);
            throw new UnknownS3Exception(message);
        } catch (LocalFolderException e) {
            log.error("Could not create local folder");
        }
        return filePath;
    }

    public void moveFileFromMainToSourceFolder(JobParameters jobParameters, String sourceFolder) {
        final String bucketName = jobParameters.getString(Constants.S3_BUCKET_NAME_PARAM);
        final String bucketSourceKey = jobParameters.getString(Constants.S3_BUCKET_KEY_PARAM);

        final String bucketDestinationKey = bucketSourceKey.replace(SOURCE_MAIN_BUCKET_FOLDER, sourceFolder);

        final String localFileName = bucketSourceKey.replace("/", "-");

        copyS3Object(bucketName, bucketSourceKey, bucketDestinationKey);
        deleteS3Object(bucketName, bucketSourceKey);

        log.info(String.format("Moving S3 Object from bucket %s from %s to %s", bucketName, bucketSourceKey, bucketDestinationKey));

        removeLocalFile(Path.of(Constants.LOCAL_DATA_FOLDER + localFileName));
    }

    public void copyS3Object(String bucketName, String sourceKey, String destinationKey) {

        CopyObjectRequest copyReq = CopyObjectRequest.builder()
                .sourceBucket(bucketName)
                .sourceKey(sourceKey)
                .destinationBucket(bucketName)
                .destinationKey(destinationKey)
                .build();

        try {
            s3Client.copyObject(copyReq);
        } catch (S3Exception e) {
            final String s3BucketUrl = bucketName + "/" + sourceKey;
            log.error("S3 exception {} while trying to copy object {} ", e.awsErrorDetails().errorMessage(), s3BucketUrl);
            throw new UnknownS3Exception("Exception while trying to encode S3 url " + e.awsErrorDetails().errorMessage());
        }
    }

    public void deleteS3Object(String bucketName, String bucketKey) {

        DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest.builder()
                .bucket(bucketName)
                .key(bucketKey)
                .build();

        s3Client.deleteObject(deleteObjectRequest);
        log.info("S3 object {} deleted successfully", bucketName);
    }



    public void testListBucketObjects(String bucketName) {
        try {
            ListObjectsRequest listObjects = ListObjectsRequest.builder()
                    .bucket(bucketName)
                    .build();

            ListObjectsResponse res = s3Client.listObjects(listObjects);
            List<S3Object> objects = res.contents();

            log.info("----------------------------------------------");
            log.info("Bucket name: {} and bucket key is {} and owner {}", bucketName, objects.get(0).key(), objects.get(0).owner());
            log.info("Bucket name: {} and bucket key is {} and owner {}", bucketName, objects.get(1).key(), objects.get(1).owner());
            log.info("----------------------------------------------");

        } catch (S3Exception exception) {
            log.info("Bucket name: {} with exception", bucketName, exception);
        }
    }
}

