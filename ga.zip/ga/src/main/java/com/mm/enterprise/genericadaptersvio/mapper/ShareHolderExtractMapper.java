package com.mm.enterprise.genericadaptersvio.mapper;


import businesscustomers.event.agreements.institutionalcontrol.completed.EventSourceFileType;
import businesscustomers.event.agreements.institutionalcontrol.completed.SvioControlCompleted;
import businesscustomers.event.agreements.institutionalshareholder.requested.*;
import com.mm.enterprise.genericadaptersvio.model.shareholderextract.ShareHolderExtractInputTrailer;
import com.mm.enterprise.genericadaptersvio.model.shareholderextract.ShareholderExtractInputRow;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import static businesscustomers.event.agreements.institutionalcontrol.completed.EventHeader.newBuilder;
import static com.mm.enterprise.genericadaptersvio.util.Constants.*;
import static com.mm.enterprise.genericadaptersvio.util.ItemProcessorHelper.removeLeadingZeroes;

@Component
@Slf4j()
@RequiredArgsConstructor
public class ShareHolderExtractMapper {

    public SVIOShareholderExtract mapShareholderExtractRow(ShareholderExtractInputRow input, String eventBatchGroupId, String inputFileName) {
        log.debug(String.format("Starting conversion from flat file to ShareholderExtract Row json with EventBatchGroupId %s.", eventBatchGroupId));
        Metadata metadata = createMetadata(inputFileName);
        EventHeader eventHeader = createEventHeader(metadata, eventBatchGroupId);
        Contract contract = createContract(input);

        return SVIOShareholderExtract.newBuilder()
                .setEventHeader(eventHeader)
                .setContract(contract)
                .build();
    }

    private Contract createContract(ShareholderExtractInputRow input) {
        return Contract.newBuilder()
                .setEffectiveDate(input.getAccountOpenDate())
                .setExpirationDate(input.getAccountCloseDate())
                .setPrimaryId(input.getShareHolderAccountNumber())
                .setStatusCode(input.getAccountStatus())
                .setSuffix(input.getSharHolderSubAccountNumber())
                .setTypeCode(input.getAccountType())
                .setDistributor(Distributor.newBuilder()
                        .setNumber(input.getDealerNumber())
                        .build())
                .setInvestment(Investment.newBuilder()
                        .setFund(Fund.newBuilder()
                                .setAdminNumber(input.getFundNumber())
                                .build())
                        .setDividend(Dividend.newBuilder()
                                .setCapitalGainTypeCode(input.getCapitalGainsOption())
                                .setDividendOptionTypeCode(input.getDividendOption())
                                .build())
                        .setUnitCount(input.getBookShares().toString())
                        .build())
                .build();
    }

    private EventHeader createEventHeader(Metadata metadata, String eventBatchGroupId) {
        final String eventCorrelationId = UUID.randomUUID().toString();
        LocalDateTime currentDateTime = LocalDateTime.now(ZoneId.of(ZONE_ID_EST));
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATETIME_FORMAT);
        DateTimeFormatter dateformatter = DateTimeFormatter.ofPattern(DATE_FORMAT);

        return EventHeader.newBuilder()
                .setMetadata(metadata)
                .setEventType(EVENT_SOURCE)
                .setEventSubtype(EVENT_SUBTYPE_SHAREHOLDEREXTRACT)
                .setEventDateTime(currentDateTime.format(dateformatter))
                .setEventGeneratedDateTime(currentDateTime.format(dateTimeFormatter))
                .setEventCorrelationId(eventCorrelationId)
                .setEventRequestId(eventCorrelationId)
                .setEventSourceDescription(EVENT_SOURCE_DESCRIPTION_SHAREHOLDEREXTRACT)
                .setEventSource(EVENT_SOURCE)
                .setEventInitiator(GENERIC_ADAPTER_SVIO)
                .setEventInitiatorDescription(EVENT_INITIATOR_DESC_SHAREHOLDEREXTRACT)
                .setEventBatchGroupId(eventBatchGroupId)
                .build();
    }

    private Metadata createMetadata(String sourceFileName) {
        return Metadata.newBuilder()
                .setEventSourceFilename(sourceFileName)
                .setFileGeneratedDate(sourceFileName.split("_")[1].substring(0, 8))
                .setProcessedDate(LocalDate.now())
                .build();
    }

    public SvioControlCompleted mapShareholderExtractTrailer(ShareHolderExtractInputTrailer input, String eventBatchGroupId, String sourceFileName) {
        log.debug(String.format("Starting conversion from flat file to ShareholderExtract Trailer json with EventBatchGroupId %s.", eventBatchGroupId));

        String valuationDate = sourceFileName.split("_")[2].substring(0, 8);
        LocalDateTime currentDateTime = LocalDateTime.now(ZoneId.of(ZONE_ID_EST));
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATETIME_FORMAT);
        final String eventCorrelationId = UUID.randomUUID().toString();

        return SvioControlCompleted.newBuilder()
                .setEventHeader(newBuilder()
                        .setEventBatchGroupId(eventBatchGroupId)
                        .setEventBatchTotalAmt(input.getBookSharesSum().toString())
                        .setEventBatchRecordCountTotal(String.valueOf(Long.parseLong(removeLeadingZeroes(input.getTransactionCount())) - 2))
                        .setEventCorrelationId(eventCorrelationId)
                        .setEventSource(EVENT_SOURCE)
                        .setEventSourceDescription(EVENT_SOURCE_DESCRIPTION_SHAREHOLDEREXTRACT)
                        .setEventGeneratedDateTime(currentDateTime.format(dateTimeFormatter))
                        .setEventType(REQUEST_EVENT_TYPE)
                        .setEventInitiatorDescription(EVENT_INITIATOR_DESC_SHAREHOLDEREXTRACT)
                        .setEventInitiator(GENERIC_ADAPTER_SVIO)
                        .setMetadata(businesscustomers.event.agreements.institutionalcontrol.completed.Metadata.newBuilder()
                                .setEventSourceReferencedFilename("")
                                .setEventSourceRunDate(sourceFileName.split("_")[1].substring(0, 8))
                                .setEventSourceRunTime(sourceFileName.split("_")[1].substring(8, 14))
                                .setEventSourceValuationDate(valuationDate)
                                .setEventSourceFilename(sourceFileName)
                                .setEventSourceFileType(EventSourceFileType.SHAREHOLDERSEXTRACT)
                                .setProcessedDate(LocalDate.now())
                                .build())
                        .build())
                .build();
    }
}
