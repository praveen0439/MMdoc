package com.mm.enterprise.genericadaptersvio.listener;

import com.mm.enterprise.genericadaptersvio.exception.KafkaMessageServiceException;
import com.mm.enterprise.genericadaptersvio.service.KafkaTopicAlertService;
import com.mm.enterprise.genericadaptersvio.service.S3Service;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.kafka.KafkaException;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import static com.mm.enterprise.genericadaptersvio.config.job.BatchJobType.SHAREHOLDERS_EXTRACTS_CHUNK_JOB;
import static com.mm.enterprise.genericadaptersvio.config.job.BatchJobType.TRANSACTIONS_EXTRACTS_CHUNK_JOB;
import static com.mm.enterprise.genericadaptersvio.util.Constants.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class SvioJobExecutionListener implements JobExecutionListener {

    private final KafkaTopicAlertService kafkaTopicAlertService;
    private final S3Service s3Service;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.info("Starting SvioJobExecutionListener");
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        log.info("{} finished with status {}", jobExecution.getJobInstance().getJobName(), jobExecution.getExitStatus());
        List<StepExecution> stepExecutions = new ArrayList<>(jobExecution.getStepExecutions());
        JobParameters jobParameters = jobExecution.getJobParameters();

        if (ExitStatus.COMPLETED.equals(jobExecution.getExitStatus())) {
            ExecutionContext executionContext = jobExecution.getExecutionContext();
            final String inputFile = jobParameters.getString(INPUT_FILE);

            Object isTrailerPresent = executionContext.get(IS_TRAILER_PRESENT);
            boolean isTransactionsExtractJob = TRANSACTIONS_EXTRACTS_CHUNK_JOB.getValue().equals(jobExecution.getJobInstance().getJobName());
            boolean isShareHoldersExtractJob = SHAREHOLDERS_EXTRACTS_CHUNK_JOB.getValue().equals(jobExecution.getJobInstance().getJobName());
            if (isTrailerPresent == null && (isTransactionsExtractJob || isShareHoldersExtractJob)) {
                String errorMessage = String.format("The trailer row is not present for %s file. Please check!", inputFile);
                kafkaTopicAlertService.sendError(errorMessage);
                s3Service.moveFileFromMainToSourceFolder(jobParameters, SOURCE_FAILURE_BUCKET_FOLDER);
            } else {
                final long writeCount = executionContext.getLong(WRITE_COUNT);

                String notificationMessage = "SVIO " + inputFile + " has been successfully processed in GA, no of rows: " + writeCount;
                try {
                    kafkaTopicAlertService.sendNotification(notificationMessage);
                } catch (InterruptedException | ExecutionException | TimeoutException e) {
                    Thread.currentThread().interrupt();
                    log.error(KafkaMessageServiceException.WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE, e);
                    throw new KafkaMessageServiceException(KafkaMessageServiceException.WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE, e);
                } catch (KafkaException e) {
                    log.error(KafkaMessageServiceException.KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE, e);
                    throw new KafkaMessageServiceException(KafkaMessageServiceException.KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE, e);
                }
                s3Service.moveFileFromMainToSourceFolder(jobParameters, SOURCE_SUCCESS_BUCKET_FOLDER);
            }
        } else {
            StepExecution failedStepExecution = stepExecutions.get(stepExecutions.size() - 1);
            List<Throwable> failureExceptions = failedStepExecution.getFailureExceptions();

            String localisedErrorMessage;
            if (failureExceptions.get(failureExceptions.size() - 1).getCause() != null) {
                localisedErrorMessage = failureExceptions.get(failureExceptions.size() - 1).getCause().toString();
            } else {
                localisedErrorMessage = failureExceptions.get(failureExceptions.size() - 1).getLocalizedMessage();
            }
            String errorMessage = jobExecution.getJobInstance().getJobName() + " job FAILED in step: " + failedStepExecution.getStepName() + " with error: " + localisedErrorMessage;
            kafkaTopicAlertService.sendError(errorMessage);
            s3Service.moveFileFromMainToSourceFolder(jobParameters, SOURCE_FAILURE_BUCKET_FOLDER);
        }
    }
}
