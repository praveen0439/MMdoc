package com.mm.enterprise.genericadaptersvio.config.job.transactionextract;

import businesscustomers.event.agreements.institutionaltransactiondetail.requested.TransactionsExtractInitiated;
import com.mm.enterprise.genericadaptersvio.listener.SvioJobExecutionListener;
import com.mm.enterprise.genericadaptersvio.mapper.TransactionExtractCompositeLineMapper;
import com.mm.enterprise.genericadaptersvio.model.transactionextract.TransactionExtractInput;
import com.mm.enterprise.genericadaptersvio.model.transactionextract.TransactionExtractInputRow;
import com.mm.enterprise.genericadaptersvio.model.transactionextract.TransactionExtractInputTrailer;
import com.mm.enterprise.genericadaptersvio.processor.TransactionExtractProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.kafka.KafkaItemWriter;
import org.springframework.batch.item.kafka.builder.KafkaItemWriterBuilder;
import org.springframework.batch.item.support.CompositeItemProcessor;
import org.springframework.batch.item.validator.BeanValidatingItemProcessor;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.List;

import static com.mm.enterprise.genericadaptersvio.config.job.BatchJobType.TRANSACTIONS_EXTRACTS_CHUNK_JOB;

@Configuration
@Slf4j
@RequiredArgsConstructor
public class TransactionExtractJobConfig {
    @Value(value = "${generic.adapter.svio.chunk.size:100}")
    private Integer batchChunkSize;

    @Value(value = "${generic.adapter.svio.retry.limit:3}")
    private Integer batchRetryLimit;
    private final TransactionExtractProcessor transactionExtractProcessor;
    private final KafkaTemplate<String, Object> transactionExtractKafkaTemplate;
    private final SvioJobExecutionListener svioJobExecutionListener;
    private final TransactionExtractCompositeLineMapper transactionExtractCompositeLineMapper;

    @Bean
    public Job transactionExtractJob(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new JobBuilder(TRANSACTIONS_EXTRACTS_CHUNK_JOB.getValue(), jobRepository)
                .start(createTransactionExtractFileStep(jobRepository, transactionManager))
                .listener(svioJobExecutionListener)
                .build();
    }

    @Bean
    protected Step createTransactionExtractFileStep(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder("createTransactionExtractFileStep", jobRepository)
                .<TransactionExtractInput, TransactionsExtractInitiated>chunk(batchChunkSize, transactionManager)
                .reader(flatFileItemReader(null))
                .processor(compositeItemProcessor())
                .writer(transactionExtractKafkaItemWriter())
                .faultTolerant()
                .retryLimit(batchRetryLimit)
                .noRetry(ValidationException.class)
                .retry(Throwable.class)
                .listener(transactionExtractProcessor)
                .listener(transactionExtractCompositeLineMapper)
                .build();
    }

    @Bean("transactionExtractItemReader")
    @StepScope
    public FlatFileItemReader<TransactionExtractInput> flatFileItemReader(
            @Value("#{jobParameters['inputFile']}") FileSystemResource fileSystemResource) {
        return new FlatFileItemReaderBuilder<TransactionExtractInput>()
                .linesToSkip(1)
                .name("transactionExtractFlatFileItemReader")
                .targetType(TransactionExtractInput.class)
                .lineMapper(transactionExtractCompositeLineMapper)
                .resource(fileSystemResource)
                .build();
    }

    @Bean("transactionExtractInputRowValidatingItemProcessor")
    @StepScope
    public BeanValidatingItemProcessor<TransactionExtractInputRow> inputValidatingRowItemProcessor() {
        return new BeanValidatingItemProcessor<>();
    }

    @Bean("transactionExtractInputTrailerValidatingItemProcessor")
    @StepScope
    public BeanValidatingItemProcessor<TransactionExtractInputTrailer> inputValidatingTrailerItemProcessor() {
        return new BeanValidatingItemProcessor<>();
    }

    @Bean("transactionExtractCompositeItemProcessor")
    @StepScope
    public ItemProcessor<TransactionExtractInput, TransactionsExtractInitiated> compositeItemProcessor() {
        CompositeItemProcessor<TransactionExtractInput, TransactionsExtractInitiated> compositeItemProcessor
                = new CompositeItemProcessor<>();
        compositeItemProcessor.setDelegates(List.of(
                inputValidatingRowItemProcessor(),
                inputValidatingTrailerItemProcessor(),
                transactionExtractProcessor));
        return compositeItemProcessor;
    }

    @Bean("transactionExtractKafkaItemWriter")
    @StepScope
    public KafkaItemWriter<String, Object> transactionExtractKafkaItemWriter() {
        return new KafkaItemWriterBuilder<String, Object>()
                .kafkaTemplate(transactionExtractKafkaTemplate)
                .itemKeyMapper(transactionExtract -> ((TransactionsExtractInitiated) transactionExtract).getEventHeader().getEventBatchGroupId())
                .build();
    }
}
