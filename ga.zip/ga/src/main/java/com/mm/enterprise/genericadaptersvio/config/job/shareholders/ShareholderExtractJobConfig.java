package com.mm.enterprise.genericadaptersvio.config.job.shareholders;

import businesscustomers.event.agreements.institutionalshareholder.requested.SVIOShareholderExtract;
import com.mm.enterprise.genericadaptersvio.config.job.tasklet.EmptyFileTask;
import com.mm.enterprise.genericadaptersvio.listener.SvioJobExecutionListener;
import com.mm.enterprise.genericadaptersvio.mapper.ShareHolderExtractCompositeLineMapper;
import com.mm.enterprise.genericadaptersvio.model.shareholderextract.ShareHolderExtractInputTrailer;
import com.mm.enterprise.genericadaptersvio.model.shareholderextract.ShareholderExtractInput;
import com.mm.enterprise.genericadaptersvio.model.shareholderextract.ShareholderExtractInputRow;
import com.mm.enterprise.genericadaptersvio.processor.ShareHolderExtractProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.kafka.KafkaItemWriter;
import org.springframework.batch.item.kafka.builder.KafkaItemWriterBuilder;
import org.springframework.batch.item.support.CompositeItemProcessor;
import org.springframework.batch.item.validator.BeanValidatingItemProcessor;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.List;

import static com.mm.enterprise.genericadaptersvio.config.job.BatchJobType.SHAREHOLDERS_EXTRACTS_CHUNK_JOB;

@Configuration
@Slf4j
@RequiredArgsConstructor
public class ShareholderExtractJobConfig {

    @Value(value = "${generic.adapter.svio.chunk.size:100}")
    private Integer batchChunkSize;

    @Value(value = "${generic.adapter.svio.retry.limit:3}")
    private Integer retryLimit;

    private final KafkaTemplate<String, Object> shareholderExtractKafkaTemplate;
    private final ShareHolderExtractProcessor shareHolderExtractProcessor;
    private final EmptyFileTask emptyFileTask;
    private final SvioJobExecutionListener svioJobExecutionListener;
    private final ShareHolderExtractCompositeLineMapper shareHolderExtractCompositeLineMapper;
    @Bean
    public Job shareholdersJob(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new JobBuilder(SHAREHOLDERS_EXTRACTS_CHUNK_JOB.getValue(), jobRepository)
                .start(createShareHoldersFileStep(jobRepository, transactionManager))
                .next(shareholdersCheckEmptyFile(jobRepository, transactionManager))
                .listener(svioJobExecutionListener)
                .build();
    }

    @Bean
    protected Step shareholdersCheckEmptyFile(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder("shareholdersEmptyFileCheck", jobRepository)
                .tasklet(emptyFileTask, transactionManager)
                .build();
    }

    @Bean
    protected Step createShareHoldersFileStep(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder("createShareHoldersFileStep", jobRepository)
                .<ShareholderExtractInput, SVIOShareholderExtract>chunk(batchChunkSize, transactionManager)
                .reader(flatFileItemReader(null))
                .processor(compositeItemProcessor())
                .writer(kafkaItemWriter())
                .faultTolerant()
                .retryLimit(retryLimit)
                .noRetry(ValidationException.class)
                .retry(Throwable.class)
                .listener(shareHolderExtractProcessor)
                .listener(shareHolderExtractCompositeLineMapper)
                .build();
    }

    @Bean("shareholdersItemReader")
    @StepScope
    public FlatFileItemReader<ShareholderExtractInput> flatFileItemReader(@Value("#{jobParameters['inputFile']}") FileSystemResource fileSystemResource) {
        return new FlatFileItemReaderBuilder<ShareholderExtractInput>()
                .linesToSkip(1)
                .name("shareholdersFlatFileItemReader")
                .targetType(ShareholderExtractInput.class)
                .lineMapper(shareHolderExtractCompositeLineMapper)
                .resource(fileSystemResource)
                .build();
    }

    @Bean("shareholdersItemProcessor")
    @StepScope
    public ItemProcessor<ShareholderExtractInput, SVIOShareholderExtract> compositeItemProcessor() {
        CompositeItemProcessor<ShareholderExtractInput, SVIOShareholderExtract> compositeItemProcessor
                = new CompositeItemProcessor<>();
        compositeItemProcessor.setDelegates(List.of(
                inputValidatingRowItemProcessor(),
                inputValidatingTrailerItemProcessor(),
                shareHolderExtractProcessor));
        return compositeItemProcessor;
    }

    @Bean("shareHoldersInputRowValidatingItemProcessor")
    @StepScope
    public BeanValidatingItemProcessor<ShareholderExtractInputRow> inputValidatingRowItemProcessor() {
        return new BeanValidatingItemProcessor<>();
    }

    @Bean("shareHoldersInputTrailerValidatingItemProcessor")
    @StepScope
    public BeanValidatingItemProcessor<ShareHolderExtractInputTrailer> inputValidatingTrailerItemProcessor() {
        return new BeanValidatingItemProcessor<>();
    }

    @Bean("shareholderExtractKafkaItemWriter")
    @StepScope
    public KafkaItemWriter<String, Object> kafkaItemWriter() {
        return new KafkaItemWriterBuilder<String, Object>()
                .kafkaTemplate(shareholderExtractKafkaTemplate)
                .itemKeyMapper(shareholderExtract -> String.valueOf(((SVIOShareholderExtract) shareholderExtract).getEventHeader().getEventBatchGroupId()))
                .build();
    }
}
