package com.mm.enterprise.genericadaptersvio.config.kafka;

import org.apache.kafka.common.config.SslConfigs;

import java.util.Map;

public final class KafkaHelpers {

    private KafkaHelpers() {
    }

    public static void enableKafkaSecurity(Map<String, Object> configs,
                                           String trustStore,
                                           String trustStorePassword,
                                           String securityProtocol,
                                           String authCredentialSource,
                                           String authUserInfo,
                                           String saslMechanism,
                                           String saslJaasConfig) {
        if (trustStore != null) {
            configs.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, trustStore);
            configs.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, trustStore);

        }
        if (trustStorePassword != null) {
            configs.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, trustStorePassword);
            configs.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, trustStorePassword);
            configs.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, trustStorePassword);

        }
        if (securityProtocol != null) {
            configs.put("security.protocol", securityProtocol);
        }
        if (authCredentialSource != null) {
            configs.put("basic.auth.credentials.source", authCredentialSource);
        }
        if (authUserInfo != null) {
            configs.put("basic.auth.user.info", authUserInfo);
        }
        if (saslMechanism != null) {
            configs.put("sasl.mechanism", saslMechanism);
        }
        if (saslJaasConfig != null) {
            configs.put("sasl.jaas.config", saslJaasConfig);
        }
    }
}
