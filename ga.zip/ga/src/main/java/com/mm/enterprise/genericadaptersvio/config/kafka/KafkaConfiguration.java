package com.mm.enterprise.genericadaptersvio.config.kafka;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javax.validation.constraints.NotNull;

@Getter
@Setter
@NoArgsConstructor
@Configuration
public class KafkaConfiguration {

    @Value(value = "${mm.common.kafka.brokers.url}")
    @NotNull
    private String kafkaUrl;

    @Value(value = "${mm.common.kafka.schema.url:#{null}}")
    private String schemaUrl;

    @Value(value = "${mm.common.kafka.security.protocol:#{null}}")
    private String securityProtocol;

    @Value(value = "${mm.common.kafka.basic.auth.credentials.source:#{null}}")
    private String authCredentialSource;

    @Value(value = "${mm.common.kafka.basic.auth.user.info:#{null}}")
    private String authUserInfo;

    @Value(value = "${mm.common.kafka.sasl.mechanism:#{null}}")
    private String saslMechanism;

    @Value(value = "${mm.common.kafka.sasl.jaas.config:#{null}}")
    private String saslJaasConfig;

    @Value(value = "${javax.net.ssl.trustStore:#{null}}")
    private String trustStore;

    @Value(value = "${javax.net.ssl.trustStorePassword:#{null}}")
    private String trustStorePassword;
}
