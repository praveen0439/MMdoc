package com.mm.enterprise.genericadaptersvio.mapper;

import businesscustomers.event.agreements.institutionalcontrol.completed.EventHeader;
import businesscustomers.event.agreements.institutionalcontrol.completed.EventSourceFileType;
import businesscustomers.event.agreements.institutionalcontrol.completed.Metadata;
import businesscustomers.event.agreements.institutionalcontrol.completed.SvioControlCompleted;
import com.mm.enterprise.genericadaptersvio.model.control.ControlInput;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import static com.mm.enterprise.genericadaptersvio.util.Constants.*;
import static com.mm.enterprise.genericadaptersvio.util.ItemProcessorHelper.removeLeadingZeroes;

@Component
@Slf4j(topic = "logger")
@RequiredArgsConstructor
public class ControlDisbursementsMapper {

    public SvioControlCompleted mapFromFlatFile(ControlInput input, String fileName, String eventBatchGroupId) {

        LocalDateTime currentDateTime = LocalDateTime.now(ZoneId.of(ZONE_ID_EST));
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATETIME_FORMAT);
        final String eventCorrelationId = UUID.randomUUID().toString();
        final Metadata metadata = Metadata.newBuilder()
                .setEventSourceFilename(fileName)
                .setEventSourceRunDate(input.getFileRunDate().trim())
                .setEventSourceRunTime(input.getFileRunTime().trim())
                .setEventSourceValuationDate(input.getEffectiveDate().trim())
                .setEventSourceReferencedFilename(input.getFileName().trim())
                .setEventSourceFileType(EventSourceFileType.DISBURSEMENTS)
                .setProcessedDate(LocalDate.now())
                .build();

        String eventBatchRecordCountTotal = removeLeadingZeroes(input.getRecordCount().trim());
        final EventHeader eventHeader = EventHeader.
                newBuilder()
                .setMetadata(metadata)
                .setEventBatchGroupId(eventBatchGroupId)
                .setEventBatchRecordCountTotal(eventBatchRecordCountTotal.isBlank() ? "0" : eventBatchRecordCountTotal)
                .setEventBatchTotalAmt(String.valueOf(input.getFacTotals()).trim())
                .setEventSource(EVENT_SOURCE)
                .setEventSourceDescription(EVENT_SOURCE_DESCRIPTION_DISBURSEMENTS)
                .setEventInitiator(GENERIC_ADAPTER_SVIO)
                .setEventInitiatorDescription(EVENT_INITIATOR_DESC_DISBURSEMENTS)
                .setEventGeneratedDateTime(currentDateTime.format(dateTimeFormatter))
                .setEventType(REQUEST_EVENT_TYPE)
                .setEventCorrelationId(eventCorrelationId)
                .build();

        return SvioControlCompleted.newBuilder()
                .setEventHeader(eventHeader)
                .build();
    }

}
