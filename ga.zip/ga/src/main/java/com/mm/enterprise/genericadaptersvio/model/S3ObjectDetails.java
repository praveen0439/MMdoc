package com.mm.enterprise.genericadaptersvio.model;

import lombok.Builder;

import java.util.List;
import java.util.Objects;

@Builder
public record S3ObjectDetails(String bucketName, String bucketKey,
                              String bucketETag, long bucketSize,
                              List<JobParamsRequest> jobParamsRequestList) {

    public S3ObjectDetails(String bucketName, String bucketKey, String bucketETag,
                           long bucketSize, List<JobParamsRequest> jobParamsRequestList) {

        this.bucketName = Objects.requireNonNull(bucketName);
        this.bucketKey = Objects.requireNonNull(bucketKey);
        this.bucketETag = Objects.requireNonNull(bucketETag);
        this.bucketSize = bucketSize;
        this.jobParamsRequestList = jobParamsRequestList;
    }
}
