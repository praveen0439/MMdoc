package com.mm.enterprise.genericadaptersvio.mapper;

import businesscustomers.event.agreements.institutionaltransactions.requested.*;
import com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions;
import com.mm.enterprise.genericadaptersvio.model.transaction.TransactionInput;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

import static com.mm.enterprise.genericadaptersvio.util.Constants.*;

@Component
@Slf4j(topic = "logger")
@RequiredArgsConstructor
public class TransactionsMapper {

    public SVIOTransactions mapFromFlatFile(TransactionInput transactionInput, String eventBatchGroupId, String inputFileName) {
        log.debug(String.format("Starting conversion from flat file to Transaction json with EventBatchGroupId %s.", eventBatchGroupId));

        if (transactionInput == null) {
            throw new GenericAdapterExceptions.EmptyTransactionsInput("Exception while mapping from flat file: TransactionsInput is empty");
        }

        final Metadata metadata = createMetadata(inputFileName);
        final EventHeader eventHeader = createEventHeader( metadata, eventBatchGroupId, transactionInput.getValuationDate());
        final Contract contract = createContract(transactionInput);
        final PayoutTransaction payoutTransaction = createPayoutTransaction(transactionInput);
        final Transaction transaction = createTransaction(transactionInput);
        final Trade trade = createTrade(transactionInput);

        return SVIOTransactions.newBuilder()
                .setEventHeader(eventHeader)
                .setContract(contract)
                .setPayoutTransaction(payoutTransaction)
                .setTransaction(transaction)
                .setTrade(trade)
                .build();

    }

    private Trade createTrade(final TransactionInput input) {
        return Trade.newBuilder()
                .setTradeDate(input.getValuationDate())
                .setSettlementDate(input.getSettlementDate())
                .build();
    }

    private Transaction createTransaction(final TransactionInput input) {

        return Transaction.newBuilder()
                .setEffectiveDate(getOptionalValue(input.getEffectiveDate()))
                .setTypeCode(getOptionalValue(input.getTransactionType()))
                .build();
    }

    private PayoutTransaction createPayoutTransaction(TransactionInput transactionInput) {
        final String secondChar = transactionInput.getTaxStateCode().substring(1);
        final String transformedTaxCode = transactionInput.getTaxStateCode().replaceFirst(secondChar, secondChar.toLowerCase());

        final Payout payout = Payout.newBuilder()
                .setMethodCode(getOptionalValue(transactionInput.getTransactionMarketAmount().doubleValue() < 0.0 ? transactionInput.getPaymentMethod() : null))
                .setPostingDate(getOptionalValue(transactionInput.getProcessingDate()))
                .build();

        final Payee payee = Payee.newBuilder()
                .setAddress(List.of(Address.newBuilder()
                        .setStateOrProvinceCode(StateOrProvinceCode.valueOf(transformedTaxCode))
                        .build()))
                .build();

        return PayoutTransaction.newBuilder()
                .setPayout(payout)
                .setPayee(payee)
                .build();
    }

    private Contract createContract(TransactionInput input) {
        final Distributor distributor = createDistributor(input);
        final Investment investment = createInvestment(input);

        return Contract.newBuilder()
                .setDistributor(distributor)
                .setInvestment(investment)
                .setEffectiveDate(input.getContractEffectiveDate())
                .setSuffix(input.getSubAccountNumber())
                .setPrimaryId(input.getAccountNumber())
                .build();
    }

    private Investment createInvestment(TransactionInput input) {
        final Fund fund = createFund(input);

        return Investment.newBuilder()
                .setFund(fund)
                .setTypeCode(getOptionalValue(input.getInvestmentType()))
                .setUnitCount(getUnitCount(input))
                .setValue(String.valueOf(input.getTransactionMarketAmount()))
                .build();
    }

    private Fund createFund(final TransactionInput input) {
        return Fund.newBuilder()
                .setReference(Reference.newBuilder().setId(input.getReferenceId()).build())
                .setAdminNumber(input.getFundId())
                .build();
    }

    private Distributor createDistributor(final TransactionInput input) {
        return Distributor.newBuilder()
                .setNumber(getOptionalValue(input.getTransactionMarketAmount().doubleValue() >= 0.0 ? input.getPaymentMethod() : null))
                .build();
    }

    private Metadata createMetadata(final String inputFileName) {
        return Metadata.newBuilder()
                .setEventSourceFilename(inputFileName)
                .setFileGeneratedDate(getOptionalValue(inputFileName.substring(6,14)))
                .setProcessedDate(LocalDate.now())
                .build();
    }

    private EventHeader createEventHeader( Metadata metadata, String eventBatchGroupId, String valuationDate) {
        final String eventCorrelationId = UUID.randomUUID().toString();
        LocalDateTime currentDateTime = LocalDateTime.now(ZoneId.of(ZONE_ID_EST));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATETIME_FORMAT);


        return EventHeader.newBuilder()
                .setMetadata(metadata)
                .setEventType(REQUEST_EVENT_TYPE)
                .setEventSubtype(EVENT_SUBTYPE_TRANSACTIONS)
                .setEventDateTime(valuationDate)
                .setEventGeneratedDateTime(currentDateTime.format(formatter))
                .setEventCorrelationId(eventCorrelationId)
                .setEventRequestId(eventCorrelationId)
                .setEventSourceDescription(EVENT_SOURCE_DESCRIPTION_TRANSACTIONS)
                .setEventSource(EVENT_SOURCE)
                .setEventInitiator(GENERIC_ADAPTER_SVIO)
                .setEventInitiatorDescription(EVENT_INITIATOR_DESC_TRANSACTIONS)
                .setEventBatchGroupId(eventBatchGroupId)
                .build();
    }

    private String getOptionalValue(String value) {
        if (value != null && value.isEmpty())
            return null;

        return value;
    }

    private String getUnitCount(TransactionInput input) {
        String marketShares = String.valueOf(input.getTransactionMarketShares());
       if(marketShares.isEmpty() || marketShares.equals("null"))
                return null;
       return marketShares;
    }
}
