package com.mm.enterprise.genericadaptersvio.config.job.tasklet;

import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

import static com.mm.enterprise.genericadaptersvio.util.Constants.S3_BUCKET_KEY_PARAM;
import static com.mm.enterprise.genericadaptersvio.util.Constants.S3_BUCKET_SIZE;

@Component
@RequiredArgsConstructor
public class EmptyFileTask implements Tasklet {
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        final Long bucketSize = chunkContext.getStepContext().getStepExecution().getJobExecution().getJobParameters().getLong(S3_BUCKET_SIZE);
        final String bucketKey = chunkContext.getStepContext().getStepExecution().getJobParameters().getString(S3_BUCKET_KEY_PARAM);

        if(bucketSize != null && bucketSize == 0) {
            throw new IllegalArgumentException(String.format("Empty %s file provided.", bucketKey));
        }
        return RepeatStatus.FINISHED;
    }
}
