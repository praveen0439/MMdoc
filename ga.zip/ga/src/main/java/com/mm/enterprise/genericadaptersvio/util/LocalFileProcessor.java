package com.mm.enterprise.genericadaptersvio.util;


import com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions.LocalFileWriteException;
import com.mm.enterprise.genericadaptersvio.exception.GenericAdapterExceptions.LocalFolderException;
import com.mm.enterprise.genericadaptersvio.model.S3ObjectDetails;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static com.mm.enterprise.genericadaptersvio.util.Constants.LOCAL_DATA_FOLDER;


@Slf4j
public final class LocalFileProcessor {
    public static String save(S3ObjectDetails s3ObjectDetails, byte[] data) {

        createLocalFolderStructureIfNotExists();

        final String fileName = s3ObjectDetails.bucketKey().replace("/", "-");
        final Path localPath = Path.of(LOCAL_DATA_FOLDER, fileName);

        try {
            Files.write(localPath, data);
            return localPath.toAbsolutePath().toString();
        } catch (IOException ex) {
            String message = String.format("Could not write S3 object %s locally %s.",
                    s3ObjectDetails.bucketName() + s3ObjectDetails, ex.getMessage());
            log.error(message);
            throw new LocalFileWriteException(message);
        }
    }

    private static void createLocalFolderStructureIfNotExists() {
        final Path localDirPath = Path.of(LOCAL_DATA_FOLDER);
        if (Files.exists(localDirPath)) {
            return;
        }

        try {
            Files.createDirectories(localDirPath);
        } catch (IOException e) {
            log.error("Could not create local folder for {}", localDirPath);
            throw new LocalFolderException("Exception while trying to create local folder " + localDirPath);
        }
    }

    public static void removeLocallyCached(String bucketName, String bucketKey) {
        log.info("Removing cached file for bucket name={}, key={}", bucketName, bucketKey);
        final String fileName = bucketKey.replace("/", "-");
        removeLocalFile(Path.of(LOCAL_DATA_FOLDER, fileName));
    }

    public static void removeLocalFile(Path filePath) {
        try {
            Files.delete(filePath);
            log.info("File {} deleted successfully", filePath);
        } catch (IOException e) {
            log.error("Failed to delete the file {} ", filePath);
            throw new LocalFolderException("Exception while trying to delete local folder " + filePath);
        }
    }

    private LocalFileProcessor() {
    }
}
