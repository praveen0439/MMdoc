package com.mm.enterprise.genericadaptersvio.mapper;

import businesscustomers.event.disbursements.institutionaldisbursement.requested.*;
import com.mm.enterprise.genericadaptersvio.model.disbursements.DisbursementsInput;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Predicate;

import static com.mm.enterprise.genericadaptersvio.util.Constants.*;

@Component
@Slf4j(topic = "logger")
@RequiredArgsConstructor
public class DisbursementsMapper {


    public InstitutionalDisbursementInitiated mapFromFlatFile(DisbursementsInput input,String eventBatchGroupId, String inputFileName) {

        Optional<String> postingDate;
        Optional<String> TypeCode;
        Optional<Boolean> reversalIndicator;
        Optional<String> reversalCode;
        Optional<StateOrProvinceCode> stateOrProvinceCode = Optional.empty();
        Optional<String> bankName;
        Optional<String> bankAccountId;
        Optional<String> accountNumber;
        Optional<String> fullName;
        Optional<String> instructionLine4;
        Optional<String> instructionLine5;
        Optional<String> instructionLine6;
        Optional<String> bankName2;
        Optional<String> city;
        Optional<String> distributorNumber;
        Optional<String> effectiveDate;
        Optional<String> fileGeneratedDate;

        TypeCode = getOptionalFilteredValue(input.getInvestmentContractType().trim());
        distributorNumber = getOptionalFilteredValue(input.getRecordKeeper().trim());
        postingDate = getOptionalFilteredValue(input.getProcessing_postingDate().trim());
        effectiveDate = getOptionalFilteredValue(input.getEffectiveDate());
        city = getOptionalFilteredValue(input.getBankCity().trim());
        stateOrProvinceCode = Optional.ofNullable(findStateOrProvinceCode(input.getWireState()));
        fullName = getOptionalFilteredValue(input.getInstructionLine3().trim());
        bankAccountId = getOptionalFilteredValue(input.getInstructionLine1().trim());
        accountNumber = getOptionalFilteredValue(input.getInstructionLine2().trim());
        bankName = getOptionalFilteredValue(input.getPayeeName().trim());
        reversalCode = getOptionalFilteredValue(input.getReversalReason().trim());
        reversalIndicator = Optional.ofNullable(getreversalFlag(input.getReversalFlag().trim()));
        bankName2 = getOptionalFilteredValue(input.getBankName().trim());
        fileGeneratedDate = getOptionalFilteredValue(ExtractfileGeneratedDate(inputFileName));
        instructionLine4 = getOptionalFilteredValue(input.getInstructionLine4().trim());
        instructionLine5 = getOptionalFilteredValue(input.getInstructionLine5().trim());
        instructionLine6 = getOptionalFilteredValue(input.getInstructionLine6().trim());


        final Contract contract = createContract(input, TypeCode, distributorNumber);
        final Trade trade = createTrade(input);
        final PayoutTransaction payoutTransaction = createPayoutTransaction(input, postingDate, effectiveDate, stateOrProvinceCode, city, fullName, bankAccountId, accountNumber, bankName);
        final Transaction transaction = createTransaction(input, reversalCode, reversalIndicator);
        final EventHeader eventHeader = createEventHeader(inputFileName,eventBatchGroupId, bankName2, fileGeneratedDate, instructionLine4, instructionLine5, instructionLine6);
        return InstitutionalDisbursementInitiated.newBuilder().setContract(contract).setTrade(trade).setPayoutTransaction(payoutTransaction).setTransaction(transaction).setEventHeader(eventHeader).build();
    }

    private String ExtractfileGeneratedDate(String filename) {
        return filename.replaceAll("[^0-9]", "").substring(0,8);
    }

    private Boolean getreversalFlag(String flag) {
        Boolean reversalFlag = null;
        if (flag.equals("Y")) reversalFlag = Boolean.TRUE;
        else if (flag.equals("N")) reversalFlag = Boolean.FALSE;
        return reversalFlag;
    }

    private Contract createContract(DisbursementsInput input, Optional<String> TypeCode, Optional<String> distributorNumber) {

        final Reference reference = Reference.newBuilder()
                .setId(input.getPooledFundNumber().trim())
                .build();

        final Fund fund = Fund.newBuilder()
                .setAdminNumber(input.getFundID().trim())
                .setReference(reference)
                .build();

        final Investment investment = BuilderWrapper.modify(Investment.newBuilder()
                .setFund(fund))
                .ifPresent(TypeCode, Investment.Builder::setTypeCode)
                .get()
                .build();

        final Distributor distributor = BuilderWrapper.modify(Distributor.newBuilder())
                .ifPresent(distributorNumber, Distributor.Builder::setNumber)
                .get()
                .build();

        return Contract.newBuilder().setInvestment(investment)
                .setPrimaryId(input.getMasterContractNumber().trim())
                .setSuffix(input.getSubPlanNumber().trim())
                .setDistributor(distributor)
                .build();
    }

    private Trade createTrade(DisbursementsInput input) {
        return Trade.newBuilder()
                .setTradeDate(input.getTradeDate().trim())
                .setSettlementDate(input.getSettlementDate().trim()).build();
    }

    private PayoutTransaction createPayoutTransaction(DisbursementsInput input, Optional<String> postingDate, Optional<String> effectiveDate, Optional<StateOrProvinceCode> stateOrProvinceCode, Optional<String> city, Optional<String> fullName, Optional<String> bankAccountId, Optional<String> accountNumber, Optional<String> bankName) {


        final Payout payout = BuilderWrapper.modify(Payout.newBuilder()
                .setAmountItem(String.valueOf(input.getMarketAmount()).trim())
                .setMethodCode(input.getPaymentMethod().trim()))
                .ifPresent(postingDate, Payout.Builder::setPostingDate)
                .ifPresent(effectiveDate, Payout.Builder::setEffectiveDate)
                .get()
                .build();

        final Address payeeAddress = BuilderWrapper.modify(Address.newBuilder())
                .ifPresent(stateOrProvinceCode, Address.Builder::setStateOrProvinceCode)
                .ifPresent(city, Address.Builder::setCity)
                .get()
                .build();

        final Address contractAddress = Address.newBuilder()
                .setStateOrProvinceCode(findStateOrProvinceCode(input.getTaxStateCode()))
                .build();

        final Owner owner = Owner.newBuilder().
                setAddress(contractAddress)
                .build();

        final Name name = BuilderWrapper.modify(Name.newBuilder())
                .ifPresent(fullName, Name.Builder::setFullName)
                .get()
                .build();

        final PayoutTransactionContract contract = PayoutTransactionContract.newBuilder()
                .setOwner(owner)
                .build();

        final BankAccount payeeBankAccount = BuilderWrapper.modify(BankAccount.newBuilder())
                .ifPresent(bankAccountId, BankAccount.Builder::setId)
                .ifPresent(accountNumber, BankAccount.Builder::setAccountNumber)
                .ifPresent(bankName, BankAccount.Builder::setBankName)
                .get()
                .build();

        final Payee payee = Payee.newBuilder()
                .setAddress(payeeAddress)
                .setName(name)
                .setBankAccount(payeeBankAccount)
                .build();

        return PayoutTransaction.newBuilder()
                .setPayee(payee)
                .setPayout(payout)
                .setContract(contract)
                .build();
    }

    private Transaction createTransaction(DisbursementsInput input, Optional<String> reversalCode, Optional<Boolean> reversalIndicator) {
        return BuilderWrapper.modify(Transaction.newBuilder())
                .ifPresent(reversalCode, Transaction.Builder::setReversalCode)
                .ifPresent(reversalIndicator, Transaction.Builder::setReversalIndicator)
                .get()
                .build();
    }

    private EventHeader createEventHeader(String inputFileName,String eventBatchGroupId,Optional<String> bankName2, Optional<String> fileGeneratedDate, Optional<String> instructionLine4, Optional<String> instructionLine5, Optional<String> instructionLine6) {
        LocalDateTime currentDateTime = LocalDateTime.now(ZoneId.of(ZONE_ID_EST));
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATETIME_FORMAT);
        DateTimeFormatter dateformatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
        final String eventCorrelationId = UUID.randomUUID().toString();


        final Metadata metadata = BuilderWrapper.modify(Metadata.newBuilder()
                        .setEventSourceFilename(inputFileName))
                .ifPresent(bankName2, Metadata.Builder::setBankName2)
                .ifPresent(fileGeneratedDate, Metadata.Builder::setFileGeneratedDate)
                .ifPresent(instructionLine4, Metadata.Builder::setInstructionLine4)
                .ifPresent(instructionLine5, Metadata.Builder::setInstructionLine5)
                .ifPresent(instructionLine6, Metadata.Builder::setInstructionLine6)
                .get()
                .build();
        metadata.setProcessedDate(LocalDate.now());

        return EventHeader.newBuilder()
                .setMetadata(metadata)
                .setEventType(REQUEST_EVENT_TYPE)
                .setEventSubtype(EVENT_SUBTYPE_DISBURSEMENTS)
                .setEventDateTime(currentDateTime.format(dateformatter))
                .setEventGeneratedDateTime(currentDateTime.format(dateTimeFormatter))
                .setEventCorrelationId(eventCorrelationId)
                .setEventRequestId(eventCorrelationId)
                .setEventSourceDescription(EVENT_SOURCE_DESCRIPTION_DISBURSEMENTS)
                .setEventSource(EVENT_SOURCE)
                .setEventInitiator(GENERIC_ADAPTER_SVIO)
                .setEventInitiatorDescription(EVENT_INITIATOR_DESC_DISBURSEMENTS)
                .setEventBatchGroupId(eventBatchGroupId)
                .build();

    }

    public static final String capitalizeFirstChar(String str) {
        if (str == null || str.length() == 0) return str;
        return str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase();
    }

    private Optional<String> getOptionalFilteredValue(String value) {
        return Optional.ofNullable(value).filter(Predicate.not(String::isBlank));
    }


    public static StateOrProvinceCode findStateOrProvinceCode(String state) {
        state = capitalizeFirstChar(state);
        StateOrProvinceCode result = null;
        for (StateOrProvinceCode stateOrProvinceCode : StateOrProvinceCode.values()) {
            if (stateOrProvinceCode.name().equalsIgnoreCase(state)) {
                result = stateOrProvinceCode;
                break;
            }
        }
        return result;
    }

}
