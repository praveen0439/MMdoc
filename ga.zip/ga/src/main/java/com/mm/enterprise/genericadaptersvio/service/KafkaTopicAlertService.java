package com.mm.enterprise.genericadaptersvio.service;

import com.mm.enterprise.genericadaptersvio.config.alert.AlertProperties;
import com.mm.enterprise.genericadaptersvio.config.alert.AlertRecipients;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import com.mm.enterprise.alert.info.Email;
import com.mm.enterprise.alert.info.InfoMessage;
import com.mm.enterprise.alert.info.Slack;
import com.mm.enterprise.alert.info.XMatters;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Service
@Slf4j(topic = "logger")
@EnableConfigurationProperties(AlertProperties.class)
public class KafkaTopicAlertService {

    private final String appName;
    private final AlertProperties alertProperties;
    private final KafkaTemplate<String, Object> kafkaTemplate;

    public KafkaTopicAlertService(@Value("${application.name}") String appName,
                                  AlertProperties alertProperties,
                                  @Qualifier("transactionsKafkaTemplate") KafkaTemplate<String, Object> kafkaTemplate) {
        this.appName = appName;
        this.alertProperties = alertProperties;
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendNotification(String message) throws ExecutionException, InterruptedException, TimeoutException {
        for (AlertRecipients recipient : alertProperties.getRecipients()) {
            send(buildAlertMessage(message,
                    recipient.getNotificationSubject(),
                    recipient.getNotificationEmail(),
                    recipient.getNotificationSlackChannel(),
                    recipient.getNotificationWebhook(),
                    recipient.getNotificationIconEmoji()));
            log.info("Notification sent to: {}", recipient);
        }
    }


    public void sendError(String message) {
        for (AlertRecipients recipient : alertProperties.getRecipients()) {
            final var errAlert = buildAlertMessage(message,
                    recipient.getErrorSubject(),
                    recipient.getErrorEmail(),
                    recipient.getErrorSlackChannel(),
                    recipient.getErrorWebhook(),
                    recipient.getErrorIconEmoji());

            if (Boolean.TRUE.equals(recipient.getXmattersEnabled())) {
                errAlert.setXMattersList(List.of(XMatters.newBuilder()
                        .setSubject(recipient.getErrorSubject())
                        .setMessage(message)
                        .setType(recipient.getXmattersType())
                        .setGroupName(recipient.getXmattersGroupName())
                        .build()));
            }
            try {
                send(errAlert);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            log.info("Error message sent to: {}", recipient);
        }
    }

    private void send(InfoMessage alert) throws ExecutionException, InterruptedException, TimeoutException {
        alert.setAppName(appName);
        CompletableFuture<SendResult<String, Object>> future = kafkaTemplate.send(alertProperties.getTopic(), alert);
        kafkaTemplate.flush();
        SendResult<String, Object> result = future.get(1, TimeUnit.SECONDS);
        log.info("Sent the message to topic: {} on partition: {} and offset: {}", result.getRecordMetadata().topic(),
                result.getRecordMetadata().partition(), result.getRecordMetadata().offset());
    }


    private InfoMessage buildAlertMessage(String msg, String subject, String email, String slackChannel, String webhook, String iconEmoji) {
        final InfoMessage alert = new InfoMessage();
        alert.setEmailList(List.of(Email.newBuilder()
                .setEmailAddresses(List.of(email))
                .setSubject(subject)
                .setMessage(msg)
                .build()));

        alert.setSlackList(List.of(Slack.newBuilder()
                .setChannel(slackChannel)
                .setWebhook(webhook)
                .setSubject(subject)
                .setMessage(msg)
                .setIconEmoji(iconEmoji)
                .build()));
        return alert;
    }
}
