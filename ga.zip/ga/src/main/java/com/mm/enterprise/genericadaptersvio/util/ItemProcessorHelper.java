package com.mm.enterprise.genericadaptersvio.util;


import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;

import java.util.UUID;

import static com.mm.enterprise.genericadaptersvio.util.Constants.EVENT_BATCH_GROUP_ID;
import static com.mm.enterprise.genericadaptersvio.util.Constants.WRITE_COUNT;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ItemProcessorHelper {
    private static ExecutionContext getExecutionContext(StepExecution stepExecution) {
        return stepExecution.getJobExecution().getExecutionContext();
    }

    public static String getEventBatchGroupId(StepExecution stepExecution) {
        ExecutionContext jobExecutionContext = getExecutionContext(stepExecution);
        if (jobExecutionContext.containsKey(EVENT_BATCH_GROUP_ID)) {
            return jobExecutionContext.getString(EVENT_BATCH_GROUP_ID);
        } else {
            final String eventBatchGroupId = UUID.randomUUID().toString();
            jobExecutionContext.putString(EVENT_BATCH_GROUP_ID, eventBatchGroupId);
            return eventBatchGroupId;
        }
    }

    public static void updateWriteCount(StepExecution stepExecution) {
        getExecutionContext(stepExecution).putLong(WRITE_COUNT, stepExecution.getWriteCount());
    }

    public static String removeLeadingZeroes(String value) {
        int i = 0;
        while (i < value.length() && value.charAt(i) == '0') {
            i++;
        }
        return new StringBuffer(value).replace(0, i, "").toString();
    }
}
