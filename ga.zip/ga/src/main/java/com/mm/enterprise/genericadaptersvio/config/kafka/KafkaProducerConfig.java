package com.mm.enterprise.genericadaptersvio.config.kafka;

import io.confluent.kafka.serializers.AbstractKafkaSchemaSerDeConfig;
import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import io.confluent.kafka.serializers.KafkaAvroSerializerConfig;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.internals.DefaultPartitioner;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import javax.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.Map;

@Configuration
@RequiredArgsConstructor
public class KafkaProducerConfig {

    @NotNull
    @Value(value = "${mm.common.kafka.producer.client.id}")
    private String clientId;

    @NotNull
    @Value(value = "${mm.common.kafka.producer.block.timeout:60000}")
    private Integer kafkaProducerBlockTimeout;

    @Value(value = "${mm.common.kafka.producer.request.timeout:30000}")
    private Integer kafkaProducerRequestTimeout;

    @Value(value = "${mm.common.kafka.producer.acks:all}")
    private String kafkaAcks;

    @Value(value = "${mm.common.kafka.producer.retries:5}")
    private Integer kafkaProducerRetries;

    @NotNull
    @Value(value = "${generic.adapter.svio.transactions.topic}")
    private String transactionsTopic;

    @NotNull
    @Value(value = "${generic.adapter.svio.transactionsextract.topic}")
    private String transactionsextractTopic;

    @NotNull
    @Value(value = "${generic.adapter.svio.control.topic}")
    private String controlTopic;

    @NotNull
    @Value(value = "${generic.adapter.svio.done.topic}")
    private String doneTopic;

    @NotNull
    @Value(value = "${generic.adapter.svio.disbursements.topic}")
    private String disbursementsTopic;

    @NotNull
    @Value(value = "${generic.adapter.svio.shareholderextract.topic}")
    private String shareholderExtractTopic;

    private final KafkaConfiguration kafkaConfiguration;

    public Map<String, Object> kafkaProducerConfiguration() {
        Map<String, Object> configs = getProducerConfiguration();
        KafkaHelpers.enableKafkaSecurity(configs,
                kafkaConfiguration.getTrustStore(),
                kafkaConfiguration.getTrustStorePassword(),
                kafkaConfiguration.getSecurityProtocol(),
                kafkaConfiguration.getAuthCredentialSource(),
                kafkaConfiguration.getAuthUserInfo(),
                kafkaConfiguration.getSaslMechanism(),
                kafkaConfiguration.getSaslJaasConfig());
        return configs;
    }

    private Map<String, Object> getProducerConfiguration() {
        Map<String, Object> configs = new HashMap<>();
        configs.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaConfiguration.getKafkaUrl());
        configs.put(ProducerConfig.CLIENT_ID_CONFIG, clientId);
        configs.put(ProducerConfig.MAX_BLOCK_MS_CONFIG, kafkaProducerBlockTimeout);
        configs.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, kafkaProducerRequestTimeout);
        configs.put(ProducerConfig.ACKS_CONFIG, kafkaAcks);
        configs.put(ProducerConfig.RETRIES_CONFIG, kafkaProducerRetries);
        configs.put(ProducerConfig.PARTITIONER_CLASS_CONFIG, DefaultPartitioner.class);
        configs.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configs.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class.getName());
        configs.put(ProducerConfig.CLIENT_DNS_LOOKUP_CONFIG, "use_all_dns_ips");
        configs.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, "true");
        configs.put(AbstractKafkaSchemaSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, kafkaConfiguration.getSchemaUrl());
        configs.put(AbstractKafkaSchemaSerDeConfig.AUTO_REGISTER_SCHEMAS, "false");
        configs.put(KafkaAvroSerializerConfig.AVRO_REMOVE_JAVA_PROPS_CONFIG, "true");
        return configs;
    }

    @Bean
    public ProducerFactory<String, Object> producerFactory() {
        return new DefaultKafkaProducerFactory<>(kafkaProducerConfiguration());
    }

    @Bean
    @Qualifier("transactionsKafkaTemplate")
    public KafkaTemplate<String, Object> transactionsKafkaTemplate() {
        KafkaTemplate<String, Object> kafkaTemplate = new KafkaTemplate<>(producerFactory());
        kafkaTemplate.setDefaultTopic(transactionsTopic);
        return kafkaTemplate;
    }

    @Bean
    @Qualifier("transactionExtractKafkaTemplate")
    public KafkaTemplate<String, Object> transactionExtractKafkaTemplate() {
        KafkaTemplate<String, Object> kafkaTemplate = new KafkaTemplate<>(producerFactory());
        kafkaTemplate.setDefaultTopic(transactionsextractTopic);
        return kafkaTemplate;
    }

    @Bean
    @Qualifier("controlKafkaTemplate")
    public KafkaTemplate<String, Object> controlKafkaTemplate() {
        KafkaTemplate<String, Object> kafkaTemplate = new KafkaTemplate<>(producerFactory());
        kafkaTemplate.setDefaultTopic(controlTopic);
        return kafkaTemplate;
    }

    @Bean
    @Qualifier("doneKafkaTemplate")
    public KafkaTemplate<String, Object> doneKafkaTemplate() {
        KafkaTemplate<String, Object> kafkaTemplate = new KafkaTemplate<>(producerFactory());
        kafkaTemplate.setDefaultTopic(doneTopic);
        return kafkaTemplate;
    }
    @Bean
    @Qualifier("disbursementsKafkaTemplate")
    public KafkaTemplate<String, Object> disbursementsKafkaTemplate() {
        KafkaTemplate<String, Object> kafkaTemplate = new KafkaTemplate<>(producerFactory());
        kafkaTemplate.setDefaultTopic(disbursementsTopic);
        return kafkaTemplate;
    }
    @Bean
    @Qualifier("shareholderExtractKafkaTemplate")
    public KafkaTemplate<String, Object> shareholderExtractKafkaTemplate() {
        KafkaTemplate<String, Object> kafkaTemplate = new KafkaTemplate<>(producerFactory());
        kafkaTemplate.setDefaultTopic(shareholderExtractTopic);
        return kafkaTemplate;
    }
}
