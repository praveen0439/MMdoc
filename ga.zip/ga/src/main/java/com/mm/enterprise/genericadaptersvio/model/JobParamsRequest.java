package com.mm.enterprise.genericadaptersvio.model;

import lombok.Builder;

@Builder
public record JobParamsRequest(String paramKey, String paramValue) {
}