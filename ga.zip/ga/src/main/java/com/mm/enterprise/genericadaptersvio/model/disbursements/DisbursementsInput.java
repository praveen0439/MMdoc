package com.mm.enterprise.genericadaptersvio.model.disbursements;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DisbursementsInput {
    @Size(max=10,message = "Pooled Fund Number should not be greater than 10 characters!")
    @NotBlank(message = "Pooled Fund Number is required")
    private String pooledFundNumber;

    @Size(max=10,message = "Fund ID should not be greater than 10 characters!")
    @NotBlank(message = "Fund ID is required")
    private String fundID;

    @Size(max=9,message = "Master Contract Number should not be greater than 9 characters!")
    @NotBlank(message = "Master Contract Number is required")
    private String masterContractNumber;

    @Size(max=2,message = "Sub-Plan Number should not be greater than 2 characters!")
    @NotBlank(message = "Sub-Plan Number is required")
    private String subPlanNumber;

    @Size(max=8,message = "Trade Date should not be greater than 8 characters!")
    @Pattern(regexp = "((19|2[0-9][0-9]{2})(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01]))", message = "Trade Date should respect the following pattern: yyyymmdd")
    private String tradeDate;

    @Size(max=8,message = "Processing/Posting Date should not be greater than 8 characters!")
    private String processing_postingDate;

    @Size(max=8,message = "Settlement Date should not be greater than 8 characters!")
    @NotBlank(message = "Settlement Date is required")
    @Pattern(regexp = "((19|2[0-9][0-9]{2})(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01]))", message = "Settlement Date should respect the following pattern: yyyymmdd")
    private String settlementDate;

    @NotNull(message = "Market Amount is required")
    @Digits(integer=15,fraction = 2,message = "Market Amount format should be 999999999999999.99 or -999999999999999.99")
    private BigDecimal marketAmount;

    @Size(max=2,message = "Investment Contract Type should not be greater than 2 digits!")
    private String investmentContractType;

    @Size(max=2,message = "Payment Method should not be greater than 2 characters!")
    @NotBlank(message = "Payment Method is required")
    private String paymentMethod;

    @Size(max=2,message = "Tax State Code should not be greater than 2 characters!")
    @NotBlank(message = "Tax State Code is required")
    private String taxStateCode;

    @Size(max=8,message = "Effective Date should not be greater than 8 characters!")
    private String effectiveDate;

    @Size(max=1,message = "Reversal Flag should not be greater than 1 characters!")
    private String reversalFlag;

    @Size(max=2,message = "Reversal Reason should not be greater than 2 characters!")
    private String reversalReason;

    @Size(max=100,message = "Wire State should not be greater than 100 characters!")
    private String wireState;

    @Size(max=100,message = "Payee Name should not be greater than 100 characters!")
    private String payeeName;

    @Size(max=100,message = "InstructionLine 1 should not be greater than 100 characters!")
    private String instructionLine1;

    @Size(max=100,message = "InstructionLine 2 should not be greater than 100 characters!")
    private String instructionLine2;

    @Size(max=100,message = "InstructionLine 3 should not be greater than 100 characters!")
    private String instructionLine3;

    @Size(max=100,message = "InstructionLine 4 should not be greater than 100 characters!")
    private String instructionLine4;

    @Size(max=100,message = "InstructionLine 5 should not be greater than 100 characters!")
    private String instructionLine5;

    @Size(max=100,message = "InstructionLine 6 should not be greater than 100 characters!")
    private String instructionLine6;

    @Size(max=100,message = "Bank Name should not be greater than 100 characters!")
    private String bankName;

    @Size(max=100,message = "Bank City should not be greater than 100 characters!")
    private String bankCity;

    @Size(max=100,message = "Record Keeper should not be greater than 100 characters!")
    private String recordKeeper;

}
