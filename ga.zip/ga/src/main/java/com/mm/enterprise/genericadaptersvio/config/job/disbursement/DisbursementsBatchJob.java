package com.mm.enterprise.genericadaptersvio.config.job.disbursement;

import businesscustomers.event.disbursements.institutionaldisbursement.requested.InstitutionalDisbursementInitiated;
import com.mm.enterprise.genericadaptersvio.listener.SvioJobExecutionListener;
import com.mm.enterprise.genericadaptersvio.model.disbursements.DisbursementsInput;
import com.mm.enterprise.genericadaptersvio.processor.DisbursementsProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.kafka.KafkaItemWriter;
import org.springframework.batch.item.kafka.builder.KafkaItemWriterBuilder;
import org.springframework.batch.item.support.CompositeItemProcessor;
import org.springframework.batch.item.validator.BeanValidatingItemProcessor;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.List;

import static com.mm.enterprise.genericadaptersvio.config.job.BatchJobType.DISBURSEMENTS_CHUNK_JOB;
import static com.mm.enterprise.genericadaptersvio.util.Constants.*;

@Slf4j(topic = "logger")
@Configuration
@RequiredArgsConstructor
public class DisbursementsBatchJob {

    @Value(value = "${generic.adapter.svio.chunk.size:100}")
    private Integer batchChunkSize;

    @Value(value = "${generic.adapter.svio.retry.limit:3}")
    private Integer batchRetryLimit;

    private final DisbursementsProcessor disbursementProcessor;
    private final SvioJobExecutionListener svioJobExecutionListener;
    private final KafkaTemplate<String, Object> disbursementsKafkaTemplate;
    private static final String[] DISBURSEMENT_FLAT_FILE_COLUMN_NAMES = {
            "pooledFundNumber", "fundID", "masterContractNumber",
            "subPlanNumber", "tradeDate", "processing_postingDate", "settlementDate", "marketAmount",
            "investmentContractType", "paymentMethod", "taxStateCode", "effectiveDate", "reversalFlag", "reversalReason",
            "wireState", "payeeName", "instructionLine1", "instructionLine2",
            "instructionLine3", "instructionLine4", "instructionLine5", "instructionLine6",
            "bankName", "bankCity", "recordKeeper"
    };

    @Bean
    public Job disbursementsChunkJob(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new JobBuilder(DISBURSEMENTS_CHUNK_JOB.getValue(), jobRepository)
                .start(createDisbursementsChunkStep(jobRepository, transactionManager))
                .listener(svioJobExecutionListener)
                .build();

    }

    @Bean
    protected Step createDisbursementsChunkStep(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder(DISBURSEMENTS_CHUNK_STEP, jobRepository)
                .<DisbursementsInput, InstitutionalDisbursementInitiated>chunk(batchChunkSize, transactionManager)
                .reader(flatFileItemReader(null))
                .processor(compositeItemProcessor())
                .writer(kafkaItemWriter())
                .faultTolerant()
                .retryLimit(batchRetryLimit)
                .noRetry(ValidationException.class)
                .retry(Throwable.class)
                .listener(disbursementProcessor)
                .build();


    }

    @Bean("disbursementFlatFileItemReader")
    @StepScope
    public FlatFileItemReader<DisbursementsInput> flatFileItemReader(@Value("#{jobParameters['inputFile']}") FileSystemResource fileSystemResource) {
        return new FlatFileItemReaderBuilder<DisbursementsInput>()
                .linesToSkip(1)
                .name(DISBURSEMENTS_FLAT_FILE_ITEM_READER)
                .delimited()
                .delimiter(TILDA_DELIMITER)
                .names(DISBURSEMENT_FLAT_FILE_COLUMN_NAMES)
                .targetType(DisbursementsInput.class)
                .resource(fileSystemResource)
                .build();

    }

    @Bean("disbursementInputValidatingItemProcessor")
    @StepScope
    public BeanValidatingItemProcessor<DisbursementsInput> inputValidatingItemProcessor() {
        return new BeanValidatingItemProcessor<>();
    }

    @Bean("disbursementCompositeItemProcessor")
    @StepScope
    public CompositeItemProcessor<DisbursementsInput, InstitutionalDisbursementInitiated> compositeItemProcessor() {
        CompositeItemProcessor<DisbursementsInput, InstitutionalDisbursementInitiated> compositeItemProcessor = new CompositeItemProcessor<>();
        compositeItemProcessor.setDelegates(List.of(inputValidatingItemProcessor(), disbursementProcessor));
        return compositeItemProcessor;
    }

    @Bean("disbursementKafkaItemWriter")
    @StepScope
    public KafkaItemWriter<String, Object> kafkaItemWriter() {
        return new KafkaItemWriterBuilder<String, Object>()
                .kafkaTemplate(disbursementsKafkaTemplate)
                .itemKeyMapper(disbursement -> String.valueOf(((InstitutionalDisbursementInitiated) disbursement).getEventHeader().getEventBatchGroupId()))
                .build();
    }

}

