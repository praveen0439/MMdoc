package com.mm.enterprise.genericadaptersvio.config.job;

import lombok.Getter;

@Getter
public enum BatchJobType {
    TRANSACTIONS_EXTRACTS_CHUNK_JOB("transactionsExtractsChunkJob"),
    TRANSACTIONS_CHUNK_JOB("transactionsChunkJob"),
    SHAREHOLDERS_EXTRACTS_CHUNK_JOB("shareholdersExtractsChunkJob"),
    DISBURSEMENTS_CHUNK_JOB("disbursementsChunkJob"),
    CONTROL_DISBURSEMENTS_CHUNK_JOB("controlDisbursementsChunkJob"),
    CONTROL_TRANSACTIONS_CHUNK_JOB("controlTransactionsChunkJob"),
    DONE_CHUNK_JOB("doneChunkJob");

    private final String value;

    BatchJobType(String value) {
        this.value = value;
    }

}
