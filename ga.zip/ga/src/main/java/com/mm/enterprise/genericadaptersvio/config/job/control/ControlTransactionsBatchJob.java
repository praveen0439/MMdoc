package com.mm.enterprise.genericadaptersvio.config.job.control;

import businesscustomers.event.agreements.institutionalcontrol.completed.SvioControlCompleted;
import com.mm.enterprise.genericadaptersvio.config.job.tasklet.EmptyFileTask;
import com.mm.enterprise.genericadaptersvio.listener.SvioJobExecutionListener;
import com.mm.enterprise.genericadaptersvio.model.control.ControlInput;
import com.mm.enterprise.genericadaptersvio.processor.ControlTransactionsProcessor;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.kafka.KafkaItemWriter;
import org.springframework.batch.item.kafka.builder.KafkaItemWriterBuilder;
import org.springframework.batch.item.support.CompositeItemProcessor;
import org.springframework.batch.item.validator.BeanValidatingItemProcessor;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.List;

import static com.mm.enterprise.genericadaptersvio.config.job.BatchJobType.CONTROL_TRANSACTIONS_CHUNK_JOB;
import static com.mm.enterprise.genericadaptersvio.util.Constants.*;

@Configuration
@RequiredArgsConstructor
public class ControlTransactionsBatchJob {

    @Value(value = "${generic.adapter.svio.retry.limit:3}")
    private Integer batchRetryLimit;

    private final ControlTransactionsProcessor controlTransactionsProcessor;

    private final EmptyFileTask emptyFileTask;

    private final SvioJobExecutionListener svioJobExecutionListener;

    private final KafkaTemplate<String, Object> controlKafkaTemplate;

    private static final String[] CONTROL_FLAT_FILE_COLUMN_NAME = {
            "fileName", "fileRunDate", "fileRunTime", "effectiveData",
            "recordCount", "facTotals"
    };

    @Bean
    public Job controlTransactionsChunkJob(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new JobBuilder(CONTROL_TRANSACTIONS_CHUNK_JOB.getValue(), jobRepository)
                .start(createTransactionsControlChunkStep(jobRepository, transactionManager))
                .next(controlTransactionsCheckEmptyFile(jobRepository, transactionManager))
                .listener(svioJobExecutionListener)
                .build();
    }

    @Bean
    protected Step controlTransactionsCheckEmptyFile(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder(EMPTY_TRANS_FILE_CHUNK_STEP, jobRepository)
                .tasklet(emptyFileTask, transactionManager)
                .build();

    }

    @Bean
    protected Step createTransactionsControlChunkStep(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        return new StepBuilder(CONTROL_TRANS_CHUNK_STEP, jobRepository)
                .<ControlInput, SvioControlCompleted>chunk(100, transactionManager)
                .reader(controlTransactionsFlatFileItemReader(null))
                .processor(compositeItemProcessor())
                .writer(kafkaItemWriter())
                .faultTolerant()
                .retryLimit(batchRetryLimit)
                .noRetry(ValidationException.class)
                .retry(Throwable.class)
                .listener(controlTransactionsProcessor)
                .build();
    }

    @Bean
    @StepScope
    public FlatFileItemReader<ControlInput> controlTransactionsFlatFileItemReader(@Value("#{jobParameters['inputFile']}") FileSystemResource fileSystemResource) {
        return new FlatFileItemReaderBuilder<ControlInput>()
                .name(CONTROL_TRANS_FLAT_FILE_ITEM_READER)
                .linesToSkip(1)
                .delimited()
                .delimiter(CONTROL_DELIMITED_LINE_TOKEN)
                .names(CONTROL_FLAT_FILE_COLUMN_NAME)
                .targetType(ControlInput.class)
                .resource(fileSystemResource)
                .build();
    }

    @Bean("controlTransKafkaItemWriter")
    @StepScope
    public KafkaItemWriter<String, Object> kafkaItemWriter() {
        return new KafkaItemWriterBuilder<String, Object>()
                .kafkaTemplate(controlKafkaTemplate)
                .itemKeyMapper(control -> String.valueOf(((SvioControlCompleted) control).getEventHeader().getEventCorrelationId()))
                .build();
    }

    @Bean("controlTransInputValidatingItemProcessor")
    @StepScope
    public BeanValidatingItemProcessor<ControlInput> inputValidatingItemProcessor() {
        return new BeanValidatingItemProcessor<>();
    }

    @Bean("controlTransCompositeItemProcessor")
    @StepScope
    public CompositeItemProcessor<ControlInput, SvioControlCompleted> compositeItemProcessor() {
        CompositeItemProcessor<ControlInput, SvioControlCompleted> compositeItemProcessor = new CompositeItemProcessor<>();
        compositeItemProcessor.setDelegates(List.of(inputValidatingItemProcessor(), controlTransactionsProcessor));
        return compositeItemProcessor;
    }
}
