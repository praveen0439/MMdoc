//package com.mm.enterprise.genericadaptersvio.transactionextract;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//import com.mm.enterprise.genericadaptersvio.helper.PostgresSqlContainerInitializer;
//import com.mm.enterprise.genericadaptersvio.mapper.TransactionExtractCompositeLineMapper;
//import com.mm.enterprise.genericadaptersvio.model.transactionextract.TransactionExtractInput;
//import com.mm.enterprise.genericadaptersvio.model.transactionextract.TransactionExtractInputRow;
//import com.mm.enterprise.genericadaptersvio.model.transactionextract.TransactionExtractInputTrailer;
//import org.junit.jupiter.api.AfterAll;
//import org.junit.jupiter.api.BeforeAll;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.ActiveProfiles;
//import org.springframework.test.context.DynamicPropertyRegistry;
//import org.springframework.test.context.DynamicPropertySource;
//import org.testcontainers.containers.PostgreSQLContainer;
//import org.testcontainers.junit.jupiter.Container;
//import org.testcontainers.junit.jupiter.Testcontainers;
//
//@SpringBootTest
//@ActiveProfiles("junit")
//@Testcontainers
//class TransactionExtractCompositeLineMapperIT {
//  static final String row =
//      "GEN155001 00000155001000000000002023091100001632000REDEEM AMOUNT                 0246     104.073244         -476183.28         -4575.4630             0.00             0.00043712.0000000.000000000000000000000000000000020230911000000002023091200000000   0InvOps  0000000000             0.00             0.0000      0.0000000000000000000000000000000000000         0.00         0.000000000000000000000000  0000000U100000         -457908.250               0               0000000000000000000000000000000000000000                              0000000   0000000     0.00 0.00000         0.000000000000               0.000.0000       0.000000000I00               0.0000 0000000.000000 00000000000.0000000000000000000000000000000000000000000000000000000090000000000000000000000000000000000000000000000000000X";
//  static final String trailer =
//      "PHOENIX-SVIO_ACTIVITY-20230912-2023091210013296.txt                                                  S000015392 20230912 20230912 0000000001033697.58 00000000267 424ccd30350715748f130778739b259c";
//  @Container
//  static final PostgreSQLContainer postgres = new PostgresSqlContainerInitializer();
//  @Autowired
//  TransactionExtractCompositeLineMapper compositeLineMapper;
//  @DynamicPropertySource
//  static void overrideConfiguration(DynamicPropertyRegistry registry) {
//    registry.add("spring.datasource.url", postgres::getJdbcUrl);
//  }
//
//  @BeforeAll
//  static void before() {
//    postgres.start();
//  }
//
//  @AfterAll
//  static void afterAll() {
//    postgres.stop();
//  }
//
//  @Test
//  void testInputRow() throws Exception {
//    TransactionExtractInput transactionExtractInput = compositeLineMapper.mapLine(row, 1);
//    assertTrue(transactionExtractInput instanceof TransactionExtractInputRow);
//    TransactionExtractInputRow transactionExtractInputRow = ((TransactionExtractInputRow) transactionExtractInput);
//    assertEquals(9, transactionExtractInputRow.getFundNumber().length());
//    assertEquals(9, transactionExtractInputRow.getShareHolderAccountNumber().length());
//    assertEquals(2, transactionExtractInputRow.getShareHolderSubAccountNumber().length());
//    assertEquals(8, transactionExtractInputRow.getDateOfTrade().length());
//    assertEquals(5, transactionExtractInputRow.getSequenceNumber().length());
//    assertEquals(3, transactionExtractInputRow.getTransactionType().length());
//    assertEquals(3, transactionExtractInputRow.getTransactionTypeSub().length());
//    assertEquals(1, transactionExtractInputRow.getReversalFlag().length());
//    assertTrue( transactionExtractInputRow.getDollarAmount().toString().length() <= 19);
//    assertEquals(8, transactionExtractInputRow.getProcessingDate().length());
//    assertEquals(8, transactionExtractInputRow.getClearDate().length());
//    assertEquals(2, transactionExtractInputRow.getPurchaseSource().length());
//    assertEquals(2, transactionExtractInputRow.getPaymentMethod().length());
//  }
//
//  @Test
//  void testInputTrailer() throws Exception {
//    TransactionExtractInput transactionExtractInput = compositeLineMapper.mapLine(trailer, 2);
//    assertTrue(transactionExtractInput instanceof TransactionExtractInputTrailer);
//    TransactionExtractInputTrailer transactionExtractInputTrailer = ((TransactionExtractInputTrailer) transactionExtractInput);
//    assertEquals(11, transactionExtractInputTrailer.getRecordCount().length());
//    assertTrue(transactionExtractInputTrailer.getTotalDollarAmount().toString().length() <= 19);
//  }
//}