//package com.mm.enterprise.genericadaptersvio;
//
//import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//import static org.testcontainers.containers.localstack.LocalStackContainer.Service.S3;
//import static org.testcontainers.shaded.org.awaitility.Awaitility.await;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.mm.enterprise.genericadaptersvio.helper.LocalStackContainerInitializer;
//import com.mm.enterprise.genericadaptersvio.helper.PostgresSqlContainerInitializer;
//import com.mm.enterprise.genericadaptersvio.helper.serviceinterceptor.ServiceInterceptedCalls;
//import com.mm.enterprise.genericadaptersvio.model.S3ObjectDetails;
//import com.mm.enterprise.testcontainers.support.kafka.KafkaContainerInitializer;
//import com.mm.enterprise.testcontainers.support.kafka.KafkaTestcontainersIntegrationTestConfig;
//import com.mm.enterprise.testcontainers.support.kafka.aop.KafkaConsumerInterceptedCalls;
//import java.io.File;
//import java.io.IOException;
//import java.util.concurrent.TimeUnit;
//import org.junit.jupiter.api.AfterAll;
//import org.junit.jupiter.api.BeforeAll;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.context.TestConfiguration;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Import;
//import org.springframework.context.annotation.Primary;
//import org.springframework.http.MediaType;
//import org.springframework.security.oauth2.jwt.JwtDecoder;
//import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors;
//import org.springframework.test.context.ActiveProfiles;
//import org.springframework.test.context.DynamicPropertyRegistry;
//import org.springframework.test.context.DynamicPropertySource;
//import org.springframework.test.web.servlet.MockMvc;
//import org.testcontainers.containers.KafkaContainer;
//import org.testcontainers.containers.PostgreSQLContainer;
//import org.testcontainers.containers.localstack.LocalStackContainer;
//import org.testcontainers.junit.jupiter.Container;
//import org.testcontainers.junit.jupiter.Testcontainers;
//import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
//import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
//import software.amazon.awssdk.regions.Region;
//import software.amazon.awssdk.services.s3.S3Client;
//import software.amazon.awssdk.services.s3.model.GetObjectRequest;
//import software.amazon.awssdk.services.s3.model.NoSuchKeyException;
//import software.amazon.awssdk.services.s3.model.PutObjectRequest;
//
//@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
//    properties = {
//        "spring.main.allow-bean-definition-overriding=true"})
//@ActiveProfiles("junit")
//@Import({
//    KafkaTestcontainersIntegrationTestConfig.class})
//@Testcontainers()
//@AutoConfigureMockMvc
//public class TransactionExtractEndToEndTest {
//
//  @Container
//  static final LocalStackContainer localstack = new LocalStackContainerInitializer()
//      .withServices(S3);
//  @Container
//  static final KafkaContainer kafkaContainer = new KafkaContainerInitializer();
//  @Container
//  static final PostgreSQLContainer postgres = new PostgresSqlContainerInitializer();
//  public static final String BUCKET_NAME = "test";
//  @Autowired
//  S3Client s3Client;
//  @Autowired
//  private KafkaConsumerInterceptedCalls consumerInterceptedCalls;
//  @Autowired
//  private ServiceInterceptedCalls serviceInterceptedCalls;
//  @Value(value = "${local.server.port}")
//  private int port;  // The port that Spring randomly assigned.
//  @Autowired
//  private MockMvc mockMvc;
//  @MockBean
//  private JwtDecoder jwtDecoder;
//
//  @DynamicPropertySource
//  static void overrideConfiguration(DynamicPropertyRegistry registry) {
//    registry.add("cloud.aws.s3.endpoint", () -> localstack.getEndpointOverride(LocalStackContainer.Service.S3));
//    registry.add("event-processing.order-event-bucket", () -> BUCKET_NAME);
//    registry.add("cloud.aws.credentials.access-key", localstack::getAccessKey);
//    registry.add("cloud.aws.credentials.secret-key", localstack::getSecretKey);
//    registry.add("spring.datasource.url", postgres::getJdbcUrl);
//  }
//
//  @BeforeAll
//  static void before() throws IOException, InterruptedException {
////    create bucket using awslocal cli wrapper
//    localstack.execInContainer("awslocal", "s3", "mb", "s3://" + BUCKET_NAME);
//    postgres.start();
//  }
//
//  @BeforeEach
//  void beforeEach() {
//    consumerInterceptedCalls.clear();
//    serviceInterceptedCalls.clear();
//  }
//
//  @AfterAll
//  static void afterAll() throws IOException, InterruptedException {
//    postgres.stop();
//    //    delete bucket
//    localstack.execInContainer("awslocal", "s3", "rb", "s3://" + BUCKET_NAME);
//    localstack.stop();
//  }
//
//  @TestConfiguration
//  @ActiveProfiles("junit")
//  static class TestS3Client {
//
//
//    @Primary
//    @Bean
//    public S3Client k8sS3Client() {
//      return S3Client.builder()
//          .region(Region.of(localstack.getRegion()))
//          .endpointOverride(localstack.getEndpointOverride(S3))
//          .credentialsProvider(StaticCredentialsProvider.create(
//              AwsBasicCredentials.create(
//                  localstack.getAccessKey(), localstack.getSecretKey())))
//          .build();
//    }
//  }
//
//  @Test
//  void happyFlow() throws Exception {
//    String mainBucketKey = "source/main/transactionsextracts/TransactionExtract_20230912100258_20230911.txt";
//    String succesBucketKey = "source/success/transactionsextracts/TransactionExtract_20230912100258_20230911.txt";
//
////    given
//    s3Client.putObject(PutObjectRequest.builder()
//        .bucket(BUCKET_NAME)
//        .key(mainBucketKey)
//        .build(), new File("src/test/resources/test-files/TransactionExtract_20230912100258_20230911.txt").toPath());
//    S3ObjectDetails s3ObjectDetails = new S3ObjectDetails(
//        BUCKET_NAME, mainBucketKey, "testETag", 2L, null);
////     when
//    mockMvc.perform(
//            post("http://localhost:" + port + "/start/transactionsExtractsChunkJob")
//                .contentType(MediaType.APPLICATION_JSON)
//                .with(SecurityMockMvcRequestPostProcessors.jwt())
//                .content(
//                    new ObjectMapper().writeValueAsString(s3ObjectDetails)))
////      then
//        .andExpect(status().is2xxSuccessful());
//
//    //    test file was moved
//    GetObjectRequest getObjectRequest = GetObjectRequest.builder()
//        .bucket(BUCKET_NAME)
//        .key(mainBucketKey)
//        .build();
//    assertThrows(NoSuchKeyException.class, () -> s3Client.getObjectAsBytes(getObjectRequest));
//    assertDoesNotThrow(() -> s3Client.getObjectAsBytes(GetObjectRequest.builder()
//        .bucket(BUCKET_NAME)
//        .key(succesBucketKey)
//        .build()));
//
//    //    test 1 message sent to control topic + 1 to done topic
//    await().atMost(10, TimeUnit.SECONDS)
//        .until(() -> serviceInterceptedCalls.methodWasCalled("KafkaMessageService", "sendMessage", 2));
//    //    test notification sent
//    await().atMost(10, TimeUnit.SECONDS)
//        .until(() -> serviceInterceptedCalls.methodWasCalled("KafkaTopicAlertService", "sendNotification", 1));
//  }
//
//  @Test
//  void givenMalformedInputFile_ThenJobFails() throws Exception {
//    String mainBucketKey = "source/main/transactionsextracts/TransactionExtract_20230912100258_20230911_dollarAmountNOK.txt";
//    String failureBucketKey = "source/failure/transactionsextracts/TransactionExtract_20230912100258_20230911_dollarAmountNOK.txt";
//
//    //    given
//    s3Client.putObject(PutObjectRequest.builder()
//        .bucket(BUCKET_NAME)
//        .key(mainBucketKey)
//        .build(), new File("src/test/resources/test-files/TransactionExtract_20230912100258_20230911_dollarAmountNOK.txt").toPath());
//    S3ObjectDetails s3ObjectDetails = new S3ObjectDetails(
//        BUCKET_NAME, mainBucketKey, "testETag", 2L, null);
//    //     when
//    mockMvc.perform(
//        post("http://localhost:" + port + "/start/transactionsExtractsChunkJob")
//            .contentType(MediaType.APPLICATION_JSON)
//            .with(SecurityMockMvcRequestPostProcessors.jwt())
//            .content(
//                new ObjectMapper().writeValueAsString(s3ObjectDetails)))
//        //      then
//        .andExpect(status().is2xxSuccessful());
//
//    //    test file was moved
//    GetObjectRequest getObjectRequest = GetObjectRequest.builder()
//        .bucket(BUCKET_NAME)
//        .key(mainBucketKey)
//        .build();
//    assertThrows(NoSuchKeyException.class, () -> s3Client.getObjectAsBytes(getObjectRequest));
//    assertDoesNotThrow(() -> s3Client.getObjectAsBytes(GetObjectRequest.builder()
//        .bucket(BUCKET_NAME)
//        .key(failureBucketKey)
//        .build()));
//    //    test error notification sent
//    await().atMost(10, TimeUnit.SECONDS)
//        .until(() -> serviceInterceptedCalls.methodWasCalled("KafkaTopicAlertService", "sendError", 1));
//  }
//}
