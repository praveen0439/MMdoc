package com.mm.enterprise.genericadaptersvio.helper.serviceinterceptor;

import java.time.Instant;
import lombok.Data;

@Data
public class ServiceCall {

  private final String serviceName;
  private final String methodName;
  private final Object[] arguments;
  private final Instant instant;

}
