package com.mm.enterprise.genericadaptersvio.helper.serviceinterceptor;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class ServiceAdvisor {

  private final ServiceInterceptedCalls serviceInterceptedCalls;

  @Pointcut("within(@org.springframework.stereotype.Service *)")
  public void serviceClassMethods() {

  }

  @Around("serviceClassMethods()")
  public Object interceptConsumerCall(ProceedingJoinPoint joinPoint) throws Throwable {
    Object returnVal = joinPoint.proceed();
    this.serviceInterceptedCalls.add(joinPoint);
    return returnVal;
  }

  public ServiceAdvisor(final ServiceInterceptedCalls serviceInterceptedCalls) {
    this.serviceInterceptedCalls = serviceInterceptedCalls;
  }

}
