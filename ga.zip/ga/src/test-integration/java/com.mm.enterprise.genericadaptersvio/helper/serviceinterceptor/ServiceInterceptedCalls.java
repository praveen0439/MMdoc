package com.mm.enterprise.genericadaptersvio.helper.serviceinterceptor;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.aspectj.lang.JoinPoint;
import org.springframework.stereotype.Component;

@Component
public class ServiceInterceptedCalls {

  private final List<ServiceCall> interceptedCalls = Collections.synchronizedList(new ArrayList());

  public ServiceInterceptedCalls() {
  }

  public void add(JoinPoint joinPoint) {
    this.interceptedCalls.add(
        new ServiceCall(joinPoint.getThis().getClass().getSimpleName(), joinPoint.getSignature().getName(), joinPoint.getArgs(), Instant.now()));
  }

  public int size() {
    return this.interceptedCalls.size();
  }

  public List<ServiceCall> getInterceptedCalls() {
    return this.interceptedCalls;
  }

  public void clear() {
    this.interceptedCalls.clear();
  }
  
  public boolean methodWasCalled(String serviceName, String methodName, long times, Object... arguments) {
    return this.getInterceptedCalls().stream().filter((call) -> {
      return call.getServiceName().startsWith(serviceName) && call.getMethodName().equals(methodName) && argumentsAreSame(call.getArguments(),
          arguments);
    }).count() == (long) times;
  }

  private boolean argumentsAreSame(Object[] existing, Object[] wanted) {
    List wantedArgs = Arrays.asList(wanted);

    if (wantedArgs.isEmpty()) {
      return true;
    }
    return Arrays.asList(existing).stream().filter(arg -> !wantedArgs.contains(arg)).count() == 0;
  }

}
