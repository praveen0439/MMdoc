package com.mm.enterprise.genericadaptersvio.helper;

import org.testcontainers.containers.localstack.LocalStackContainer;
import org.testcontainers.utility.DockerImageName;


public class LocalStackContainerInitializer extends LocalStackContainer {
  public LocalStackContainerInitializer() {
    super(getImageName());
  }

  private static DockerImageName getImageName() {
    String arch = System.getProperty("os.arch");
    return "aarch64".equals(arch) ? DockerImageName.parse("localstack/localstack") : DockerImageName.parse("artifactory.awsmgmt.massmutual.com/mm-streaming-docker/testcontainers/localstack:latest").asCompatibleSubstituteFor("localstack/localstack");
  }
}
