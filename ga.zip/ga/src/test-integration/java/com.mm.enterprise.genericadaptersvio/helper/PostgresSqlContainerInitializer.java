package com.mm.enterprise.genericadaptersvio.helper;

import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.utility.DockerImageName;

public class PostgresSqlContainerInitializer extends PostgreSQLContainer  {
  public PostgresSqlContainerInitializer() {
    super(getImageName());
  }

  private static DockerImageName getImageName() {
    String arch = System.getProperty("os.arch");
    return "aarch64".equals(arch) ? DockerImageName.parse("postgres:15-alpine") : DockerImageName.parse("mm-streaming-docker/testcontainers/postgres/postgres:15-alpine/").asCompatibleSubstituteFor("postgres:15-alpine");
  }
}
