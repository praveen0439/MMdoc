package com.mm.enterprise.svioreportingbatch.processor;

import static org.junit.jupiter.api.Assertions.*;

class TransactionDisbursementExtractProcessorTest {



}