package com.mm.enterprise.svioreportingbatch.listener;

import businesscustomers.event.agreements.institutionalcontrol.completed.EventHeader;
import businesscustomers.event.agreements.institutionalcontrol.completed.EventSourceFileType;
import businesscustomers.event.agreements.institutionalcontrol.completed.Metadata;
import businesscustomers.event.agreements.institutionalcontrol.completed.SvioControlCompleted;
import com.mm.enterprise.svioreportingbatch.config.jobs.BatchJobType;
import com.mm.enterprise.svioreportingbatch.config.service.JobService;
import com.mm.enterprise.svioreportingbatch.config.service.KafkaTopicAlertService;
import com.mm.enterprise.svioreportingbatch.config.service.MongoDBService;
import com.mm.enterprise.svioreportingbatch.model.controlfiles.ControlEventHeader;
import com.mm.enterprise.svioreportingbatch.model.controlfiles.ControlFile;
import com.mm.enterprise.svioreportingbatch.model.status.BiPairFile;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;

import java.util.*;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class TriggerBatchKafkaControlListenerTest {

    @Mock
    JobService jobService;

    @Mock
    MongoDBService mongoDBService;

    @Mock
    KafkaTopicAlertService kafkaTopicAlertService;

    @Captor
    ArgumentCaptor<JobParameters> jobParametersArgumentCaptor;

    @Captor
    ArgumentCaptor<ControlFile> controlFileArgumentCaptor;
    @InjectMocks
    TriggerBatchKafkaControlListener triggerBatchKafkaControlListener;

    @Test
    void givenSVIControlForTransactionExtract_thenStartJobWithCorrectParms(){
        SvioControlCompleted svioControl = SvioControlCompleted.newBuilder().setEventHeader(
                EventHeader.newBuilder().setMetadata(
                        Metadata.newBuilder()
                                .setEventSourceFileType(EventSourceFileType.TRANSACTIONSEXTRACT)
                                .setEventSourceFilename("TRANSACTIONSEXTRACT.ctrl")
                                .setEventSourceReferencedFilename("TRANSACTIONSEXTRACT.ctrl")
                                .setEventSourceRunDate("")
                                .setEventSourceRunTime("")
                                .setEventSourceValuationDate("")
                                .build()
                        ).setEventGeneratedDateTime("")
                        .setEventType("TRANSACTIONSEXTRACT")
                        .build()
        ).build();

        JobExecution jobExecution = new JobExecution(1L);
        jobExecution.setExitStatus(ExitStatus.COMPLETED);
        Mockito.when(jobService.startJob(Mockito.any(), Mockito.any())).thenReturn(jobExecution);

        ControlFile controlFile = ControlFile.builder()
                .id("1")
                .eventHeader(new ControlEventHeader())
                .build();
        final Map<String, JobParameter<?>> params = new HashMap<>();
        String eventSourceFilFile=svioControl.getEventHeader().getMetadata().getEventSourceFilename();
        String eventSourceFileType =svioControl.getEventHeader().getMetadata().getEventSourceFileType().name();
        params.put(INPUT_FIL_FILE, new JobParameter<>(eventSourceFilFile, String.class));
        params.put(INPUT_FILE_TYPE, new JobParameter<>(eventSourceFileType, String.class));
        params.put(INPUT_CONTROL_FILE, new JobParameter<>(eventSourceFilFile, String.class));
        Mockito.when(jobService.getJobParameters(eventSourceFilFile,eventSourceFileType,eventSourceFilFile)).thenReturn(new JobParameters(params));
        triggerBatchKafkaControlListener.consume(svioControl,null);

        Mockito.verify(jobService, Mockito.times(1)).startJob(Mockito.any(), jobParametersArgumentCaptor.capture());
        JobParameters jobParameters = jobParametersArgumentCaptor.getValue();
        assertEquals("TRANSACTIONSEXTRACT.ctrl",jobParameters.getString(INPUT_FIL_FILE));
        assertEquals(TRANSACTIONSEXTRACT,jobParameters.getString(INPUT_FILE_TYPE));
        assertEquals("TRANSACTIONSEXTRACT.ctrl",jobParameters.getString(INPUT_CONTROL_FILE));

    }

    @Test
    void givenSVIControlForTransactionDisb_thenStartJobWithCorrectParms(){
        SvioControlCompleted svioControl = SvioControlCompleted.newBuilder().setEventHeader(
                EventHeader.newBuilder().setMetadata(
                                Metadata.newBuilder()
                                        .setEventSourceFileType(EventSourceFileType.TRANSACTIONS)
                                        .setEventSourceFilename("CARSTR40240304195129.ctrl")
                                        .setEventSourceReferencedFilename("CARSTR40240304195129.FIL")
                                        .setEventSourceRunDate("")
                                        .setEventSourceRunTime("")
                                        .setEventSourceValuationDate("")
                                        .build()
                        ).setEventGeneratedDateTime("")
                        .setEventType("TRANSACTIONS")
                        .build()
        ).build();

        JobExecution jobExecution = new JobExecution(1L);
        jobExecution.setExitStatus(ExitStatus.COMPLETED);
        Mockito.when(jobService.startJob(Mockito.any(), Mockito.any())).thenReturn(jobExecution);

        ControlFile controlFile = ControlFile.builder()
                .id("1")
                .eventHeader(new ControlEventHeader())
                .build();
        Mockito.when(mongoDBService.doesCollectionExist(BI_PAIR_FILE_COLLECTION)).thenReturn(true);
        BiPairFile biPairFile = BiPairFile.builder()
                .fileName("CARSDIST40240304195129.FIL")
                .build();
        List<BiPairFile> biPairFileList = new ArrayList<>();
        biPairFileList.add(biPairFile);
        Mockito.when(mongoDBService.findBiPairFileByFileName(Mockito.any())).thenReturn(biPairFileList);

        String eventSourceControlFile=svioControl.getEventHeader().getMetadata().getEventSourceFilename();
        String eventSourceFileType =svioControl.getEventHeader().getMetadata().getEventSourceFileType().name();
        String eventSourceFilFile =svioControl.getEventHeader().getMetadata().getEventSourceReferencedFilename();
        String transactionFilFileName = eventSourceFilFile.replace("CARSDIST", "CARSTR");
        String disbursementFilFileName = eventSourceFilFile.replace("CARSTR", "CARSDIST");
        final Map<String, JobParameter<?>> params = new HashMap<>();
        params.put(INPUT_FIL_FILE, new JobParameter<>(eventSourceFilFile, String.class));
        params.put(INPUT_FILE_TYPE, new JobParameter<>(eventSourceFileType, String.class));
        params.put(INPUT_CONTROL_FILE, new JobParameter<>(eventSourceControlFile, String.class));
        params.put(INPUT_TRANSACTION_FILE, new JobParameter<>(transactionFilFileName, String.class));
        params.put(INPUT_DISBURSEMENT_FILE, new JobParameter<>(disbursementFilFileName, String.class));

        Mockito.when(jobService.getJobParameters(eventSourceFilFile,eventSourceFileType,eventSourceControlFile)).thenReturn(new JobParameters(params));
        triggerBatchKafkaControlListener.consume(svioControl,null);

        Mockito.verify(jobService, Mockito.times(1)).startJob(Mockito.any(), jobParametersArgumentCaptor.capture());
        JobParameters jobParameters = jobParametersArgumentCaptor.getValue();
        assertEquals("CARSTR40240304195129.FIL",jobParameters.getString(INPUT_FIL_FILE));
        assertEquals("TRANSACTIONS",jobParameters.getString(INPUT_FILE_TYPE));
        assertEquals("CARSTR40240304195129.ctrl",jobParameters.getString(INPUT_CONTROL_FILE));
        assertEquals("CARSTR40240304195129.FIL",jobParameters.getString(INPUT_TRANSACTION_FILE));
        assertEquals("CARSDIST40240304195129.FIL",jobParameters.getString(INPUT_DISBURSEMENT_FILE));

    }


    @Test
    void testgetPairFileName(){
        assertEquals("CARSDIST40240304195129.FIL",triggerBatchKafkaControlListener.getPairFileName("CARSTR40240304195129.FIL","TRANSACTIONS"));
        assertEquals("CARSTR40240304195129.FIL",triggerBatchKafkaControlListener.getPairFileName("CARSDIST40240304195129.FIL","DISBURSEMENTS"));
    }

    @Test
    void testwaitForPairFile(){
        SvioControlCompleted svioControl = SvioControlCompleted.newBuilder().setEventHeader(
                EventHeader.newBuilder().setMetadata(
                                Metadata.newBuilder()
                                        .setEventSourceFileType(EventSourceFileType.TRANSACTIONS)
                                        .setEventSourceFilename("CARSTR40240304195129.ctrl")
                                        .setEventSourceReferencedFilename("CARSTR40240304195129.FIL")
                                        .setEventSourceRunDate("")
                                        .setEventSourceRunTime("")
                                        .setEventSourceValuationDate("")
                                        .build()
                        )
                        .setEventGeneratedDateTime("")
                        .setEventType("TRANSACTIONS")
                        .build()
        ).build();
        Mockito.when(mongoDBService.findBiPairFileByFileName(Mockito.anyString())).thenReturn(Collections.emptyList());
        assertTrue(triggerBatchKafkaControlListener.waitForPairFile(svioControl,"TRANSACTIONS"));
    }


}