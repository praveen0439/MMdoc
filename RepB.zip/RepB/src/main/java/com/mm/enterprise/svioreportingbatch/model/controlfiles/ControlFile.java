package com.mm.enterprise.svioreportingbatch.model.controlfiles;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.annotation.Id;

@Data
@Builder
@Document("controlfiles")
public class ControlFile {
    @Id
    private String id;
    private ControlEventHeader eventHeader;
    public String getEventGeneratedDateTime(){
        return eventHeader.getEventGeneratedDateTime();
    }
}
