package com.mm.enterprise.svioreportingbatch.mapping;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@AllArgsConstructor
public class CashbookMappingIssues implements Serializable {
    private String transactionType;
    private String purchaseSource;
    private String paymentMethod;
    @Override
    public boolean equals(Object o){
        if(this ==o) return true;
        if(o==null || getClass()!=o.getClass()) return false;
        CashbookMappingIssues cashbookMappingIssues= (CashbookMappingIssues) o;
        return Objects.equals(transactionType,cashbookMappingIssues.transactionType) && Objects.equals(purchaseSource,cashbookMappingIssues.purchaseSource)
                && Objects.equals(paymentMethod,cashbookMappingIssues.paymentMethod);
    }
    @Override
    public int hashCode(){
        return Objects.hash(transactionType,purchaseSource,paymentMethod);
    }

    @Override
    public String toString() {
        return
                "transactionType='" + transactionType + '\'' +
                ", purchaseSource='" + purchaseSource + '\'' +
                ", paymentMethod='" + paymentMethod + '\'';
    }
}
