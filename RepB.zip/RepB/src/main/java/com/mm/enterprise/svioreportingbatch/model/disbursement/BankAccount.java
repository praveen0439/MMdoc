package com.mm.enterprise.svioreportingbatch.model.disbursement;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
public class BankAccount {
    @Field("id")
    private String id;
    private String accountNumber;
    private String bankName;
}
