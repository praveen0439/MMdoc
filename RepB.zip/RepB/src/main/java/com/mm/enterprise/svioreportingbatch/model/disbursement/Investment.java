package com.mm.enterprise.svioreportingbatch.model.disbursement;

import lombok.Data;

@Data
public class Investment {
    private Fund fund;
    private String typeCode;
}
