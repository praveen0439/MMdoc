package com.mm.enterprise.svioreportingbatch.mapping;

import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.Id;

@SuperBuilder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString(callSuper = true)
public class CashbookMappings {
    @Id
    private String id;
    private String transactionType;
    private String paymentMethod;
    private String cashbookTypeDesc;
    private String cashbookClassDesc;
    private String cashbookActivityDesc;
}
