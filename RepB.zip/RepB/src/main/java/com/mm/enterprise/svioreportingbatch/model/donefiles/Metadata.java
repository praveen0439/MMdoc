package com.mm.enterprise.svioreportingbatch.model.donefiles;

import lombok.Data;

import java.time.LocalDate;
import java.util.ArrayList;
@Data
public class Metadata {
    private String eventSourceFilename;
    private ArrayList<String> eventSourceTransactionsControlFiles;
    private ArrayList<String> eventSourceTransactionsFilFiles;
    private ArrayList<String> eventSourceDisbursementsControlFiles;
    private ArrayList<String> eventSourceDisbursementsFilFiles;
    private ArrayList<String> eventSourceShareholdersExtractFiles;
    private ArrayList<String> eventSourceTransactionsExtractFiles;
    private String fileGeneratedDate;
    private String valuationDate;
    private LocalDate processedDate;

}
