package com.mm.enterprise.svioreportingbatch.model.disbursement;

import lombok.Data;

@Data
public class Trade {
    private String tradeDate;
    private String settlementDate;
}
