package com.mm.enterprise.svioreportingbatch.tasklets;

import com.mm.enterprise.svioreportingbatch.config.exception.SvioReportingBatchException;
import com.mm.enterprise.svioreportingbatch.config.service.MongoDBService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.*;

@Component
@Slf4j
@RequiredArgsConstructor
public class CollectionsValidator implements Tasklet, StepExecutionListener {

    private final MongoDBService mongoDBService;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
        if(!mongoDBService.doesCollectionExist(CASHBOOKMAPPING_COLLECTION)){
            throw new SvioReportingBatchException.BusinessValidationException(String.format(NO_COLLECTION_FOUND, CASHBOOKMAPPING_COLLECTION));
        }

        return null;
    }

    @Override
    public void beforeStep(StepExecution stepExecution) {
        StepExecutionListener.super.beforeStep(stepExecution);
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        return StepExecutionListener.super.afterStep(stepExecution);
    }
}
