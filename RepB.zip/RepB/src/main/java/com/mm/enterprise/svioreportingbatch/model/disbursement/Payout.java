package com.mm.enterprise.svioreportingbatch.model.disbursement;

import lombok.Data;

@Data
public class Payout {
    private String postingDate;
    private String methodCode;
    private String amountItem;
    private String effectiveDate;
}
