package com.mm.enterprise.svioreportingbatch.config.jobs;

import com.mm.enterprise.svioreportingbatch.config.service.JobService;
import com.mm.enterprise.svioreportingbatch.config.service.MongoDBService;
import com.mm.enterprise.svioreportingbatch.model.donefiles.DoneFile;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class GaSapBatchJobScheduler
{
    private final JobService jobService;
    private final MongoDBService mongoDBService;

    @Scheduled(cron="${gaSapEventsBatch.schedule.cron}")
    public void runBatchJob(){
        var list = mongoDBService.getMongoAggregatedCollection("CARSTR20240318204031.FIL","CARSDIST20240318204031.FIL");
       /*List<DoneFile> donefiles=mongoDBService.findDoneByStatusSiaAndStatusBi(PROCESSED,Boolean.FALSE) ;
        if(!(donefiles.isEmpty())){
            jobService.startJob(BatchJobType.GASAP_EVENTS.getValue(),new JobParametersBuilder().addLong("time",System.currentTimeMillis()).toJobParameters());
        }*/
    }
}
