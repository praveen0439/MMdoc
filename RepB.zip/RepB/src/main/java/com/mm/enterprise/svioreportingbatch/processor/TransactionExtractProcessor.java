package com.mm.enterprise.svioreportingbatch.processor;

import com.mm.enterprise.svioreportingbatch.mapper.TransactionExtractMapper;
import com.mm.enterprise.svioreportingbatch.model.cashbookdata.CashbookData;
import com.mm.enterprise.svioreportingbatch.model.transactionextract.TransactionsExtracts;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;

import static com.mm.enterprise.svioreportingbatch.config.util.ItemProcessorHelper.getBatchUpdateDt;
import static com.mm.enterprise.svioreportingbatch.config.util.ItemProcessorHelper.updateWriteCount;

@Component
@Slf4j(topic = "logger")
@RequiredArgsConstructor
public class TransactionExtractProcessor implements ItemProcessor<TransactionsExtracts, CashbookData>, StepExecutionListener {

    private final TransactionExtractMapper transactionExtractMapper;
    private StepExecution stepExecution;
    @Override
    public CashbookData process(TransactionsExtracts transactionsExtracts) throws Exception {
        final Timestamp updateDt=getBatchUpdateDt(stepExecution);
        return  transactionExtractMapper.mapFromMongoCollection(transactionsExtracts,updateDt);
    }

    @Override
    public void beforeStep(StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        updateWriteCount(stepExecution);
        return StepExecutionListener.super.afterStep(stepExecution);
    }
}
