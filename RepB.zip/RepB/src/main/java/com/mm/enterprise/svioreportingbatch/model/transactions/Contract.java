package com.mm.enterprise.svioreportingbatch.model.transactions;

import lombok.Data;

@Data
public class Contract {
    private String primaryId;
    private String suffix;
    private String effectiveDate;
    private Investment investment;
    private Distributor distributor;

}
