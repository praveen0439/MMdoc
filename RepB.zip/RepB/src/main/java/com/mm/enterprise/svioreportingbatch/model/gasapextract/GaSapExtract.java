package com.mm.enterprise.svioreportingbatch.model.gasapextract;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document("gasap_lines")
public class GaSapExtract {
    @Id
    private String id;
    private String postingDate;
    private String glReferenceNumber;
    private String shortTestHeader;
    private String companyCodeNumber;
    private String glAccountNumber;
    private String debitCreditInd;
    private String cashAmount;
    private String businessArea;
    private String costCenterNumber;
    private String profitCenterNumber;
    private String paymentStatusNumber;
    private String insuranceStatusNumber;
    private String qualifiedStatusNumber;
    private String stateCode;
    private String cityCode;
    private String idNumber;
    private String lineText;
    private String assignment;
    private String investmentVehicle;
    private String rowTerminator;
}
