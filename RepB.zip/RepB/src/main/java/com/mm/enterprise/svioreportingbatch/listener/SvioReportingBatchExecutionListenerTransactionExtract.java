package com.mm.enterprise.svioreportingbatch.listener;

import com.mm.enterprise.svioreportingbatch.abstracts.SvioReportingBatchExecutionListener;
import com.mm.enterprise.svioreportingbatch.config.exception.KafkaMessageServiceException;
import com.mm.enterprise.svioreportingbatch.config.exception.SvioReportingBatchException;
import com.mm.enterprise.svioreportingbatch.config.service.KafkaTopicAlertService;
import com.mm.enterprise.svioreportingbatch.config.service.PostgresDBService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.KafkaException;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import static com.mm.enterprise.svioreportingbatch.config.exception.KafkaMessageServiceException.KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE;
import static com.mm.enterprise.svioreportingbatch.config.exception.KafkaMessageServiceException.WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE;
import static com.mm.enterprise.svioreportingbatch.config.util.Constants.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class SvioReportingBatchExecutionListenerTransactionExtract implements SvioReportingBatchExecutionListener {

    private final KafkaTopicAlertService kafkaTopicAlertService;

    private final PostgresDBService postgresDBService;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.info("Starting SvioReportingBatchJobExecutionListener");
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        log.info("{} finished with status {}", jobExecution.getJobInstance().getJobName(), jobExecution.getExitStatus());
        List<StepExecution> stepExecutions = new ArrayList<>(jobExecution.getStepExecutions());
        JobParameters jobParameters = jobExecution.getJobParameters();

        if (ExitStatus.COMPLETED.equals(jobExecution.getExitStatus())) {
            ExecutionContext executionContext = jobExecution.getExecutionContext();
            final long writeCount = executionContext.getLong(WRITE_COUNT);
                String filFiles = (String) jobParameters.getParameters().get(INPUT_FIL_FILE).getValue();
                String notificationMessage = String.format("Svio reporting batch job executed successfully for Transaction Extract event for file %s. No. of rows inserted %s", filFiles,writeCount);
            try {
                kafkaTopicAlertService.sendNotification(notificationMessage);
            } catch (InterruptedException | ExecutionException | TimeoutException e) {
                Thread.currentThread().interrupt();
                throw new KafkaMessageServiceException(WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE, e);
            } catch (KafkaException e) {
                throw new KafkaMessageServiceException(KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE, e);
            }
        } else {
            Timestamp updateDt=(Timestamp) jobExecution.getExecutionContext().get(UPDATE_DATE);
            StepExecution failedStepExecution = stepExecutions.get(stepExecutions.size() - 1);
            List<Throwable> failureExceptions = failedStepExecution.getFailureExceptions();

            String localisedErrorMessage;
            if (failureExceptions.get(failureExceptions.size() - 1).getCause() != null) {
                localisedErrorMessage = failureExceptions.get(failureExceptions.size() - 1).getCause().toString();
            } else {
                localisedErrorMessage = failureExceptions.get(failureExceptions.size() - 1).getLocalizedMessage();
            }

            String errorMessage =
                    jobExecution.getJobInstance().getJobName() + " job FAILED in step: " + failedStepExecution.getStepName() + " with error: "
                            + localisedErrorMessage;
            var exception =failureExceptions.get(failureExceptions.size() - 1);
            if(!(exception instanceof SvioReportingBatchException.BusinessValidationRetryableException))
                kafkaTopicAlertService.sendError(errorMessage);
            postgresDBService.deleteLoadedCashbookDataOnFailure(updateDt,SVI_BI_TR_EXT);
        }
    }
}
