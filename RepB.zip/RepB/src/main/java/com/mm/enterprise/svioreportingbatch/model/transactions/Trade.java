package com.mm.enterprise.svioreportingbatch.model.transactions;

import lombok.Data;

@Data
public class Trade {
    private String settlementDate;
    private String tradeDate;
}
