package com.mm.enterprise.svioreportingbatch.mapper;

import com.mm.enterprise.svioreportingbatch.model.cashbookdata.CashbookData;
import com.mm.enterprise.svioreportingbatch.model.transactionextract.TransactionsExtracts;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.SVI_BI_TR_EXT;

@Component
@Slf4j(topic = "logger")
public class TransactionExtractMapper {

    public CashbookData mapFromMongoCollection(TransactionsExtracts transactionsExtracts,Timestamp updateDt){

        String adminNumber=transactionsExtracts.getContract().getInvestment().getFund().getAdminNumber();
        String distbrNumber=transactionsExtracts.getContract().getDistributor().getNumber();
        String productTypeCd = "";
        if (adminNumber.startsWith("S"))
            productTypeCd = "SIA";
        else if (adminNumber.startsWith("G"))
            productTypeCd = "GIA";

        String fundIdCd="";
        if(productTypeCd.equals("SIA"))
            fundIdCd=adminNumber.substring(0,4);
        else fundIdCd="GAG";

        String mediumCde="";
        if(distbrNumber.equals("00"))
            mediumCde=transactionsExtracts.getPayoutTransaction().getPayout().getMethodCode();
        else mediumCde=distbrNumber;


            return CashbookData.builder()
                .accountNum(transactionsExtracts.getContract().getPrimaryId())
                .subAccountNum(transactionsExtracts.getContract().getSuffix())
                .productTypeCde(productTypeCd)
                .fundIdCde(fundIdCd)
                .txnTypeCde("H")
                .phxTxnTypeCde(transactionsExtracts.getTransaction().getTypeCode())
                .mediumCde(mediumCde)
                .cashAmt(new BigDecimal(transactionsExtracts.getContract().getInvestment().getValue()))
                .valuationDt(stringToDt(transactionsExtracts.getTrade().getTradeDate()))
                .cashbookDt(stringToDt(transactionsExtracts.getTrade().getSettlementDate()))
                .postDt(stringToDt(transactionsExtracts.getPayoutTransaction().getPayout().getPostingDate()))
                .updateDt(updateDt)
                .loginUserId(SVI_BI_TR_EXT)
                .build();

    }

    public static Timestamp stringToDt(String dateString)  {
        if(dateString.equals("00000000"))
            dateString="99991231";
        LocalDateTime localDateTime= LocalDate.parse(dateString, DateTimeFormatter.BASIC_ISO_DATE).atTime(00,00,00);
        return Timestamp.valueOf(localDateTime);

    }
}
