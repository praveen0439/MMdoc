package com.mm.enterprise.svioreportingbatch.processor;

import com.mm.enterprise.svioreportingbatch.mapper.GaSapExtractMapper;
import com.mm.enterprise.svioreportingbatch.model.cashbookdata.CashbookData;
import com.mm.enterprise.svioreportingbatch.model.gasapextract.GaSapExtract;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;

import static com.mm.enterprise.svioreportingbatch.config.util.ItemProcessorHelper.getBatchUpdateDt;
import static com.mm.enterprise.svioreportingbatch.config.util.ItemProcessorHelper.updateWriteCount;

@Component
@Slf4j(topic = "logger")
@RequiredArgsConstructor
public class GaSapExtractProcessor implements ItemProcessor<GaSapExtract, CashbookData>, StepExecutionListener {

    private final GaSapExtractMapper gaSapExtractMapper;
    private StepExecution stepExecution;

    @Override
    public void beforeStep(StepExecution stepExecution)
    {
        this.stepExecution = stepExecution;
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        updateWriteCount(stepExecution);
        return StepExecutionListener.super.afterStep(stepExecution);
    }

    @Override
    public CashbookData process(GaSapExtract gaSapExtract) throws Exception {
        final Timestamp updateDt=getBatchUpdateDt(stepExecution);
       return gaSapExtractMapper.mapFromMongoCollection(gaSapExtract,updateDt);
    }
}
