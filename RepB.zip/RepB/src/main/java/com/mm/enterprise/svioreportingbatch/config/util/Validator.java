package com.mm.enterprise.svioreportingbatch.config.util;

import com.mm.enterprise.svioreportingbatch.config.exception.SvioReportingBatchException;
import com.mm.enterprise.svioreportingbatch.model.controlfiles.ControlFile;
import com.mm.enterprise.svioreportingbatch.model.disbursement.Disbursements;
import com.mm.enterprise.svioreportingbatch.model.transactionextract.TransactionsExtracts;
import com.mm.enterprise.svioreportingbatch.model.transactions.Transactions;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.*;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Validator {


    public static void validateRecordCountAndTotalAmountTransactionExtract(List<TransactionsExtracts> transactionsExtracts, ControlFile controlFile) {
        String controlFileName = controlFile.getEventHeader().getMetadata().getEventSourceFilename();
        BigDecimal controlTotalRecords = controlFile.getEventHeader().getEventBatchRecordCountTotal();
        BigDecimal controlTotalSum = controlFile.getEventHeader().getEventBatchTotalAmt();

        BigDecimal transactionsextractsSum = computeTransactionsextractSum(transactionsExtracts);

        if (controlTotalRecords.compareTo(BigDecimal.valueOf(transactionsExtracts.size())) != 0) {
            throw new SvioReportingBatchException.BusinessValidationRetryableException(String.format(RECORD_COUNT,controlFileName, controlFileName, transactionsExtracts.size(), controlTotalRecords));
        }

        if (controlTotalSum.compareTo(transactionsextractsSum) != 0) {
            throw new SvioReportingBatchException.BusinessValidationRetryableException(String.format(TOTAL_AMT,controlFileName, controlFileName, transactionsextractsSum, controlTotalSum));
        }
    }

    private static BigDecimal computeTransactionsextractSum(List<TransactionsExtracts> transactionextracts) {
        return transactionextracts.stream()
                .map(trans -> new BigDecimal(trans.getContract().getInvestment().getValue()))
                .reduce(BigDecimal::add)
                .orElse(BigDecimal.ZERO);
    }

    public static void validateControlCollection(List<ControlFile> controlFileList, String filFileName){
        if(controlFileList==null||controlFileList.isEmpty()){
            throw new SvioReportingBatchException.BusinessValidationRetryableException(String.format(NO_DATA_CONTROL,filFileName));
        }
    }

    public static void validateRecordCountAndTotalAmountDisbursements(List<Disbursements> disbursements, ControlFile controlFile) {
        String controlFileName = controlFile.getEventHeader().getMetadata().getEventSourceFilename();
        String filFileName= controlFile.getEventHeader().getMetadata().getEventSourceReferencedFilename();
        BigDecimal controlTotalRecords = controlFile.getEventHeader().getEventBatchRecordCountTotal();
        BigDecimal controlTotalSum = controlFile.getEventHeader().getEventBatchTotalAmt();

        BigDecimal disbursementsSum = computeDisbursementsSum(disbursements);

        if (controlTotalRecords.compareTo(BigDecimal.valueOf(disbursements.size())) != 0) {
            throw new SvioReportingBatchException.BusinessValidationRetryableException(String.format(RECORD_COUNT,filFileName, controlFileName, disbursements.size(), controlTotalRecords));
        }

        if (controlTotalSum.compareTo(disbursementsSum) != 0) {
            throw new SvioReportingBatchException.BusinessValidationRetryableException(String.format(TOTAL_AMT, filFileName, controlFileName, disbursementsSum, controlTotalSum));
        }
    }

    private static BigDecimal computeDisbursementsSum(List<Disbursements> disbursements) {
        return disbursements.stream()
                .map(disb -> new BigDecimal(disb.getPayoutTransaction().getPayout().getAmountItem()))
                .reduce(BigDecimal::add)
                .orElse(BigDecimal.ZERO);
    }


    public static void validateRecordCountAndTotalAmountTransactions(List<Transactions> transactions, ControlFile controlFile) {
        String controlFileName = controlFile.getEventHeader().getMetadata().getEventSourceFilename();
        String filFileName= controlFile.getEventHeader().getMetadata().getEventSourceReferencedFilename();
        BigDecimal controlTotalRecords = controlFile.getEventHeader().getEventBatchRecordCountTotal();
        BigDecimal controlTotalSum = controlFile.getEventHeader().getEventBatchTotalAmt();

        BigDecimal transactionsSum = computeTransactionsSum(transactions);

        if (controlTotalRecords.compareTo(BigDecimal.valueOf(transactions.size())) != 0) {
            throw new SvioReportingBatchException.BusinessValidationRetryableException(String.format(RECORD_COUNT,filFileName, controlFileName, transactions.size(), controlTotalRecords));
        }

        if (controlTotalSum.compareTo(transactionsSum) != 0) {
            throw new SvioReportingBatchException.BusinessValidationRetryableException(String.format(TOTAL_AMT,filFileName,controlFileName, transactionsSum, controlTotalSum));
        }
    }

    private static BigDecimal computeTransactionsSum(List<Transactions> transactions) {
        return transactions.stream()
                .map(trans -> new BigDecimal(trans.getContract().getInvestment().getValue()))
                .reduce(BigDecimal::add)
                .orElse(BigDecimal.ZERO);
    }


}
