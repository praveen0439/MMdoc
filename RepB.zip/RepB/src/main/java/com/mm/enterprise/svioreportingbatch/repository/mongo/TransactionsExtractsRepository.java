package com.mm.enterprise.svioreportingbatch.repository.mongo;

import com.mm.enterprise.svioreportingbatch.model.transactionextract.TransactionsExtracts;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TransactionsExtractsRepository extends MongoRepository<TransactionsExtracts,String> {

    @Query("{'eventHeader.metadata.eventSourceFilename' : ?0}")
    List<TransactionsExtracts> findByFileName(String fileName);
}
