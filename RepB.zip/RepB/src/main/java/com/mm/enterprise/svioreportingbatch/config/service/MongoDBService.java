package com.mm.enterprise.svioreportingbatch.config.service;

import com.mm.enterprise.svioreportingbatch.model.controlfiles.ControlFile;
import com.mm.enterprise.svioreportingbatch.model.disbursement.Disbursements;
import com.mm.enterprise.svioreportingbatch.model.donefiles.DoneFile;
import com.mm.enterprise.svioreportingbatch.model.gasapextract.GaSapExtract;
import com.mm.enterprise.svioreportingbatch.model.status.BiPairFile;
import com.mm.enterprise.svioreportingbatch.model.transactionextract.TransactionsExtracts;
import com.mm.enterprise.svioreportingbatch.model.transactions.Transactions;
import com.mm.enterprise.svioreportingbatch.model.transactions.TransactionsAggregated;
import com.mm.enterprise.svioreportingbatch.repository.mongo.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOptions;
import org.springframework.data.mongodb.core.aggregation.ConditionalOperators;
import org.springframework.data.mongodb.core.aggregation.EvaluationOperators;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.EVENT_SOURCE_FILENAME;
import static com.mm.enterprise.svioreportingbatch.config.util.Constants.TRANSACTIONS_COLLECTION;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;
import static org.springframework.data.mongodb.core.aggregation.BooleanOperators.And.and;
import static org.springframework.data.mongodb.core.aggregation.BooleanOperators.Or.or;
import static org.springframework.data.mongodb.core.aggregation.ComparisonOperators.valueOf;
import static org.springframework.data.mongodb.core.aggregation.LookupOperation.newLookup;
import static org.springframework.data.mongodb.core.aggregation.VariableOperators.Let.ExpressionVariable.newVariable;
import static org.springframework.data.mongodb.core.query.Criteria.where;

@Service
@Slf4j
@RequiredArgsConstructor
public class MongoDBService {
    private final DoneFilesRepository doneFilesRepository;
    private final GaSapExtractsRepository gaSapExtractsRepository;
    private final TransactionsExtractsRepository transactionsExtractsRepository;
    private final ControlFilesRepository controlFilesRepository;
    private final TransactionsRepository transactionsRepository;

    private final DisbursementsRepository disbursementsRepository;

    private final BiPairFileRepository biPairFileRepository;
    private final MongoOperations mongoOperations;
    private final MongoTemplate mongoTemplate;

    public List<DoneFile> findDoneByStatusSiaAndStatusBi(String statusSIA, Boolean statusBIExists) {
        return doneFilesRepository.findByStatusSiaAndStatusBi(statusSIA, statusBIExists);
    }

    public List<DoneFile> findDoneByStatusBiAndFileName(String statusBI, String fileName) {
        return doneFilesRepository.findDoneByStatusBiAndFileName(statusBI, fileName);
    }

    public void deleteAllGaSapLines() {
        gaSapExtractsRepository.deleteAll();
    }

    public void saveDoneFile(DoneFile doneFile) {
        doneFilesRepository.save(doneFile);
    }

    public List<ControlFile> findControlByEventSourceFilename(String eventSourceFilFile) {
        return controlFilesRepository.findByEventSourceFilename(eventSourceFilFile);
    }

    public List<ControlFile> findControlByEventSourceRefFilename(String eventSourceFilFile){
    return controlFilesRepository.findByEventSourceRefFilename(eventSourceFilFile);
    }
    public List<TransactionsExtracts> findTransactionExtractByFileName(String eventSourceFilFile) {
    return transactionsExtractsRepository.findByFileName(eventSourceFilFile);
    }

    public List<Disbursements> findDisbursementsByFileName(String eventSourceFilFile) {
        return  disbursementsRepository.findByFileName(eventSourceFilFile);
    }


    public List<TransactionsAggregated> getMongoAggregatedCollection(String transactionFilFileName,String disbursementFilFileName){

        Aggregation aggregation = Aggregation.newAggregation(
                match(where(EVENT_SOURCE_FILENAME).is(transactionFilFileName)),
                newLookup()
                        .from("disbursements")
                        .let(newVariable("adminNumber").forField("contract.investment.fund.adminNumber"),
                                newVariable("primaryId").forField("contract.primaryId"),
                                newVariable("suffix").forField("contract.suffix"),
                                newVariable("methodCode").forField("payoutTransaction.payout.methodCode"),
                                newVariable("valuationDate").forField("trade.tradeDate")
                        )
                        .pipeline(
                                match(
                                        EvaluationOperators.Expr.valueOf(and(
                                                valueOf("eventHeader.metadata.eventSourceFilename").equalToValue(disbursementFilFileName),
                                                valueOf("contract.investment.fund.adminNumber").equalToValue("$$adminNumber"),
                                                valueOf("contract.primaryId").equalToValue("$$primaryId"),
                                                valueOf("contract.suffix").equalToValue("$$suffix"),
                                                valueOf("payoutTransaction.payout.methodCode").equalToValue("$$methodCode"),
                                                valueOf("trade.tradeDate").equalToValue("$$valuationDate")
                                        ))

                                )
                        )
                        .as("disbursements")
                ,
                newLookup()
                        .from("cashbookMapping")
                        .let(newVariable("methodCode").forField("payoutTransaction.payout.methodCode"),
                                newVariable("typeCode").forField("transaction.typeCode"),
                                newVariable("distributorNumber").forField("contract.distributor.number")
                        )
                        .pipeline(
                                match(
                                        EvaluationOperators.Expr.valueOf(and(
                                                valueOf("transactionType").equalToValue("$$typeCode"),
                                                or(and(valueOf("purchaseSource").equalToValue("$$distributorNumber"),
                                                                ConditionalOperators.ifNull("$$distributorNumber").then(false)),
                                                        and(valueOf("paymentMethod").equalToValue("$$methodCode"),
                                                                ConditionalOperators.ifNull("$$methodCode").then(false))
                                                )

                                        ))
                                )
                        ).as("cashbookMappings")
        ).withOptions(AggregationOptions.builder()
                .cursorBatchSize(100)
                .allowDiskUse(true)
                .build());

        return mongoOperations.aggregate(aggregation,TRANSACTIONS_COLLECTION, TransactionsAggregated.class).getMappedResults();

    }


    public void saveBiPairFile(BiPairFile biPairFile){
        biPairFileRepository.save(biPairFile);
    }

    public List<BiPairFile> findBiPairFileByFileName(String fileName){
      return  biPairFileRepository.findBiPairFileByFileName(fileName);
    }

    public void deleteBiPairFileByFileName(String fileName){
        biPairFileRepository.deleteByFileName(fileName);
    }

    public List<Transactions> findTransactionsByEventSourceFilename(String fileName) {
        return transactionsRepository.findByFileName(fileName);
    }

    public List<GaSapExtract> findAllGaSapExtracts(){
        return gaSapExtractsRepository.findAll();
    }
    public boolean doesCollectionExist(String collectionName) {
      return mongoTemplate.collectionExists(collectionName);
    }

}
