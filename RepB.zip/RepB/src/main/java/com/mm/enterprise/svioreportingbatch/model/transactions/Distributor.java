package com.mm.enterprise.svioreportingbatch.model.transactions;

import lombok.Data;

@Data
public class Distributor {
    private String number;

}
