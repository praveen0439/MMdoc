package com.mm.enterprise.svioreportingbatch.controller;

import com.mm.enterprise.svioreportingbatch.config.exception.SvioReportingBatchException;
import com.mm.enterprise.svioreportingbatch.config.jobs.BatchJobType;
import com.mm.enterprise.svioreportingbatch.config.service.JobService;
import com.mm.enterprise.svioreportingbatch.config.service.MongoDBService;
import com.mm.enterprise.svioreportingbatch.model.donefiles.DoneFile;
import com.mm.enterprise.svioreportingbatch.model.job.JobDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.access.prepost.PreAuthorize;

import java.util.List;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.*;

@RestController
@RequestMapping(value = "/job")
@Slf4j
public class RestartJobController {

    private final JobService jobService;
    private final MongoDBService mongoDBService;


    public RestartJobController(JobService jobService, MongoDBService mongoDBService) {
        this.jobService = jobService;
        this.mongoDBService = mongoDBService;
    }

    @PreAuthorize("hasAuthority('SVIO_REPORTING_BATCH_SCOPE')")
    @PostMapping(value = "/restart", produces = MediaType.APPLICATION_JSON_VALUE)
    public String restart(@RequestBody JobDetails jobDetails) {
        log.info("Manually restarting job {}.", jobDetails.getJobName());

        if (BatchJobType.GASAP_EVENTS.getValue().equals(jobDetails.getJobName())){
            runGasapJob(jobDetails);
            return "Status BI successfully deleted.";
        } else {
            restartJob(jobDetails);
            return "Job manually restarted : " + jobDetails.getJobName();
        }
    }
    private void runGasapJob(JobDetails jobDetails) {
        // gasap job is a scheduler, if it does not have the statusBi, will run again
        List<DoneFile> donefiles = mongoDBService.findDoneByStatusBiAndFileName(FAILED, jobDetails.getDoneFile());
        if (!donefiles.isEmpty()) {
        donefiles.get(0).getEventHeader().setStatusBi(null);
        mongoDBService.saveDoneFile(donefiles.get(0));
        log.info("Status Bi successfully deleted for failed {} job.", jobDetails.getJobName());
        }
        else {
            log.error("Done file not present for file : {}", jobDetails.getDoneFile());
        }
    }

    private void restartJob(JobDetails jobDetails) {
        JobParameters jobParameters = new JobParametersBuilder()
                .addString("inputTransactionFile", jobDetails.getFilTransactionFileName())
                .addString("inputDisbursementFile", jobDetails.getFilDisbursementFileName()) //used for TransactionDisbursmentJob
                .addString("inputControlFile", jobDetails.getCtrlFileName()) //used for TransactionDisbursmentJob
                .addString("inputFilFile", jobDetails.getFilTransactionFileName()) //used for TransactionExtractJob
                .addLong(CURRENT_TIME, System.currentTimeMillis())
                .toJobParameters();

        try {
            jobService.startJob(jobDetails.getJobName(), jobParameters);
        } catch (SvioReportingBatchException e) {
            log.error("Error when mannually restarting the job");
            throw  e;
        }
    }
}






























