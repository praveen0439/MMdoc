package com.mm.enterprise.svioreportingbatch.model.disbursement;

import lombok.Data;

@Data
public class Payee {
    private Address address;
    private BankAccount bankAccount;
    private Name name;
}
