package com.mm.enterprise.svioreportingbatch.tasklets;

import com.mm.enterprise.svioreportingbatch.config.service.MongoDBService;
import com.mm.enterprise.svioreportingbatch.config.util.Validator;
import com.mm.enterprise.svioreportingbatch.model.controlfiles.ControlFile;
import com.mm.enterprise.svioreportingbatch.model.disbursement.Disbursements;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.INPUT_DISBURSEMENT_FILE;

@Component
@Slf4j
@RequiredArgsConstructor
public class DisbursementsValidator implements Tasklet, StepExecutionListener {

    private final MongoDBService mongoDBService;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        JobParameters jobParameters = contribution.getStepExecution().getJobParameters();
        String disbursementsFilFile=jobParameters.getParameters().get(INPUT_DISBURSEMENT_FILE).getValue().toString();
        List<ControlFile> controlFileList=mongoDBService.findControlByEventSourceRefFilename(disbursementsFilFile);
        Validator.validateControlCollection(controlFileList,disbursementsFilFile);
        ControlFile controlFile = controlFileList.stream().max(Comparator.comparing(ControlFile::getEventGeneratedDateTime)).get();
        List<Disbursements> disbursementsList = mongoDBService.findDisbursementsByFileName(disbursementsFilFile);
        Validator.validateRecordCountAndTotalAmountDisbursements(disbursementsList,controlFile);
        return null;
    }

    @Override
    public void beforeStep(StepExecution stepExecution) {
        StepExecutionListener.super.beforeStep(stepExecution);
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        return StepExecutionListener.super.afterStep(stepExecution);
    }
}
