package com.mm.enterprise.svioreportingbatch.config.jobs;

import com.mm.enterprise.svioreportingbatch.config.exception.KafkaMessageServiceException;
import com.mm.enterprise.svioreportingbatch.config.service.KafkaTopicAlertService;
import com.mm.enterprise.svioreportingbatch.config.service.PostgresDBService;
import com.mm.enterprise.svioreportingbatch.model.cashbookdata.ExecutionLog;
import com.mm.enterprise.svioreportingbatch.model.springbatchmetadata.JobStatus;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.KafkaException;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import static com.mm.enterprise.svioreportingbatch.config.exception.KafkaMessageServiceException.KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE;
import static com.mm.enterprise.svioreportingbatch.config.exception.KafkaMessageServiceException.WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE;
@Component
@RequiredArgsConstructor
@Slf4j
public class CashbookApprovalScheduler {

    private final PostgresDBService postgresDBService;
    private final KafkaTopicAlertService kafkaTopicAlertService;
    @Value(value = "${mm.svio.reportingbatch.environment}")
    private String env;

    @Scheduled(cron="${cashbookApprovalNotification.schedule.cron}")
    public void runBatchJob(){
        LocalDate runDate = LocalDate.now();

        // Prevent execution if already done today
        if(postgresDBService.findByExecutionDate(runDate).isEmpty()){
            List<JobStatus> transactionExtractEventJob= postgresDBService.findJobStatusByNameAndDate("transactionExtractEventsJob",runDate);
            List<JobStatus> shareholdersExtractsChunkJob=postgresDBService.findJobStatusByNameAndDate("shareholdersExtractsChunkJob",runDate);
            if(transactionExtractEventJob.size()>0 && shareholdersExtractsChunkJob.size()>0){
                String cashbookDate= DateTimeFormatter.ofPattern("MM-dd-yyyy").format(LocalDate.now());
                String businessNotificationMessage=String.format("The "+env+" SVI Cashbook for %s is complete and cashbook is ready for approval.",cashbookDate);
                postgresDBService.saveExecutionLogRepository(new ExecutionLog(runDate));
                try {
                    kafkaTopicAlertService.sendBusinessNotification(businessNotificationMessage);
                    postgresDBService.saveExecutionLogRepository(new ExecutionLog(runDate));
                } catch (InterruptedException | ExecutionException | TimeoutException e) {
                    Thread.currentThread().interrupt();
                    throw new KafkaMessageServiceException(WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE, e);
                } catch (KafkaException e) {
                    throw new KafkaMessageServiceException(KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE, e);
                }
            }
        }


    }

}
