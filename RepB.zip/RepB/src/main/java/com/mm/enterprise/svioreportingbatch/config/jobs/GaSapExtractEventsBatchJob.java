
package com.mm.enterprise.svioreportingbatch.config.jobs;

import com.mm.enterprise.svioreportingbatch.config.service.MongoDBService;
import com.mm.enterprise.svioreportingbatch.listener.SvioReportingBatchExecutionListenerGaSap;
import com.mm.enterprise.svioreportingbatch.model.cashbookdata.CashbookData;
import com.mm.enterprise.svioreportingbatch.model.gasapextract.GaSapExtract;
import com.mm.enterprise.svioreportingbatch.processor.GaSapExtractProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.support.ListItemReader;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.INSERT_SQL;

@Configuration
@Slf4j
@RequiredArgsConstructor
public class GaSapExtractEventsBatchJob {

    private final MongoDBService mongoDBService;
    private final GaSapExtractProcessor gaSapExtractProcessor;
    private  final SvioReportingBatchExecutionListenerGaSap svioReportingBatchExecutionListenerGaSap;


    private final DataSource dataSource;

    @Bean
    public Job gaSapExtractEventsJob(JobRepository jobRepository, PlatformTransactionManager transactionManager){
        return new JobBuilder(BatchJobType.GASAP_EVENTS.getValue(),jobRepository)
                .start(createGaSapExtractEventStep(jobRepository, transactionManager))
                .listener(svioReportingBatchExecutionListenerGaSap)
                .build();

    }

    @Bean
    protected Step createGaSapExtractEventStep(JobRepository jobRepository, PlatformTransactionManager transactionManager){
        return new StepBuilder("createGaSapExtractEventStep",jobRepository)
                .<GaSapExtract, CashbookData>chunk(100,transactionManager)
                .reader(gaSapExtractItemReader())
                .processor(gaSapExtractProcessor)
                .writer(gaSapExtractwriter(dataSource))
                .build();
    }

    @StepScope
    @Bean("GaSapExtractItemReader")
    public ListItemReader<GaSapExtract> gaSapExtractItemReader() {
        return new ListItemReader<>(mongoDBService.findAllGaSapExtracts());
    }



    @Bean
    public JdbcBatchItemWriter<CashbookData> gaSapExtractwriter(DataSource dataSource) {
        return new JdbcBatchItemWriterBuilder<CashbookData>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql(INSERT_SQL)
                .dataSource(dataSource)
                .build();
    }

}
