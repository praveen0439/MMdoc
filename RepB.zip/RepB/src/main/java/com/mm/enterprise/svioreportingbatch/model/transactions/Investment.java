package com.mm.enterprise.svioreportingbatch.model.transactions;

import lombok.Data;

@Data
public class Investment {
    private String unitCount;
    private String value;
    private String typeCode;
    private Fund fund;
}
