package com.mm.enterprise.svioreportingbatch.repository.jpa;

import com.mm.enterprise.svioreportingbatch.model.cashbookdata.CashbookData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;

@Repository
public interface CashBookDataRepository extends JpaRepository<CashbookData,Long> {

    public void deleteCashbookDataByUpdateDtAndLoginUserId(Timestamp updateDt,String loginUserId);
}
