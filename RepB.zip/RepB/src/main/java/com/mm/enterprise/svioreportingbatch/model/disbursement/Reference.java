package com.mm.enterprise.svioreportingbatch.model.disbursement;

import lombok.Data;

@Data
public class Reference {
    private String id;
}
