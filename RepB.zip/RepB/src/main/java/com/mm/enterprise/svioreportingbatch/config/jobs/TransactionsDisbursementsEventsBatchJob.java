package com.mm.enterprise.svioreportingbatch.config.jobs;

import com.mm.enterprise.svioreportingbatch.config.service.MongoDBService;
import com.mm.enterprise.svioreportingbatch.listener.SvioReportingBatchExecutionListenerTransDisb;
import com.mm.enterprise.svioreportingbatch.model.cashbookdata.CashbookData;
import com.mm.enterprise.svioreportingbatch.model.transactions.TransactionsAggregated;
import com.mm.enterprise.svioreportingbatch.processor.TransactionDisbursementExtractProcessor;
import com.mm.enterprise.svioreportingbatch.tasklets.CollectionsValidator;
import com.mm.enterprise.svioreportingbatch.tasklets.DisbursementsValidator;
import com.mm.enterprise.svioreportingbatch.tasklets.TransactionsValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.support.ListItemReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

import java.util.List;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.INSERT_SQL;

@RequiredArgsConstructor
@Configuration
public class TransactionsDisbursementsEventsBatchJob {
    private final MongoDBService mongoDBService;
    private final DataSource dataSource;

    private final TransactionsValidator transactionsValidator;

    private final DisbursementsValidator disbursementsValidator;

    private final CollectionsValidator collectionsValidator;

    private final SvioReportingBatchExecutionListenerTransDisb svioReportingBatchExecutionListenerTransDisb;

    private final TransactionDisbursementExtractProcessor transactionDisbursementExtractProcessor;

    @Bean
    public Job transactionsDisbursementsEventsJob(JobRepository jobRepository, PlatformTransactionManager transactionManager){
        return new JobBuilder(BatchJobType.TRANSACTIONS_DISBURSEMENTS_EVENTS.getValue(),jobRepository)
                .start(collectionsValidatorStep(jobRepository,transactionManager))
                .next(transactionsValidatorStep(jobRepository,transactionManager))
                .next(disbursementsValidatorStep(jobRepository,transactionManager))
                .next(createTransactionsDisbursementsEventsStep(jobRepository,transactionManager))
                .listener(svioReportingBatchExecutionListenerTransDisb)
                .build();

    }

    @Bean
    protected Step transactionsValidatorStep(JobRepository jobRepository, PlatformTransactionManager transactionManager){
        return new StepBuilder("transactionsValidatorStep",jobRepository)
                .tasklet(transactionsValidator,transactionManager)
                .build();

    }
    @Bean
    protected Step disbursementsValidatorStep(JobRepository jobRepository, PlatformTransactionManager transactionManager){
        return new StepBuilder("disbursementsValidatorStep",jobRepository)
                .tasklet(disbursementsValidator,transactionManager)
                .build();
    }

    @Bean
    protected Step collectionsValidatorStep(JobRepository jobRepository, PlatformTransactionManager transactionManager){
        return new StepBuilder("collectionsValidatorStep",jobRepository)
                .tasklet(collectionsValidator,transactionManager)
                .build();

    }
    @Bean
    protected Step createTransactionsDisbursementsEventsStep(JobRepository jobRepository, PlatformTransactionManager platformTransactionManager){
        return new StepBuilder("createTransactionsDisbursementsEventsStep",jobRepository)
                .<TransactionsAggregated, CashbookData>chunk(100,platformTransactionManager)
                .reader(transactionsAggregatedListItemReader(null,null))
                .processor(transactionDisbursementExtractProcessor)
                .writer(transactionsDisbursementsEventwriter(dataSource))
                .build();

    }
    @StepScope
    @Bean("transactionsAggregatedListItemReader")
    public ListItemReader<TransactionsAggregated> transactionsAggregatedListItemReader(@Value("#{jobParameters['inputTransactionFile']}") String transactionFilFileName,@Value("#{jobParameters['inputDisbursementFile']}") String disbursementFilFileName ){
       return new ListItemReader<>(null);
        // return new ListItemReader<>((List<TransactionsAggregated>)mongoDBService.getMongoAggregatedCollection(transactionFilFileName,disbursementFilFileName));
    }


    @Bean("transactionsDisbursementsEventwriter")
    public JdbcBatchItemWriter<CashbookData> transactionsDisbursementsEventwriter(DataSource dataSource) {
        return new JdbcBatchItemWriterBuilder<CashbookData>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql(INSERT_SQL)
                .dataSource(dataSource)
                .build();
    }


}
