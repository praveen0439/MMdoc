
package com.mm.enterprise.svioreportingbatch.mapper;

import com.mm.enterprise.svioreportingbatch.model.cashbookdata.CashbookData;
import com.mm.enterprise.svioreportingbatch.model.transactions.TransactionsAggregated;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.SVI_BI_TR_DISB;

@Component
@Slf4j(topic = "logger")
@RequiredArgsConstructor
public class TransactionDisbursementExtractMapper {


    public static Timestamp stringToDt(String dateString) {
        if (dateString.equals("00000000"))
            dateString = "99991231";
        LocalDateTime localDateTime = LocalDate.parse(dateString, DateTimeFormatter.BASIC_ISO_DATE).atTime(00, 00, 00);
        return Timestamp.valueOf(localDateTime);

    }

    public CashbookData mapFromMongoCollection(TransactionsAggregated transactionsExtractsAggregated,Timestamp updateDt){
        String adminNumber = transactionsExtractsAggregated.getContract().getInvestment().getFund().getAdminNumber();
        String distbrNumber = transactionsExtractsAggregated.getContract().getDistributor().getNumber();
        String productTypeCd = "";
        if (adminNumber.startsWith("S"))
            productTypeCd = "SIA";
        else if (adminNumber.startsWith("G"))
            productTypeCd = "GIA";

        String mediumCde;
        if (distbrNumber == null)
            mediumCde = transactionsExtractsAggregated.getPayoutTransaction().getPayout().getMethodCode();
        else mediumCde = distbrNumber;

        String bankName = null;
        String bankName2 = null;
        String city = null;
        String stateOrProvinceCD = null;
        String id = null;
        String accountNumber = null;
        String fullName = null;
        String instrLine4Txt = null;
        String instrLine5Txt = null;
        String instrLine6Txt = null;


        if (!transactionsExtractsAggregated.getDisbursements().isEmpty()) {
            bankName = transactionsExtractsAggregated.getDisbursements().get(0).getPayoutTransaction().getPayee().getBankAccount().getBankName();
            bankName2 = transactionsExtractsAggregated.getDisbursements().get(0).getEventHeader().getMetadata().getBankName2();
            city = transactionsExtractsAggregated.getDisbursements().get(0).getPayoutTransaction().getPayee().getAddress().getCity();
            stateOrProvinceCD = transactionsExtractsAggregated.getDisbursements().get(0).getPayoutTransaction().getPayee().getAddress().getStateOrProvinceCode();
            if(stateOrProvinceCD!=null)
                stateOrProvinceCD=stateOrProvinceCD.toUpperCase();
            id = transactionsExtractsAggregated.getDisbursements().get(0).getPayoutTransaction().getPayee().getBankAccount().getId();
            accountNumber = transactionsExtractsAggregated.getDisbursements().get(0).getPayoutTransaction().getPayee().getBankAccount().getAccountNumber();
            fullName = transactionsExtractsAggregated.getDisbursements().get(0).getPayoutTransaction().getPayee().getName().getFullName();
            instrLine4Txt = transactionsExtractsAggregated.getDisbursements().get(0).getEventHeader().getMetadata().getInstructionLine4();
            instrLine5Txt = transactionsExtractsAggregated.getDisbursements().get(0).getEventHeader().getMetadata().getInstructionLine5();
            instrLine6Txt = transactionsExtractsAggregated.getDisbursements().get(0).getEventHeader().getMetadata().getInstructionLine6();
        }

        String cashbookTypeDesc = null;
        String cashbookClassDesc = null;
        String cashbookActivityDesc = null;

        if (!transactionsExtractsAggregated.getCashbookMappings().isEmpty()) {
            cashbookTypeDesc = transactionsExtractsAggregated.getCashbookMappings().get(0).getCashbookTypeDesc();
            cashbookClassDesc = transactionsExtractsAggregated.getCashbookMappings().get(0).getCashbookClassDesc();
            cashbookActivityDesc = transactionsExtractsAggregated.getCashbookMappings().get(0).getCashbookActivityDesc();
        }
        String fundNm = null;
        String contractStateCde = transactionsExtractsAggregated.getPayoutTransaction().getPayee().getAddress().get(0).getStateOrProvinceCode();
        if(contractStateCde!=null)
            contractStateCde=contractStateCde.toUpperCase();


      return CashbookData.builder()
              .accountNum(transactionsExtractsAggregated.getContract().getPrimaryId())
              .subAccountNum(transactionsExtractsAggregated.getContract().getSuffix())
              .productTypeCde(productTypeCd)
              .fundIdCde(transactionsExtractsAggregated.getContract().getInvestment().getFund().getReference().getId())
              .fundNm(fundNm)
              .txnTypeCde("T")
              .phxTxnTypeCde(transactionsExtractsAggregated.getTransaction().getTypeCode())
              .mediumCde(mediumCde)
              .cashbookTypeDesc(cashbookTypeDesc)
              .cashbookClassDesc(cashbookClassDesc)
              .cashbookActivityDesc(cashbookActivityDesc)
              .cashAmt(new BigDecimal(transactionsExtractsAggregated.getContract().getInvestment().getValue()))
              .effectiveDt(stringToDt(transactionsExtractsAggregated.getTransaction().getEffectiveDate()))
              .valuationDt(stringToDt(transactionsExtractsAggregated.getTrade().getTradeDate()))
              .cashbookDt(stringToDt(transactionsExtractsAggregated.getTrade().getSettlementDate()))
              .postDt(stringToDt(transactionsExtractsAggregated.getPayoutTransaction().getPayout().getPostingDate()))
              .payeeNm(bankName)
              .bankNm(bankName2)
              .bankCityNm(city)
              .bankStateCde(stateOrProvinceCD)
              .instrLine1Txt(id)
              .instrLine2Txt(accountNumber)
              .instrLine3Txt(fullName)
              .instrLine4Txt(instrLine4Txt)
              .instrLine5Txt(instrLine5Txt)
              .instrLine6Txt(instrLine6Txt)
              .contractStateCde(contractStateCde)
              .updateDt(updateDt)
              .loginUserId(SVI_BI_TR_DISB)
              .build();

    }

}

