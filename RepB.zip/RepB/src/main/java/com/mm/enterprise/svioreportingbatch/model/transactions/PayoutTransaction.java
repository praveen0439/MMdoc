package com.mm.enterprise.svioreportingbatch.model.transactions;

import lombok.Data;

@Data
public class PayoutTransaction {
    private Payout payout;
    private Payee payee;
}
