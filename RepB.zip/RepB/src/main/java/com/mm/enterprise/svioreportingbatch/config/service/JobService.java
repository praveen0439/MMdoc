package com.mm.enterprise.svioreportingbatch.config.service;
import com.mm.enterprise.svioreportingbatch.config.exception.SvioReportingBatchException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class JobService {

    private final JobLauncher jobLauncher;
    private final JobSelector jobSelector;
    private final KafkaTopicAlertService kafkaTopicAlertService;

    public JobParameters getJobParameters(String eventSourceFilFile, String eventSourceFileType, String eventSourceControlFile) {
        final Map<String, JobParameter<?>> params = new HashMap<>();
        if (eventSourceFileType.equals("TRANSACTIONSEXTRACT")) {
            params.put(INPUT_FIL_FILE, new JobParameter<>(eventSourceFilFile, String.class));
            params.put(INPUT_FILE_TYPE, new JobParameter<>(eventSourceFileType, String.class));
            params.put(INPUT_CONTROL_FILE, new JobParameter<>(eventSourceControlFile, String.class));
        } else {
            String transactionFilFileName = eventSourceFilFile.replace("CARSDIST", "CARSTR");
            String disbursementFilFileName = eventSourceFilFile.replace("CARSTR", "CARSDIST");
            params.put(INPUT_FIL_FILE, new JobParameter<>(eventSourceFilFile, String.class));
            params.put(INPUT_FILE_TYPE, new JobParameter<>(eventSourceFileType, String.class));
            params.put(INPUT_CONTROL_FILE, new JobParameter<>(eventSourceControlFile, String.class));
            params.put(INPUT_TRANSACTION_FILE, new JobParameter<>(transactionFilFileName, String.class));
            params.put(INPUT_DISBURSEMENT_FILE, new JobParameter<>(disbursementFilFileName, String.class));
        }
        params.put(CURRENT_TIME, new JobParameter<>(System.currentTimeMillis(), Long.class));
        return new JobParameters(params);
    }

    @Async
    public JobExecution startJob(String jobName, JobParameters jobParameters) {
        final JobExecution jobExecution;
        Job job = jobSelector.get(jobName);
        try {
            log.info("Starting the job {}",jobName);
            jobExecution = jobLauncher.run(job, jobParameters);
            log.info("Job execution id: " + jobExecution.getId());
        } catch (Exception e) {
            String message = String.format("Exception while starting the job %s with parameters %s. %s", jobName, jobParameters, e);
            kafkaTopicAlertService.sendError(message);
            log.error("Exception while starting the job: {}", jobName, e);
            throw new SvioReportingBatchException(message + e.getMessage(),e);
        }
        return jobExecution;
    }
}
