package com.mm.enterprise.svioreportingbatch.listener;

import com.mm.enterprise.svioreportingbatch.abstracts.SvioReportingBatchExecutionListener;
import com.mm.enterprise.svioreportingbatch.config.exception.KafkaMessageServiceException;
import com.mm.enterprise.svioreportingbatch.config.exception.SvioReportingBatchException;
import com.mm.enterprise.svioreportingbatch.config.service.KafkaTopicAlertService;
import com.mm.enterprise.svioreportingbatch.config.service.MongoDBService;
import com.mm.enterprise.svioreportingbatch.config.service.PostgresDBService;
import com.mm.enterprise.svioreportingbatch.mapping.CashbookMappingIssues;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.kafka.KafkaException;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;

import static com.mm.enterprise.svioreportingbatch.config.exception.KafkaMessageServiceException.KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE;
import static com.mm.enterprise.svioreportingbatch.config.exception.KafkaMessageServiceException.WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE;
import static com.mm.enterprise.svioreportingbatch.config.util.Constants.*;
@Component
@RequiredArgsConstructor
@Slf4j
public class SvioReportingBatchExecutionListenerTransDisb implements SvioReportingBatchExecutionListener {

    private final KafkaTopicAlertService kafkaTopicAlertService;

    private final MongoDBService mongoDBService;

    private final PostgresDBService postgresDBService;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.info("Starting SvioReportingBatchJobExecutionListener");
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        log.info("{} finished with status {}", jobExecution.getJobInstance().getJobName(), jobExecution.getExitStatus());
        List<StepExecution> stepExecutions = new ArrayList<>(jobExecution.getStepExecutions());
        JobParameters jobParameters = jobExecution.getJobParameters();

        if (ExitStatus.COMPLETED.equals(jobExecution.getExitStatus())) {
            ExecutionContext executionContext = jobExecution.getExecutionContext();
            final long writeCount = executionContext.getLong(WRITE_COUNT);
            final HashSet<CashbookMappingIssues> cashbookMappingIssuesHashSet= (HashSet<CashbookMappingIssues>)executionContext.get(CASHBOOK_MAPPING_ISSUES);
            String transactionFilFileName=((String)jobParameters.getParameters().get(INPUT_TRANSACTION_FILE).getValue());
            String disbursementFilFileName=((String)jobParameters.getParameters().get(INPUT_DISBURSEMENT_FILE).getValue());
            String notificationCashbookMappingIssues="";
            String notificationMessage = String.format("Svio reporting batch job executed successfully for Transaction/Disbursement event for files %s , %s. No. of rows inserted %s", transactionFilFileName, disbursementFilFileName,writeCount);
            if(!cashbookMappingIssuesHashSet.isEmpty()){
                notificationCashbookMappingIssues=String.format(NO_CASHBOOK_MAPPING_FOUND, CASHBOOKMAPPING_COLLECTION, cashbookMappingIssuesHashSet.stream().map(CashbookMappingIssues::toString).collect(Collectors.joining(" & ")));
                log.warn(notificationCashbookMappingIssues);
            }
            try {
                if(cashbookMappingIssuesHashSet.isEmpty()){
                    kafkaTopicAlertService.sendNotification(notificationMessage);
                } else{
                    kafkaTopicAlertService.sendWarningNotification(notificationMessage+"\n"+notificationCashbookMappingIssues);
                }

                log.info("Deleting the status collection biPairFile for the processed files :"+transactionFilFileName+","+disbursementFilFileName);
                mongoDBService.deleteBiPairFileByFileName(transactionFilFileName);
                mongoDBService.deleteBiPairFileByFileName(disbursementFilFileName);


            } catch (InterruptedException | ExecutionException | TimeoutException e) {
                Thread.currentThread().interrupt();
                throw new KafkaMessageServiceException(WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE, e);
            } catch (KafkaException e) {
                throw new KafkaMessageServiceException(KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE, e);
            }
        } else {
            Timestamp updateDt=(Timestamp) jobExecution.getExecutionContext().get(UPDATE_DATE);
            StepExecution failedStepExecution = stepExecutions.get(stepExecutions.size() - 1);
            List<Throwable> failureExceptions = failedStepExecution.getFailureExceptions();

            String localisedErrorMessage;
            if (failureExceptions.get(failureExceptions.size() - 1).getCause() != null) {
                localisedErrorMessage = failureExceptions.get(failureExceptions.size() - 1).getCause().toString();
            } else {
                localisedErrorMessage = failureExceptions.get(failureExceptions.size() - 1).getLocalizedMessage();
            }

            String errorMessage =
                    jobExecution.getJobInstance().getJobName() + " job FAILED in step: " + failedStepExecution.getStepName() + " with error: "
                            + localisedErrorMessage;
            var exception =failureExceptions.get(failureExceptions.size() - 1);
            if(!(exception instanceof SvioReportingBatchException.BusinessValidationRetryableException))
                kafkaTopicAlertService.sendError(errorMessage);
            postgresDBService.deleteLoadedCashbookDataOnFailure(updateDt,SVI_BI_TR_DISB);
        }
    }
}
