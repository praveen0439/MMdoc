package com.mm.enterprise.svioreportingbatch.model.disbursement;

import lombok.Data;

import java.time.LocalDate;

@Data
public class Metadata {
    private String eventSourceFilename;
    private String instructionLine4;
    private String instructionLine5;
    private String instructionLine6;
    private String bankName2;
    private String fileGeneratedDate;
    private LocalDate processedDate;
}
