
package com.mm.enterprise.svioreportingbatch.config.kafka;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.kafka.common.config.SslConfigs;

import java.util.Map;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class KafkaHelpers {

    public static void enableKafkaSecurity(Map<String, Object> configs, KafkaConfiguration configuration) {
        String trustStore = configuration.getTrustStore();
        if (trustStore != null) {
            configs.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, trustStore);
            configs.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, trustStore);

        }
        String trustStorePassword = configuration.getTrustStorePassword();
        if (trustStorePassword != null) {
            configs.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, trustStorePassword);
            configs.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, trustStorePassword);
            configs.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, trustStorePassword);

        }
        String securityProtocol = configuration.getSecurityProtocol();
        if (securityProtocol != null) {
            configs.put("security.protocol", securityProtocol);
        }
        String authCredentialSource = configuration.getAuthCredentialSource();
        if (authCredentialSource != null) {
            configs.put("basic.auth.credentials.source", authCredentialSource);
        }
        String authUserInfo = configuration.getAuthUserInfo();
        if (authUserInfo != null) {
            configs.put("basic.auth.user.info", authUserInfo);
        }
        String saslMechanism = configuration.getSaslMechanism();
        if (saslMechanism != null) {
            configs.put("sasl.mechanism", saslMechanism);
        }
        String saslLoginCallback = configuration.getSaslLoginCallback();
        if (saslLoginCallback != null) {
            configs.put("sasl.login.callback.handler.class", saslLoginCallback);
        }
        String saslJaasConfig = configuration.getSaslJaasConfig();
        if (saslJaasConfig != null) {
            configs.put("sasl.jaas.config", saslJaasConfig);
        }
    }

}

