package com.mm.enterprise.svioreportingbatch.model.transactionextract;

import lombok.Data;

@Data
public class Payout {
    private String postingDate;
    private String methodCode;
}
