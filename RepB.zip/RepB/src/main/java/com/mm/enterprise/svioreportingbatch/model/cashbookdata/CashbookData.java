package com.mm.enterprise.svioreportingbatch.model.cashbookdata;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.sql.Timestamp;


@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name="cashbook_data")
public class CashbookData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  Long cashbookId;
    private  String accountNum;
    private  String subAccountNum;
    private  String productTypeCde;
    private  String fundIdCde;
    private  String fundNm;
    private  String txnTypeCde;
    private  String phxTxnTypeCde;
    private  String mediumCde;
    private  String cashbookTypeDesc;
    private  String cashbookClassDesc;
    private  String cashbookActivityDesc;
    private  BigDecimal cashAmt;
    private  Timestamp effectiveDt;
    private  Timestamp valuationDt;
    private  Timestamp cashbookDt;
    private  Timestamp postDt;
    private  String payeeNm;
    private  String bankNm;
    private  String bankCityNm;
    private  String bankStateCde;
    @Column(name="instr_line1_txt")
    private  String instrLine1Txt;
    @Column(name="instr_line2_txt")
    private  String instrLine2Txt;
    @Column(name="instr_line3_txt")
    private  String instrLine3Txt;
    @Column(name="instr_line4_txt")
    private  String instrLine4Txt;
    @Column(name="instr_line5_txt")
    private  String instrLine5Txt;
    @Column(name="instr_line6_txt")
    private  String instrLine6Txt;
    private  String contractStateCde;
    private  String companyCode;
    private  String businessAreaCde;
    private  String glAccountNum;
    @Column(name = "profit_center_num")
    private  String profitCenterCde;
    private  Timestamp updateDt;
    private  String loginUserId;

}
