package com.mm.enterprise.svioreportingbatch.abstracts;

import org.springframework.batch.core.JobExecutionListener;

public interface SvioReportingBatchExecutionListener extends JobExecutionListener {
}
