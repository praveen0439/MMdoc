package com.mm.enterprise.svioreportingbatch.model.donefiles;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class EventHeader {

    private String eventBatchGroupId;
    private Long eventBatchRecordCountTotal;
    private BigDecimal eventBatchTotalAmt;
    private String eventCorrelationId;
    private String eventSource;
    private String eventSourceDescription;
    private String eventInitiatorDescription;
    private String eventInitiator;
    private String eventGeneratedDateTime;
    private String eventType;
    private String statusSia;
    private String statusGia;
    private String statusBi;
    private Metadata metadata;
}
