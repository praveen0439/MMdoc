package com.mm.enterprise.svioreportingbatch.model.transactions;

import lombok.Data;

@Data
public class TransactionsEventHeader {
    private String eventType;
    private String eventSubtype;
    private String eventDateTime;
    private String eventGeneratedDateTime;
    private String eventCorrelationId;
    private String eventRequestId;
    private String eventSourceDescription;
    private String eventSource;
    private String eventInitiatorDescription;
    private String eventInitiator;
    private String eventBatchGroupId;
    private String eventBatchRecordCountTotal;
    private String eventBatchRecordOffset;
    private String eventBatchTotalAmount;
    private TransactionsMetadata metadata;
}
