package com.mm.enterprise.svioreportingbatch.tasklets;

import com.mm.enterprise.svioreportingbatch.config.service.MongoDBService;
import com.mm.enterprise.svioreportingbatch.config.util.Validator;
import com.mm.enterprise.svioreportingbatch.model.controlfiles.ControlFile;
import com.mm.enterprise.svioreportingbatch.model.transactions.Transactions;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.INPUT_TRANSACTION_FILE;

@Component
@Slf4j
@RequiredArgsConstructor
public class TransactionsValidator implements Tasklet, StepExecutionListener {

    private final MongoDBService mongoDBService;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        JobParameters jobParameters = contribution.getStepExecution().getJobParameters();
        String transactionFilFileName=jobParameters.getParameters().get(INPUT_TRANSACTION_FILE).getValue().toString();
        List<ControlFile> controlFileList=mongoDBService.findControlByEventSourceRefFilename(transactionFilFileName);
        Validator.validateControlCollection(controlFileList,transactionFilFileName);
        ControlFile controlFile = controlFileList.stream().max(Comparator.comparing(ControlFile::getEventGeneratedDateTime)).get();
        List<Transactions> transactionsList = mongoDBService.findTransactionsByEventSourceFilename(transactionFilFileName);
        Validator.validateRecordCountAndTotalAmountTransactions(transactionsList,controlFile);
        return null;
    }

    @Override
    public void beforeStep(StepExecution stepExecution) {
        StepExecutionListener.super.beforeStep(stepExecution);
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        return StepExecutionListener.super.afterStep(stepExecution);
    }
}
