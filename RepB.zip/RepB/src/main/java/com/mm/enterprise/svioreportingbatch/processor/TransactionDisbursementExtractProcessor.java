package com.mm.enterprise.svioreportingbatch.processor;

import com.mm.enterprise.svioreportingbatch.mapper.TransactionDisbursementExtractMapper;
import com.mm.enterprise.svioreportingbatch.mapping.CashbookMappingIssues;
import com.mm.enterprise.svioreportingbatch.model.cashbookdata.CashbookData;
import com.mm.enterprise.svioreportingbatch.model.transactions.TransactionsAggregated;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;

import static com.mm.enterprise.svioreportingbatch.config.util.ItemProcessorHelper.getBatchUpdateDt;
import static com.mm.enterprise.svioreportingbatch.config.util.ItemProcessorHelper.updateWriteCount;
import java.util.HashSet;

import static com.mm.enterprise.svioreportingbatch.config.util.ItemProcessorHelper.*;

@Component
@Slf4j(topic = "logger")
@RequiredArgsConstructor
public class TransactionDisbursementExtractProcessor implements ItemProcessor<TransactionsAggregated, CashbookData>, StepExecutionListener {
    private final TransactionDisbursementExtractMapper transactionDisbursementExtractMapper;
    private  StepExecution stepExecution;
    private HashSet<CashbookMappingIssues> cashbookMappingIssues;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        cashbookMappingIssues=new HashSet<>();
        this.stepExecution=stepExecution;
    }

    @Override
    public CashbookData process(TransactionsAggregated transactionsAggregated) throws Exception {
        final Timestamp updateDt=getBatchUpdateDt(stepExecution);
        validateTransactionsAggregated(transactionsAggregated);
        return transactionDisbursementExtractMapper.mapFromMongoCollection(transactionsAggregated,updateDt);

    }

    private void validateTransactionsAggregated(TransactionsAggregated transactionsAggregated) {
    if(transactionsAggregated.getCashbookMappings().isEmpty()){
        cashbookMappingIssues.add(new CashbookMappingIssues(transactionsAggregated.getTransaction().getTypeCode(),transactionsAggregated.getContract().getDistributor().getNumber(),transactionsAggregated.getPayoutTransaction().getPayout().getMethodCode()));
    }
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        updateWriteCount(stepExecution);
        updateCashbookMappingIssues(stepExecution,cashbookMappingIssues);
        return StepExecutionListener.super.afterStep(stepExecution);
    }
}
