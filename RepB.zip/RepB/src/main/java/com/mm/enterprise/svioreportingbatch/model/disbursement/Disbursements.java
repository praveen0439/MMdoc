package com.mm.enterprise.svioreportingbatch.model.disbursement;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.MongoId;

@Data
public class Disbursements {
    @MongoId
    private String id;
    private EventHeader eventHeader;
    private Contract contract;
    private Trade trade;
    private PayoutTransaction payoutTransaction;
    private Transaction transaction;
}
