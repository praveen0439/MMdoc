package com.mm.enterprise.svioreportingbatch.repository.jpa;

import com.mm.enterprise.svioreportingbatch.model.springbatchmetadata.JobStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface SpringBatchMetadataRepository extends JpaRepository<JobStatus,Integer> {
    @Query(value= "select job_instance.job_instance_id ,job_instance.job_name,job_execution.status\n" +
            "from batch_job_instance job_instance join batch_job_execution job_execution\n" +
            "on job_instance.job_instance_id =job_execution.job_instance_id \n" +
            "where date(job_execution.start_time) = :dt and job_instance.job_name = :jobName and job_execution.status='COMPLETED'", nativeQuery = true )
    List<JobStatus> findJobStatusByNameAndDate(String jobName, LocalDate dt);
}
