package com.mm.enterprise.svioreportingbatch.model.donefiles;


import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document("donefiles")
public class DoneFile {
    @Id
    private String id;
    private EventHeader eventHeader;
}
