package com.mm.enterprise.svioreportingbatch.config.util;


import com.mm.enterprise.svioreportingbatch.mapping.CashbookMappingIssues;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.UPDATE_DATE;
import static com.mm.enterprise.svioreportingbatch.config.util.Constants.WRITE_COUNT;
import java.util.Set;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.*;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ItemProcessorHelper {
    private static ExecutionContext getExecutionContext(StepExecution stepExecution) {
        return stepExecution.getJobExecution().getExecutionContext();
    }

    public static void updateWriteCount(StepExecution stepExecution) {
        getExecutionContext(stepExecution).putLong(WRITE_COUNT, stepExecution.getWriteCount());
    }

    public static Timestamp getBatchUpdateDt(StepExecution stepExecution) {
        ExecutionContext jobExecutionContext = getExecutionContext(stepExecution);
        if (jobExecutionContext.containsKey(UPDATE_DATE)) {
            return jobExecutionContext.get(UPDATE_DATE, Timestamp.class);
        } else {
            final Timestamp updateDt = Timestamp.valueOf(LocalDateTime.now());
            jobExecutionContext.put(UPDATE_DATE, updateDt);
            return updateDt;
        }
    }
    public static void updateCashbookMappingIssues(StepExecution stepExecution, Set<CashbookMappingIssues> cashbookMappingIssuesHashSet){
        getExecutionContext(stepExecution).put(CASHBOOK_MAPPING_ISSUES, cashbookMappingIssuesHashSet);
    }










}
