package com.mm.enterprise.svioreportingbatch.config.mongo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnCloudPlatform;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.cloud.CloudPlatform;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.WebIdentityTokenFileCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.REPORTING_SESSION;


@Slf4j
@Configuration
@RequiredArgsConstructor
public class AwsConfig {

    @Bean
    @ConditionalOnCloudPlatform(CloudPlatform.KUBERNETES)
    public AwsCredentialsProvider awsCredentialProvider() {
        return WebIdentityTokenFileCredentialsProvider
                .builder()
                .roleSessionName(REPORTING_SESSION)
                .build();

    }

    @Bean
    @Primary
    @ConditionalOnCloudPlatform(CloudPlatform.KUBERNETES)
    public S3Client s3Client() {
        return S3Client
                .builder()
                .credentialsProvider(awsCredentialProvider())
                .build();
    }

    @Bean
    @ConditionalOnMissingBean(S3Client.class)
    public S3Client locals3Client() {
        return S3Client.builder()
                .region(Region.US_EAST_1)
                .build();
    }
}
