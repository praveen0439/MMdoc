package com.mm.enterprise.svioreportingbatch.repository.mongo;

import com.mm.enterprise.svioreportingbatch.model.status.BiPairFile;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BiPairFileRepository extends MongoRepository<BiPairFile, String> {


    List<BiPairFile> findBiPairFileByFileName(String fileName);

    @Override
    <S extends BiPairFile> S save(S biPairFile);

    //@Query(value = "{'fileName' : ?0}",delete = true)
    void deleteByFileName(String fileName);
}
