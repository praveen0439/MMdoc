package com.mm.enterprise.svioreportingbatch.config.exception;

public class KafkaMessageServiceException extends RuntimeException {

    public static final String WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE = "Exception occurred while waiting for message to be sent";
    public static final String KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE = "Exception occurred while sending a Kafka message";
    public KafkaMessageServiceException(String message, Throwable cause) {
        super(message, cause);


    }
}
