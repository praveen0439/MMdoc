package com.mm.enterprise.svioreportingbatch.config.service;

import com.mm.enterprise.svioreportingbatch.model.cashbookdata.ExecutionLog;
import com.mm.enterprise.svioreportingbatch.model.springbatchmetadata.JobStatus;
import com.mm.enterprise.svioreportingbatch.repository.jpa.CashBookDataRepository;
import com.mm.enterprise.svioreportingbatch.repository.jpa.ExecutionLogRepository;
import com.mm.enterprise.svioreportingbatch.repository.jpa.SpringBatchMetadataRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
@Transactional
public class PostgresDBService {
    private final CashBookDataRepository cashBookDataRepository;
    private final ExecutionLogRepository executionLogRepository;
    private final SpringBatchMetadataRepository springBatchMetadataRepository;

    public void deleteLoadedCashbookDataOnFailure(Timestamp updateDt,String loginUserId){
        cashBookDataRepository.deleteCashbookDataByUpdateDtAndLoginUserId(updateDt,loginUserId);
    }

    public List<JobStatus> findJobStatusByNameAndDate(String jobName, LocalDate dt) {
        return springBatchMetadataRepository.findJobStatusByNameAndDate(jobName,dt);

    }


    public List<ExecutionLog> findByExecutionDate(LocalDate runDate) {
        return executionLogRepository.findByExecutionDate(runDate);
    }

    public void saveExecutionLogRepository(ExecutionLog executionLog) {
        executionLogRepository.save(executionLog);
    }
}
