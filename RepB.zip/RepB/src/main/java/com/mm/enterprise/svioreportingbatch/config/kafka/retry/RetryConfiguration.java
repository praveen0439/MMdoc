package com.mm.enterprise.svioreportingbatch.config.kafka.retry;

import com.mm.enterprise.svioreportingbatch.config.exception.SvioReportingBatchException;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.retrytopic.RetryTopicConfiguration;
import org.springframework.kafka.retrytopic.RetryTopicConfigurationBuilder;
import org.springframework.kafka.retrytopic.RetryTopicNamesProviderFactory;
import org.springframework.kafka.retrytopic.SuffixingRetryTopicNamesProviderFactory;

import java.util.List;

@Configuration
@Slf4j
public class RetryConfiguration {

    @NotNull
    @Value(value = "${mm.svio.reportingbatch.kafka.consumer.retries}")
    private int retries;

    @NotNull
    @Value(value = "${mm.svio.reportingbatch.kafka.consumer.retry-backoff}")
    private Long retriesBackoff;

    @NotNull
    @Value(value = "${mm.svio.reportingbatch.kafka.topic.control}")
    private String topic;
    public static final String RETRY_TOPIC_SUFFIX = ".retry";


    @Bean
    public RetryTopicConfiguration mmKafkaRetryConfiguration( @Qualifier("retryKafkaTemplate") KafkaTemplate<String, Object> retryKafkaTemplate) {
        return RetryTopicConfigurationBuilder
                .newInstance()
                .fixedBackOff(retriesBackoff)
                .useSingleTopicForSameIntervals()
                .maxAttempts(retries)
                .includeTopics(List.of(topic))
                .retryOn(SvioReportingBatchException.BusinessValidationRetryableException.class)
                .retryTopicSuffix(RETRY_TOPIC_SUFFIX)
                .doNotAutoCreateRetryTopics()
                .doNotConfigureDlt()
                .create(retryKafkaTemplate);


    }
    @Bean
    public RetryTopicNamesProviderFactory retryTopicNamesProviderFactory() {
        return properties -> {
            if (properties.isMainEndpoint() || properties.isDltTopic()) {
                return new SuffixingRetryTopicNamesProviderFactory.SuffixingRetryTopicNamesProvider(properties);
            }
            return new SuffixingRetryTopicNamesProviderFactory.SuffixingRetryTopicNamesProvider(properties) {
                @Override
                public String getTopicName(String topic) {
                    return topic + RETRY_TOPIC_SUFFIX;
                }

            };
        };
    }
}


