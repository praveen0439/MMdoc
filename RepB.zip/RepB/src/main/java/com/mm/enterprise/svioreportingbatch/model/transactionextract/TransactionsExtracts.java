package com.mm.enterprise.svioreportingbatch.model.transactionextract;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document("transactionsextracts")
public class TransactionsExtracts {
    @Id
    private String id;
    EventHeader eventHeader;
    Contract contract;
    Trade trade;
    Transaction transaction;
    PayoutTransaction payoutTransaction;
}
