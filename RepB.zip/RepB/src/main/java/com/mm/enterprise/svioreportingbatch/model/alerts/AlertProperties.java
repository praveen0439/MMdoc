package com.mm.enterprise.svioreportingbatch.model.alerts;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

@Data
@ConfigurationProperties(prefix = "mm.svio.reportingbatch.alert")
public class AlertProperties {
    private String topic;
    private List<AlertRecipients> recipients;
}
