package com.mm.enterprise.svioreportingbatch.model.transactions;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class Payee {
    private List<Address> address = new ArrayList<>();

}
