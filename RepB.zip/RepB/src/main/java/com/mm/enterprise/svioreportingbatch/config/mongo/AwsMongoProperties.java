
package com.mm.enterprise.svioreportingbatch.config.mongo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@ToString
@Validated
@Getter
@Setter
@ConfigurationProperties(prefix = "mm.svio.reportingbatch.mongo")
public class AwsMongoProperties {
    private String uri;
}