package com.mm.enterprise.svioreportingbatch.model.transactionextract;

import lombok.Data;

import java.time.LocalDate;

@Data
public class Metadata {
    private String eventSourceFilename;
    private String fileGeneratedDate;
    private String collectionAuthorityIndicator;
    private String transactionSubType;
    private String reverseDate;
    private LocalDate processedDate;
}
