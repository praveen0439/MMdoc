package com.mm.enterprise.svioreportingbatch.repository.mongo;

import com.mm.enterprise.svioreportingbatch.model.disbursement.Disbursements;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DisbursementsRepository extends MongoRepository<Disbursements,String> {

    @Query("{'eventHeader.metadata.eventSourceFilename' : ?0}")
    List<Disbursements> findByFileName(String fileName);
}
