
package com.mm.enterprise.svioreportingbatch.listener;


import businesscustomers.event.agreements.institutionalcontrol.completed.SvioControlCompleted;
import com.mm.enterprise.svioreportingbatch.config.exception.SvioReportingBatchException;
import com.mm.enterprise.svioreportingbatch.config.jobs.BatchJobType;
import com.mm.enterprise.svioreportingbatch.config.service.JobService;
import com.mm.enterprise.svioreportingbatch.config.service.KafkaTopicAlertService;
import com.mm.enterprise.svioreportingbatch.config.service.MongoDBService;
import com.mm.enterprise.svioreportingbatch.model.status.BiPairFile;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.retrytopic.RetryTopicHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.*;

@Component
@EnableKafka
@RequiredArgsConstructor
@Slf4j
public class TriggerBatchKafkaControlListener {

    private final JobService jobService;
    private final MongoDBService mongoDBService;
    private final KafkaTopicAlertService kafkaTopicAlertService;

    @NotNull
    @Value(value = "${mm.svio.reportingbatch.kafka.consumer.retries}")
    private int maxRetries;

    @KafkaListener(containerFactory = "mmKafkaListenerContainerFactory", topics = "${mm.svio.reportingbatch.kafka.topic.control}")
        public void consume(@Payload SvioControlCompleted svioControl,@Header(name = RetryTopicHeaders.DEFAULT_HEADER_ATTEMPTS, required = false) Integer retryAttempt) {
        JobExecution jobExecution;
        if(retryAttempt==null)
            retryAttempt=0;
        log.info("Received payload" + svioControl.toString());

        String eventSourceFileType = svioControl.getEventHeader().getMetadata().getEventSourceFileType().name();
        if (eventSourceFileType.equals("TRANSACTIONSEXTRACT")){
            jobExecution= startJob(svioControl, eventSourceFileType);
            JobexecutionStatus(jobExecution,retryAttempt);
            }
        else if (eventSourceFileType.equals("TRANSACTIONS") || eventSourceFileType.equals("DISBURSEMENTS")) {
            writeToBiFilePairCollection(svioControl);
            if (!waitForPairFile(svioControl, eventSourceFileType)) {
                jobExecution= startJob(svioControl, eventSourceFileType);
                JobexecutionStatus(jobExecution,retryAttempt);
            }
        }

    }

    public JobExecution startJob(SvioControlCompleted svioControl,String eventSourceFileType){
        String eventSourceFilFile;
        String eventSourceControlFile;
        JobParameters jobParameters=null;
        String jobType=null;
        if(eventSourceFileType.equals(TRANSACTIONSEXTRACT)){
            eventSourceFilFile=svioControl.getEventHeader().getMetadata().getEventSourceFilename();
            eventSourceControlFile=eventSourceFilFile;
            jobType=BatchJobType.TRANSACTIONS_EXTRACT_EVENTS.getValue();
            jobParameters= jobService.getJobParameters(eventSourceFilFile,eventSourceFileType,eventSourceControlFile);
        }
        else if(eventSourceFileType.equals(TRANSACTIONS)||eventSourceFileType.equals(DISBURSEMENTS)){
            eventSourceFilFile=svioControl.getEventHeader().getMetadata().getEventSourceReferencedFilename();
            eventSourceControlFile=svioControl.getEventHeader().getMetadata().getEventSourceFilename();
            jobType=BatchJobType.TRANSACTIONS_DISBURSEMENTS_EVENTS.getValue();
            jobParameters= jobService.getJobParameters(eventSourceFilFile,eventSourceFileType,eventSourceControlFile);
        }

        return jobService.startJob(jobType, jobParameters);
    }

    public void JobexecutionStatus(JobExecution jobExecution , int retryAtempt) throws SvioReportingBatchException.BusinessValidationRetryableException {
        if(!jobExecution.getExitStatus().equals(ExitStatus.COMPLETED)) {
            List<StepExecution> stepExecutions = new ArrayList<>(jobExecution.getStepExecutions());
            StepExecution failedStepExecution = stepExecutions.get(stepExecutions.size() - 1);
            List<Throwable> failureExceptions = failedStepExecution.getFailureExceptions();
            Throwable throwable = failureExceptions.get(failureExceptions.size() - 1);

            if(retryAtempt==maxRetries){
                String errorMessage =
                        jobExecution.getJobInstance().getJobName() + " job FAILED in step: " + failedStepExecution.getStepName() + " with error: "
                                + failureExceptions.get(failureExceptions.size() - 1).getCause();
                kafkaTopicAlertService.sendError(errorMessage);
            }

            if(throwable instanceof SvioReportingBatchException.BusinessValidationRetryableException){
                throw new SvioReportingBatchException.BusinessValidationRetryableException(throwable.getMessage());
            }
        }
    }

    public boolean waitForPairFile(SvioControlCompleted svioControl,String eventSourceFileType){
        String filFileName=svioControl.getEventHeader().getMetadata().getEventSourceReferencedFilename();
        String pairFile= getPairFileName(filFileName,eventSourceFileType);

        List<BiPairFile> biPairFileList=mongoDBService.findBiPairFileByFileName(pairFile);
        return biPairFileList.isEmpty();
    }

    public void writeToBiFilePairCollection(SvioControlCompleted svioControlCompleted){
        String filFileName = svioControlCompleted.getEventHeader().getMetadata().getEventSourceReferencedFilename();
        BiPairFile biPairFile = BiPairFile.builder()
                .fileName(filFileName)
                .build();
        if(!mongoDBService.doesCollectionExist(BI_PAIR_FILE_COLLECTION)){
            String errorMessage=String.format(NO_COLLECTION_FOUND, BI_PAIR_FILE_COLLECTION);
            kafkaTopicAlertService.sendError(errorMessage);
            throw new SvioReportingBatchException.BusinessValidationException(errorMessage);
        }
        mongoDBService.saveBiPairFile(biPairFile);

    }

    public String getPairFileName(String fileName, String eventSourceFileType){
        String pairFileName;
        if(eventSourceFileType.equals(TRANSACTIONS))
            pairFileName=fileName.replace("CARSTR","CARSDIST");
        else
            pairFileName=fileName.replace("CARSDIST","CARSTR");
        return pairFileName;
    }

}

