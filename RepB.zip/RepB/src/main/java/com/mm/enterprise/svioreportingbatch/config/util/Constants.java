
package com.mm.enterprise.svioreportingbatch.config.util;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class Constants {


        public static final String REPORTING_SESSION = "svio-reporting-batch-session";
        public static final String AWS_ROLE_ARN = "AWS_ROLE_ARN";

        public static final String INPUT_FIL_FILE = "inputFilFile";

        public static final String CURRENT_TIME = "time";

        public static final String INPUT_CONTROL_FILE = "inputControlFile";

        public static final String INPUT_TRANSACTION_FILE = "inputTransactionFile";
        public static final String WRITE_COUNT = "writeCount";

        public static final String UPDATE_DATE="updateDt";
        public static final String INPUT_DISBURSEMENT_FILE = "inputDisbursementFile";
        public static final String INPUT_FILE_TYPE = "inputFileType";
        public static final String RECORD_COUNT = "validation: Records count for %s file does not match expected data in control file %s. Computed: %s; Expected: %s.";
        public static final String TOTAL_AMT = "validation: Total net amount computed for %s file does not match expected data in the control file %s. Computed: %s; Expected: %s.";

        public static final String PROCESSED = "PROCESSED";

        public static final String FAILED = "FAILED";
        public static final String NO_DATA_CONTROL="Document not found in the controlfiles collection for Fil file %s ";
        public static final String EVENT_SOURCE_FILENAME = "eventHeader.metadata.eventSourceFilename";

        public static final String TRANSACTIONS_COLLECTION = "transactions";

        public static final String TRANSACTIONSEXTRACT="TRANSACTIONSEXTRACT";

        public static final String TRANSACTIONS="TRANSACTIONS";

        public static final String DISBURSEMENTS="DISBURSEMENTS";

        public static final String SVI_BI_GASAP="SVI_BI_GASAP";

        public static final String SVI_BI_TR_EXT="SVI_BI_TR_EXT";

        public static final String SVI_BI_TR_DISB="SVI_BI_TR_DISB";
        public static final String INSERT_SQL="INSERT INTO cashbook_data (account_num, sub_account_num, product_type_cde, fund_id_cde, fund_nm, phx_txn_type_cde, medium_cde, txn_type_cde, cashbook_type_desc, cashbook_class_desc, cashbook_activity_desc, cash_amt, effective_dt, valuation_dt, cashbook_dt, post_dt, payee_nm, bank_nm,bank_city_nm,bank_state_cde, instr_line1_txt, instr_line2_txt, instr_line3_txt, instr_line4_txt, instr_line5_txt, instr_line6_txt, contract_state_cde, company_code, business_area_cde, gl_account_num, profit_center_num, update_dt, login_user_id)\n" +
                "VALUES(:accountNum, :subAccountNum, :productTypeCde, :fundIdCde, :fundNm, :phxTxnTypeCde, :mediumCde, :txnTypeCde, :cashbookTypeDesc, :cashbookClassDesc, :cashbookActivityDesc, :cashAmt, :effectiveDt, :valuationDt, :cashbookDt, :postDt, :payeeNm, :bankNm, :bankCityNm, :bankStateCde, :instrLine1Txt, :instrLine2Txt, :instrLine3Txt, :instrLine4Txt, :instrLine5Txt, :instrLine6Txt, :contractStateCde, :companyCode, :businessAreaCde, :glAccountNum, :profitCenterCde, :updateDt,:loginUserId);";


        public static final String  CASHBOOK_MAPPING_ISSUES="cashbookMappingIssues";

        public static final String NO_CASHBOOK_MAPPING_FOUND = "No mapping found in %s collection for entries: %s";

        public static final String CASHBOOKMAPPING_COLLECTION = "cashbookMapping";

        public static final String BI_PAIR_FILE_COLLECTION ="biPairFile";

        public static final String NO_COLLECTION_FOUND = "%s collection not found";
}


