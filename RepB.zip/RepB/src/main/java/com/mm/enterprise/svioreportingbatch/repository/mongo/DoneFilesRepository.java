package com.mm.enterprise.svioreportingbatch.repository.mongo;

import com.mm.enterprise.svioreportingbatch.model.donefiles.DoneFile;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DoneFilesRepository extends MongoRepository<DoneFile,String> {

    @Query("{'eventHeader.statusSia' : ?0,'eventHeader.statusBi' : {$exists : ?1}}")
    List<DoneFile> findByStatusSiaAndStatusBi(String statusSia, Boolean statusBiExists);

    @Query("{'eventHeader.statusBi' : ?0, 'eventHeader.metadata.eventSourceFilename' : ?1}")
    List<DoneFile> findDoneByStatusBiAndFileName(String statusBi, String fileName);

    @Override
    <S extends DoneFile> S save(S doneFile);
}
