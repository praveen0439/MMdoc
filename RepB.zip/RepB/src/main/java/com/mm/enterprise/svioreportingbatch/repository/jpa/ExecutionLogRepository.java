package com.mm.enterprise.svioreportingbatch.repository.jpa;

import com.mm.enterprise.svioreportingbatch.model.cashbookdata.ExecutionLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
@Repository
public interface ExecutionLogRepository extends JpaRepository<ExecutionLog,Long> {
    List<ExecutionLog> findByExecutionDate(LocalDate date);
}
