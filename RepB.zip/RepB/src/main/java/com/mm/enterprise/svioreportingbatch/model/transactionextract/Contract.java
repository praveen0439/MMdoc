package com.mm.enterprise.svioreportingbatch.model.transactionextract;

import lombok.Data;

@Data
public class Contract {
    private String primaryId;
    private String suffix;
    Investment investment;
    Distributor distributor;
}
