package com.mm.enterprise.svioreportingbatch.model.cashbookdata;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;

@Entity
@Data
@Table(name="cashbook_notification_log")
public class ExecutionLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="execution_date")
    private LocalDate executionDate;

    public ExecutionLog() {
    }
    public ExecutionLog(LocalDate executionDate) {
        this.executionDate = executionDate;
    }
}

