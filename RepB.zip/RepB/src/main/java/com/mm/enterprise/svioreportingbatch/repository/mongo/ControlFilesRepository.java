package com.mm.enterprise.svioreportingbatch.repository.mongo;

import com.mm.enterprise.svioreportingbatch.model.controlfiles.ControlFile;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ControlFilesRepository extends MongoRepository<ControlFile,String> {

    @Query("{'eventHeader.metadata.eventSourceFilename' : ?0}")
    List<ControlFile> findByEventSourceFilename(String fileName);

    @Query("{'eventHeader.metadata.eventSourceReferencedFilename' : ?0}")
    List<ControlFile> findByEventSourceRefFilename(String fileName);

}
