package com.mm.enterprise.svioreportingbatch.config.jobs;

public enum BatchJobType {
    TRANSACTIONS_EXTRACT_EVENTS("transactionExtractEventsJob"),

    TRANSACTIONS_DISBURSEMENTS_EVENTS("transactionsDisbursementsEventsJob"),

    GASAP_EVENTS("gaSapExtractEventsJob");
    private final String value;
    BatchJobType(String value) {
        this.value = value;
    }
    public String getValue() {
        return value;
    }

}
