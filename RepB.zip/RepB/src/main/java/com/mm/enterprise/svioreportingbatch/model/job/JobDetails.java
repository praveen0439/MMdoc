package com.mm.enterprise.svioreportingbatch.model.job;

import lombok.Data;

@Data
public class JobDetails {

    private String jobName;
    private String doneFile;
    private String filTransactionFileName;
    private String filDisbursementFileName;
    private String ctrlFileName;
}
