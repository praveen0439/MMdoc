package com.mm.enterprise.svioreportingbatch.repository.mongo;

import com.mm.enterprise.svioreportingbatch.model.gasapextract.GaSapExtract;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GaSapExtractsRepository extends MongoRepository<GaSapExtract,String> {
}
