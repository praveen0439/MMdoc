package com.mm.enterprise.svioreportingbatch.model.disbursement;

import lombok.Data;

@Data
public class PayoutTransaction {
    private Payee payee;
    private Payout payout;
    private Contract contract;
}
