package com.mm.enterprise.svioreportingbatch.mapper;

import com.mm.enterprise.svioreportingbatch.model.cashbookdata.CashbookData;
import com.mm.enterprise.svioreportingbatch.model.gasapextract.GaSapExtract;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static com.mm.enterprise.svioreportingbatch.config.util.Constants.SVI_BI_GASAP;

@Component
@Slf4j(topic = "logger")
public class GaSapExtractMapper {

    public CashbookData mapFromMongoCollection(GaSapExtract gaSapExtract,Timestamp updateDt) {
        String accountNum=gaSapExtract.getIdNumber().substring(4,13);
        String subAccountNum=gaSapExtract.getIdNumber().substring(13,15);
        String debitCreditInd= gaSapExtract.getDebitCreditInd();
        Double cashAmtGaSap = Double.parseDouble(gaSapExtract.getCashAmount());
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        Double cashAmt=0.00;
        if(debitCreditInd.trim().equals("D"))
            cashAmt=-1*(cashAmtGaSap/100);
        else if(debitCreditInd.trim().equals("C"))
            cashAmt=(cashAmtGaSap/100);

            return CashbookData.builder()
                .accountNum(accountNum)
                .subAccountNum(subAccountNum)
                .productTypeCde("SIA")
                .txnTypeCde("G")
                .cashAmt(new BigDecimal(decimalFormat.format(cashAmt)))
                .cashbookDt(stringToDt(gaSapExtract.getPostingDate()))
                .postDt(stringToDt(gaSapExtract.getPostingDate()))
                .contractStateCde(gaSapExtract.getStateCode().trim())
                .companyCode(gaSapExtract.getCompanyCodeNumber().trim())
                .businessAreaCde(gaSapExtract.getBusinessArea())
                .glAccountNum(gaSapExtract.getGlAccountNumber())
                .profitCenterCde(gaSapExtract.getProfitCenterNumber())
                .updateDt(updateDt)
                .loginUserId(SVI_BI_GASAP)
                .build();

    }

    public static Timestamp stringToDt(String dateString)  {
        if(dateString.equals("00000000"))
            dateString="99991231";
        LocalDateTime localDateTime= LocalDate.parse(dateString, DateTimeFormatter.BASIC_ISO_DATE).atTime(00,00,00);
        return Timestamp.valueOf(localDateTime);

    }
}
