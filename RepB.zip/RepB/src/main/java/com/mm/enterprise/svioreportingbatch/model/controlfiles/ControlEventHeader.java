package com.mm.enterprise.svioreportingbatch.model.controlfiles;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ControlEventHeader {
    private String eventBatchGroupId;
    private BigDecimal eventBatchRecordCountTotal;
    private BigDecimal eventBatchTotalAmt;
    private String eventCorrelationId;
    private String eventGeneratedDateTime;
    private String eventInitiator;
    private String eventInitiatorDescription;
    private String eventSource;
    private String eventSourceDescription;
    private String eventType;
    private ControlMetadata metadata;
}
