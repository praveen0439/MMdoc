package com.mm.enterprise.svioreportingbatch.config.kafka.consumer;
import com.mm.enterprise.svioreportingbatch.config.kafka.KafkaConfiguration;
import com.mm.enterprise.svioreportingbatch.config.kafka.KafkaHelpers;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import jakarta.validation.constraints.NotNull;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;


@Configuration
@EnableKafka
public class KafkaConsumer {

    @NotNull
    @Value(value = "${mm.svio.reportingbatch.kafka.consumer.client.id}")
    private String clientId;

    @NotNull
    @Value(value = "${mm.svio.reportingbatch.kafka.consumer.group.id}")
    private String groupId;

    @Value(value = "${mm.svio.reportingbatch.kafka.consumer.heartbeat.interval:10000}")
    private Integer heartbeatInterval;

    @Value(value = "${mm.svio.reportingbatch.kafka.consumer.session.timeout:30000}")
    private Integer sessionTimeout;

    @Value(value = "${mm.svio.reportingbatch.kafka.consumer.max.poll.interval:60000}")
    private Integer maxPollInterval;

    @Value(value = "${mm.svio.reportingbatch.kafka.consumer.max.poll.records:2}")
    private Integer maxPollRecords;

    @Value(value = "${mm.svio.reportingbatch.kafka.consumer.request.timeout:5000}")
    private Integer requestTimeout;

    @Value(value = "${mm.svio.reportingbatch.kafka.consumer.offset.reset:latest}")
    private String offsetReset;

    @Value(value = "${mm.svio.reportingbatch.kafka.consumer.autocommit.interval:1000}")
    private Integer autocommitInterval;

    @Value(value = "${mm.svio.reportingbatch.kafka.consumer.enable.autocommit:true}")
    private Boolean enableAutocommit;

    @Value(value = "${mm.svio.reportingbatch.kafka.consumer.concurrency:1}")
    private Integer concurrency;

    @NotNull
    @Value(value = "${mm.svio.reportingbatch.kafka.consumer.poll.timeout:10000}")
    private Integer pollTimeout;

    private final KafkaConfiguration kafkaConfiguration;

    public KafkaConsumer(KafkaConfiguration kafkaConfiguration) {
        this.kafkaConfiguration = kafkaConfiguration;
    }

    @Bean
    public Map<String, Object> mmConsumerConfigs() {
        Map<String, Object> configs = new HashMap<>();
        configs.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaConfiguration.getKafkaUrl());
        configs.put(ConsumerConfig.CLIENT_ID_CONFIG, clientId);
        configs.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        configs.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, heartbeatInterval);
        configs.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, sessionTimeout);
        configs.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, maxPollInterval);
        configs.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, maxPollRecords);
        configs.put(ConsumerConfig.REQUEST_TIMEOUT_MS_CONFIG, requestTimeout);
        configs.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, offsetReset);
        configs.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, autocommitInterval);
        configs.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, enableAutocommit);
        configs.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        configs.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, KafkaAvroDeserializer.class);
        configs.put("spring.deserializer.value.delegate.class", KafkaAvroDeserializer.class);
        configs.put("schema.registry.url", kafkaConfiguration.getSchemaUrl());
        configs.put("specific.avro.reader", "true");

        KafkaHelpers.enableKafkaSecurity(configs, kafkaConfiguration);

        return configs;
    }
    @Bean
    public JsonDeserializer<Object> deserializer() {
        JsonDeserializer<Object> deserializer = new JsonDeserializer<>(Object.class);
        deserializer.addTrustedPackages("*");
        return deserializer;
    }

    public ConsumerFactory<String, Object> mmConsumerFactory() {

        var deserializer = new ErrorHandlingDeserializer<>(new KafkaAvroDeserializer());
        var configs = mmConsumerConfigs();

        deserializer.configure(configs, false);

        return new DefaultKafkaConsumerFactory<>(configs,
                new StringDeserializer(),
                deserializer);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object> mmKafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, Object> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(mmConsumerFactory());
        factory.setAutoStartup(true);
        factory.setBatchListener(false);
        factory.setConcurrency(concurrency);
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.RECORD);
        factory.getContainerProperties().setSyncCommits(true);
        factory.getContainerProperties().setPollTimeout(pollTimeout);
        factory.setContainerCustomizer(container -> container.getContainerProperties()
                .setAuthExceptionRetryInterval(Duration.ofSeconds(10L)));

        return factory;
    }
}