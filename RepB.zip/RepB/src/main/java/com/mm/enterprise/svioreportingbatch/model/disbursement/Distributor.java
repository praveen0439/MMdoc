package com.mm.enterprise.svioreportingbatch.model.disbursement;

import lombok.Data;

@Data
public class Distributor {
    private String number;
}
