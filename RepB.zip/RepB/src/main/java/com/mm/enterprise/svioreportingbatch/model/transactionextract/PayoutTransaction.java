package com.mm.enterprise.svioreportingbatch.model.transactionextract;

import lombok.Data;

@Data
public class PayoutTransaction {
    Payout payout;
}
