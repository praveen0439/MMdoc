package com.mm.enterprise.svioreportingbatch.config.exception;

public class SvioReportingBatchException extends RuntimeException {
    public SvioReportingBatchException(String message,Throwable cause) {
        super(message,cause);
    }

    public static class BusinessValidationRetryableException extends RuntimeException {
        public BusinessValidationRetryableException(String msg) {
            super(msg);
            initCause(new RuntimeException(msg));
        }
    }

    public static class BusinessValidationException extends RuntimeException {
        public BusinessValidationException(String msg) {
            super(msg);
            initCause(new RuntimeException(msg));
        }
    }
}
