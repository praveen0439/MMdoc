package com.mm.enterprise.svioreportingbatch.model.disbursement;

import lombok.Data;

@Data
public class Transaction {
    private boolean reversalIndicator;
    private String reversalCode;
}
