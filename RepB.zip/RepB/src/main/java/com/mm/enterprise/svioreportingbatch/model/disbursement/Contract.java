package com.mm.enterprise.svioreportingbatch.model.disbursement;

import lombok.Data;

@Data
public class Contract {
    private String primaryId;
    private String suffix;
    private Investment investment;
    private Distributor distributor;
    private Owner owner;
}
