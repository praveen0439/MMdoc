package com.mm.enterprise.svioreportingbatch.model.alerts;

import lombok.Data;

@Data
public class AlertRecipients {
    private String errorEmail;
    private String errorSlackChannel;
    private String errorWebhook;
    private String errorIconEmoji;
    private String errorSubject;
    private String notificationEmail;
    private String notificationBusinessEmail;
    private String notificationSlackChannel;
    private String notificationWebhook;
    private String notificationIconEmoji;
    private String notificationWarningIconEmoji;
    private String notificationSubject;
    private String notificationBusinessSubject;
    private Boolean xmattersEnabled;
    private String xmattersGroupName;
    private String xmattersType;
}
