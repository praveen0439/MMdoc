package com.mm.enterprise.svioreportingbatch.listener;

import com.mm.enterprise.svioreportingbatch.abstracts.SvioReportingBatchExecutionListener;
import com.mm.enterprise.svioreportingbatch.config.exception.KafkaMessageServiceException;
import com.mm.enterprise.svioreportingbatch.config.service.KafkaTopicAlertService;
import com.mm.enterprise.svioreportingbatch.config.service.MongoDBService;
import com.mm.enterprise.svioreportingbatch.config.service.PostgresDBService;
import com.mm.enterprise.svioreportingbatch.model.donefiles.DoneFile;
import com.mongodb.MongoException;
import com.mongodb.client.result.UpdateResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.dao.DataAccessException;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.kafka.KafkaException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import static com.mm.enterprise.svioreportingbatch.config.exception.KafkaMessageServiceException.KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE;
import static com.mm.enterprise.svioreportingbatch.config.exception.KafkaMessageServiceException.WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE;
import static com.mm.enterprise.svioreportingbatch.config.util.Constants.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class SvioReportingBatchExecutionListenerGaSap implements SvioReportingBatchExecutionListener {
    private final KafkaTopicAlertService kafkaTopicAlertService;

    private final MongoDBService mongoDBService;

    private final MongoTemplate mongoTemplate;

    private final PostgresDBService postgresDBService;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.info("Starting SvioReportingBatchJobExecutionListener");
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        log.info("{} finished with status {}", jobExecution.getJobInstance().getJobName(), jobExecution.getExitStatus());
        List<StepExecution> stepExecutions = new ArrayList<>(jobExecution.getStepExecutions());

        if (ExitStatus.COMPLETED.equals(jobExecution.getExitStatus())) {
            ExecutionContext executionContext = jobExecution.getExecutionContext();
            final long writeCount = executionContext.getLong(WRITE_COUNT);
            String notificationMessage= "Svio reporting batch job executed successfully for GASAP event. No. of rows inserted: "+writeCount;
            try {
                    kafkaTopicAlertService.sendNotification(notificationMessage);
                    mongoDBService.deleteAllGaSapLines();
                    updateDoneStatus(PROCESSED);

            } catch (InterruptedException | ExecutionException | TimeoutException e) {
                Thread.currentThread().interrupt();
                throw new KafkaMessageServiceException(WAIT_FOR_MESSAGE_TO_BE_SENT_EXCEPTION_MESSAGE, e);
            } catch (KafkaException e) {
                throw new KafkaMessageServiceException(KAFKA_MESSAGE_SEND_EXCEPTION_MESSAGE, e);
            }
        } else {
            Timestamp updateDt=(Timestamp) jobExecution.getExecutionContext().get(UPDATE_DATE);
            StepExecution failedStepExecution = stepExecutions.get(stepExecutions.size() - 1);
            List<Throwable> failureExceptions = failedStepExecution.getFailureExceptions();

            String localisedErrorMessage;
            if (failureExceptions.get(failureExceptions.size() - 1).getCause() != null) {
                localisedErrorMessage = failureExceptions.get(failureExceptions.size() - 1).getCause().toString();
            } else {
                localisedErrorMessage = failureExceptions.get(failureExceptions.size() - 1).getLocalizedMessage();
            }

            String errorMessage =
                    jobExecution.getJobInstance().getJobName() + " job FAILED in step: " + failedStepExecution.getStepName() + " with error: "
                            + localisedErrorMessage;
            kafkaTopicAlertService.sendError(errorMessage);
            postgresDBService.deleteLoadedCashbookDataOnFailure(updateDt,SVI_BI_GASAP);
            updateDoneStatus(FAILED);


        }
    }

    @Retryable(retryFor = {MongoException.class, DataAccessException.class},maxAttempts = 5,backoff = @Backoff(delay = 2000))
    public void updateDoneStatus(String status) throws MongoException,DataAccessException{
        Query query = new Query().addCriteria(Criteria.where("eventHeader.statusBi").exists(false).and("eventHeader.statusSia").is(PROCESSED));
        Update updatedef= new Update().set("eventHeader.statusBi",status);
        UpdateResult updateResult = mongoTemplate.updateFirst(query,updatedef, DoneFile.class);
        log.info("Done status update: "+updateResult);
    }
}
